
# Ensures that the stubs are picked up - thanks, numpy project
from depthai import (
    node as node,
)

import typing
json = dict
from pathlib import Path
from typing import Set, Type, TypeVar
T = TypeVar('T')
import datetime
import numpy
from . import node as node
from _typeshed import Incomplete
from typing import Callable, ClassVar, Iterator, overload

X_LINK_ALREADY_OPEN: XLinkError_t
X_LINK_ANY_PLATFORM: XLinkPlatform
X_LINK_ANY_PROTOCOL: XLinkProtocol
X_LINK_ANY_STATE: XLinkDeviceState
X_LINK_BOOTED: XLinkDeviceState
X_LINK_BOOTLOADER: XLinkDeviceState
X_LINK_COMMUNICATION_FAIL: XLinkError_t
X_LINK_COMMUNICATION_NOT_OPEN: XLinkError_t
X_LINK_COMMUNICATION_UNKNOWN_ERROR: XLinkError_t
X_LINK_DEVICE_ALREADY_IN_USE: XLinkError_t
X_LINK_DEVICE_NOT_FOUND: XLinkError_t
X_LINK_ERROR: XLinkError_t
X_LINK_FLASH_BOOTED: XLinkDeviceState
X_LINK_INIT_PCIE_ERROR: XLinkError_t
X_LINK_INIT_TCP_IP_ERROR: XLinkError_t
X_LINK_INIT_USB_ERROR: XLinkError_t
X_LINK_INSUFFICIENT_PERMISSIONS: XLinkError_t
X_LINK_IPC: XLinkProtocol
X_LINK_MYRIAD_2: XLinkPlatform
X_LINK_MYRIAD_X: XLinkPlatform
X_LINK_NMB_OF_PROTOCOLS: XLinkProtocol
X_LINK_NOT_IMPLEMENTED: XLinkError_t
X_LINK_OUT_OF_MEMORY: XLinkError_t
X_LINK_PCIE: XLinkProtocol
X_LINK_SUCCESS: XLinkError_t
X_LINK_TCP_IP: XLinkProtocol
X_LINK_TIMEOUT: XLinkError_t
X_LINK_UNBOOTED: XLinkDeviceState
X_LINK_USB_CDC: XLinkProtocol
X_LINK_USB_VSC: XLinkProtocol
__bootloader_version__: str
__build_datetime__: str
__commit__: str
__commit_datetime__: str
__device_version__: str
__version__: str

class ADatatype:
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""
    def getRaw(self) -> RawBuffer:
        """getRaw(self: depthai.ADatatype) -> depthai.RawBuffer"""

class AprilTag:
    bottomLeft: Point2f
    bottomRight: Point2f
    decisionMargin: Incomplete
    hamming: int
    id: int
    topLeft: Point2f
    topRight: Point2f
    def __init__(self) -> None:
        """__init__(self: depthai.AprilTag) -> None"""

class AprilTagConfig(Buffer):
    class Family:
        __members__: ClassVar[dict] = ...  # read-only
        TAG_16H5: ClassVar[RawAprilTagConfig.Family] = ...
        TAG_25H9: ClassVar[RawAprilTagConfig.Family] = ...
        TAG_36H10: ClassVar[RawAprilTagConfig.Family] = ...
        TAG_36H11: ClassVar[RawAprilTagConfig.Family] = ...
        TAG_CIR21H7: ClassVar[RawAprilTagConfig.Family] = ...
        TAG_STAND41H12: ClassVar[RawAprilTagConfig.Family] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawAprilTagConfig.Family, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawAprilTagConfig.Family) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawAprilTagConfig.Family) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class QuadThresholds:
        criticalDegree: float
        deglitch: bool
        maxLineFitMse: float
        maxNmaxima: int
        minClusterPixels: int
        minWhiteBlackDiff: int
        def __init__(self) -> None:
            """__init__(self: depthai.RawAprilTagConfig.QuadThresholds) -> None"""
    def __init__(self) -> None:
        """__init__(self: depthai.AprilTagConfig) -> None"""
    def get(self) -> RawAprilTagConfig:
        """get(self: depthai.AprilTagConfig) -> depthai.RawAprilTagConfig

        Retrieve configuration data for AprilTag.

        Returns:
            config for stereo depth algorithm
        """
    def set(self, arg0: RawAprilTagConfig) -> AprilTagConfig:
        """set(self: depthai.AprilTagConfig, arg0: depthai.RawAprilTagConfig) -> depthai.AprilTagConfig

        Set explicit configuration.

        Parameter ``config``:
            Explicit configuration
        """
    def setFamily(self, family: RawAprilTagConfig.Family) -> AprilTagConfig:
        """setFamily(self: depthai.AprilTagConfig, family: depthai.RawAprilTagConfig.Family) -> depthai.AprilTagConfig

        Parameter ``family``:
            AprilTag family
        """

class AprilTagProperties:
    initialConfig: RawAprilTagConfig
    inputConfigSync: bool
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class AprilTags(Buffer):
    aprilTags: list[AprilTag]
    def __init__(self) -> None:
        """__init__(self: depthai.AprilTags) -> None"""
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.AprilTags) -> int

        Retrieves sequence number
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.AprilTags) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.AprilTags) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """
    def setSequenceNum(self, arg0: int) -> AprilTags:
        """setSequenceNum(self: depthai.AprilTags, arg0: int) -> depthai.AprilTags

        Retrieves image sequence number
        """
    def setTimestamp(self, arg0: datetime.timedelta) -> AprilTags:
        """setTimestamp(self: depthai.AprilTags, arg0: datetime.timedelta) -> depthai.AprilTags

        Sets image timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> AprilTags:
        """setTimestampDevice(self: depthai.AprilTags, arg0: datetime.timedelta) -> depthai.AprilTags

        Sets image timestamp related to dai::Clock::now()
        """

class Asset:
    alignment: int
    data: numpy.ndarray[numpy.uint8]
    @overload
    def __init__(self) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Asset) -> None

        2. __init__(self: depthai.Asset, arg0: str) -> None
        """
    @overload
    def __init__(self, arg0: str) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Asset) -> None

        2. __init__(self: depthai.Asset, arg0: str) -> None
        """
    @property
    def key(self) -> str: ...

class AssetManager:
    def __init__(self) -> None:
        """__init__(self: depthai.AssetManager) -> None"""
    def addExisting(self, assets: list[Asset]) -> None:
        """addExisting(self: depthai.AssetManager, assets: list[depthai.Asset]) -> None

        Adds all assets in an array to the AssetManager

        Parameter ``assets``:
            Vector of assets to add
        """
    @overload
    def get(self, key: str) -> Asset:
        """get(*args, **kwargs)
        Overloaded function.

        1. get(self: depthai.AssetManager, key: str) -> depthai.Asset

        Returns:
            Asset assigned to the specified key or a nullptr otherwise

        2. get(self: depthai.AssetManager, key: str) -> depthai.Asset

        Returns:
            Asset assigned to the specified key or a nullptr otherwise
        """
    @overload
    def get(self, key: str) -> Asset:
        """get(*args, **kwargs)
        Overloaded function.

        1. get(self: depthai.AssetManager, key: str) -> depthai.Asset

        Returns:
            Asset assigned to the specified key or a nullptr otherwise

        2. get(self: depthai.AssetManager, key: str) -> depthai.Asset

        Returns:
            Asset assigned to the specified key or a nullptr otherwise
        """
    @overload
    def getAll(self) -> list[Asset]:
        """getAll(*args, **kwargs)
        Overloaded function.

        1. getAll(self: depthai.AssetManager) -> list[depthai.Asset]

        Returns:
            All asset stored in the AssetManager

        2. getAll(self: depthai.AssetManager) -> list[depthai.Asset]

        Returns:
            All asset stored in the AssetManager
        """
    @overload
    def getAll(self) -> list[Asset]:
        """getAll(*args, **kwargs)
        Overloaded function.

        1. getAll(self: depthai.AssetManager) -> list[depthai.Asset]

        Returns:
            All asset stored in the AssetManager

        2. getAll(self: depthai.AssetManager) -> list[depthai.Asset]

        Returns:
            All asset stored in the AssetManager
        """
    def remove(self, key: str) -> None:
        """remove(self: depthai.AssetManager, key: str) -> None

        Removes asset with key

        Parameter ``key``:
            Key of asset to remove
        """
    @overload
    def set(self, asset: Asset) -> Asset:
        """set(*args, **kwargs)
        Overloaded function.

        1. set(self: depthai.AssetManager, asset: depthai.Asset) -> depthai.Asset

        Adds or overwrites an asset object to AssetManager.

        Parameter ``asset``:
            Asset to add

        Returns:
            Shared pointer to asset

        2. set(self: depthai.AssetManager, key: str, asset: depthai.Asset) -> depthai.Asset

        Adds or overwrites an asset object to AssetManager with a specified key. Key
        value will be assigned to an Asset as well

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``asset``:
            Asset to store

        Returns:
            Shared pointer to asset

        3. set(self: depthai.AssetManager, key: str, path: Path, alignment: int = 64) -> depthai.Asset

        Loads file into asset manager under specified key.

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``path``:
            Path to file which to load as asset

        Parameter ``alignment``:
            [Optional] alignment of asset data in asset storage. Default is 64B

        4. set(self: depthai.AssetManager, key: str, data: list[int], alignment: int = 64) -> depthai.Asset

        Loads file into asset manager under specified key.

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``data``:
            Asset data

        Parameter ``alignment``:
            [Optional] alignment of asset data in asset storage. Default is 64B

        Returns:
            Shared pointer to asset
        """
    @overload
    def set(self, key: str, asset: Asset) -> Asset:
        """set(*args, **kwargs)
        Overloaded function.

        1. set(self: depthai.AssetManager, asset: depthai.Asset) -> depthai.Asset

        Adds or overwrites an asset object to AssetManager.

        Parameter ``asset``:
            Asset to add

        Returns:
            Shared pointer to asset

        2. set(self: depthai.AssetManager, key: str, asset: depthai.Asset) -> depthai.Asset

        Adds or overwrites an asset object to AssetManager with a specified key. Key
        value will be assigned to an Asset as well

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``asset``:
            Asset to store

        Returns:
            Shared pointer to asset

        3. set(self: depthai.AssetManager, key: str, path: Path, alignment: int = 64) -> depthai.Asset

        Loads file into asset manager under specified key.

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``path``:
            Path to file which to load as asset

        Parameter ``alignment``:
            [Optional] alignment of asset data in asset storage. Default is 64B

        4. set(self: depthai.AssetManager, key: str, data: list[int], alignment: int = 64) -> depthai.Asset

        Loads file into asset manager under specified key.

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``data``:
            Asset data

        Parameter ``alignment``:
            [Optional] alignment of asset data in asset storage. Default is 64B

        Returns:
            Shared pointer to asset
        """
    @overload
    def set(self, key: str, path: Path, alignment: int = ...) -> Asset:
        """set(*args, **kwargs)
        Overloaded function.

        1. set(self: depthai.AssetManager, asset: depthai.Asset) -> depthai.Asset

        Adds or overwrites an asset object to AssetManager.

        Parameter ``asset``:
            Asset to add

        Returns:
            Shared pointer to asset

        2. set(self: depthai.AssetManager, key: str, asset: depthai.Asset) -> depthai.Asset

        Adds or overwrites an asset object to AssetManager with a specified key. Key
        value will be assigned to an Asset as well

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``asset``:
            Asset to store

        Returns:
            Shared pointer to asset

        3. set(self: depthai.AssetManager, key: str, path: Path, alignment: int = 64) -> depthai.Asset

        Loads file into asset manager under specified key.

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``path``:
            Path to file which to load as asset

        Parameter ``alignment``:
            [Optional] alignment of asset data in asset storage. Default is 64B

        4. set(self: depthai.AssetManager, key: str, data: list[int], alignment: int = 64) -> depthai.Asset

        Loads file into asset manager under specified key.

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``data``:
            Asset data

        Parameter ``alignment``:
            [Optional] alignment of asset data in asset storage. Default is 64B

        Returns:
            Shared pointer to asset
        """
    @overload
    def set(self, key: str, data: list[int], alignment: int = ...) -> Asset:
        """set(*args, **kwargs)
        Overloaded function.

        1. set(self: depthai.AssetManager, asset: depthai.Asset) -> depthai.Asset

        Adds or overwrites an asset object to AssetManager.

        Parameter ``asset``:
            Asset to add

        Returns:
            Shared pointer to asset

        2. set(self: depthai.AssetManager, key: str, asset: depthai.Asset) -> depthai.Asset

        Adds or overwrites an asset object to AssetManager with a specified key. Key
        value will be assigned to an Asset as well

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``asset``:
            Asset to store

        Returns:
            Shared pointer to asset

        3. set(self: depthai.AssetManager, key: str, path: Path, alignment: int = 64) -> depthai.Asset

        Loads file into asset manager under specified key.

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``path``:
            Path to file which to load as asset

        Parameter ``alignment``:
            [Optional] alignment of asset data in asset storage. Default is 64B

        4. set(self: depthai.AssetManager, key: str, data: list[int], alignment: int = 64) -> depthai.Asset

        Loads file into asset manager under specified key.

        Parameter ``key``:
            Key under which the asset should be stored

        Parameter ``data``:
            Asset data

        Parameter ``alignment``:
            [Optional] alignment of asset data in asset storage. Default is 64B

        Returns:
            Shared pointer to asset
        """
    def size(self) -> int:
        """size(self: depthai.AssetManager) -> int

        Returns:
            Number of asset stored in the AssetManager
        """

class BoardConfig:
    class GPIO:
        class Direction:
            __members__: ClassVar[dict] = ...  # read-only
            INPUT: ClassVar[BoardConfig.GPIO.Direction] = ...
            OUTPUT: ClassVar[BoardConfig.GPIO.Direction] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.BoardConfig.GPIO.Direction, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.BoardConfig.GPIO.Direction) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.BoardConfig.GPIO.Direction) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...

        class Drive:
            __members__: ClassVar[dict] = ...  # read-only
            MA_12: ClassVar[BoardConfig.GPIO.Drive] = ...
            MA_2: ClassVar[BoardConfig.GPIO.Drive] = ...
            MA_4: ClassVar[BoardConfig.GPIO.Drive] = ...
            MA_8: ClassVar[BoardConfig.GPIO.Drive] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.BoardConfig.GPIO.Drive, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.BoardConfig.GPIO.Drive) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.BoardConfig.GPIO.Drive) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...

        class Level:
            __members__: ClassVar[dict] = ...  # read-only
            HIGH: ClassVar[BoardConfig.GPIO.Level] = ...
            LOW: ClassVar[BoardConfig.GPIO.Level] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.BoardConfig.GPIO.Level, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.BoardConfig.GPIO.Level) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.BoardConfig.GPIO.Level) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...

        class Mode:
            __members__: ClassVar[dict] = ...  # read-only
            ALT_MODE_0: ClassVar[BoardConfig.GPIO.Mode] = ...
            ALT_MODE_1: ClassVar[BoardConfig.GPIO.Mode] = ...
            ALT_MODE_2: ClassVar[BoardConfig.GPIO.Mode] = ...
            ALT_MODE_3: ClassVar[BoardConfig.GPIO.Mode] = ...
            ALT_MODE_4: ClassVar[BoardConfig.GPIO.Mode] = ...
            ALT_MODE_5: ClassVar[BoardConfig.GPIO.Mode] = ...
            ALT_MODE_6: ClassVar[BoardConfig.GPIO.Mode] = ...
            DIRECT: ClassVar[BoardConfig.GPIO.Mode] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.BoardConfig.GPIO.Mode, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.BoardConfig.GPIO.Mode) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.BoardConfig.GPIO.Mode) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...

        class Pull:
            __members__: ClassVar[dict] = ...  # read-only
            BUS_KEEPER: ClassVar[BoardConfig.GPIO.Pull] = ...
            NO_PULL: ClassVar[BoardConfig.GPIO.Pull] = ...
            PULL_DOWN: ClassVar[BoardConfig.GPIO.Pull] = ...
            PULL_UP: ClassVar[BoardConfig.GPIO.Pull] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.BoardConfig.GPIO.Pull, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.BoardConfig.GPIO.Pull) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.BoardConfig.GPIO.Pull) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...
        ALT_MODE_0: ClassVar[BoardConfig.GPIO.Mode] = ...
        ALT_MODE_1: ClassVar[BoardConfig.GPIO.Mode] = ...
        ALT_MODE_2: ClassVar[BoardConfig.GPIO.Mode] = ...
        ALT_MODE_3: ClassVar[BoardConfig.GPIO.Mode] = ...
        ALT_MODE_4: ClassVar[BoardConfig.GPIO.Mode] = ...
        ALT_MODE_5: ClassVar[BoardConfig.GPIO.Mode] = ...
        ALT_MODE_6: ClassVar[BoardConfig.GPIO.Mode] = ...
        BUS_KEEPER: ClassVar[BoardConfig.GPIO.Pull] = ...
        DIRECT: ClassVar[BoardConfig.GPIO.Mode] = ...
        HIGH: ClassVar[BoardConfig.GPIO.Level] = ...
        INPUT: ClassVar[BoardConfig.GPIO.Direction] = ...
        LOW: ClassVar[BoardConfig.GPIO.Level] = ...
        MA_12: ClassVar[BoardConfig.GPIO.Drive] = ...
        MA_2: ClassVar[BoardConfig.GPIO.Drive] = ...
        MA_4: ClassVar[BoardConfig.GPIO.Drive] = ...
        MA_8: ClassVar[BoardConfig.GPIO.Drive] = ...
        NO_PULL: ClassVar[BoardConfig.GPIO.Pull] = ...
        OUTPUT: ClassVar[BoardConfig.GPIO.Direction] = ...
        PULL_DOWN: ClassVar[BoardConfig.GPIO.Pull] = ...
        PULL_UP: ClassVar[BoardConfig.GPIO.Pull] = ...
        direction: BoardConfig.GPIO.Direction
        drive: BoardConfig.GPIO.Drive
        level: BoardConfig.GPIO.Level
        mode: BoardConfig.GPIO.Mode
        pull: BoardConfig.GPIO.Pull
        schmitt: bool
        slewFast: bool
        @overload
        def __init__(self) -> None:
            """__init__(*args, **kwargs)
            Overloaded function.

            1. __init__(self: depthai.BoardConfig.GPIO) -> None

            2. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction) -> None

            3. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level) -> None

            4. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level, arg2: depthai.BoardConfig.GPIO.Pull) -> None

            5. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode) -> None

            6. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode, arg2: depthai.BoardConfig.GPIO.Pull) -> None
            """
        @overload
        def __init__(self, arg0: BoardConfig.GPIO.Direction) -> None:
            """__init__(*args, **kwargs)
            Overloaded function.

            1. __init__(self: depthai.BoardConfig.GPIO) -> None

            2. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction) -> None

            3. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level) -> None

            4. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level, arg2: depthai.BoardConfig.GPIO.Pull) -> None

            5. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode) -> None

            6. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode, arg2: depthai.BoardConfig.GPIO.Pull) -> None
            """
        @overload
        def __init__(self, arg0: BoardConfig.GPIO.Direction, arg1: BoardConfig.GPIO.Level) -> None:
            """__init__(*args, **kwargs)
            Overloaded function.

            1. __init__(self: depthai.BoardConfig.GPIO) -> None

            2. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction) -> None

            3. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level) -> None

            4. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level, arg2: depthai.BoardConfig.GPIO.Pull) -> None

            5. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode) -> None

            6. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode, arg2: depthai.BoardConfig.GPIO.Pull) -> None
            """
        @overload
        def __init__(self, arg0: BoardConfig.GPIO.Direction, arg1: BoardConfig.GPIO.Level, arg2: BoardConfig.GPIO.Pull) -> None:
            """__init__(*args, **kwargs)
            Overloaded function.

            1. __init__(self: depthai.BoardConfig.GPIO) -> None

            2. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction) -> None

            3. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level) -> None

            4. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level, arg2: depthai.BoardConfig.GPIO.Pull) -> None

            5. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode) -> None

            6. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode, arg2: depthai.BoardConfig.GPIO.Pull) -> None
            """
        @overload
        def __init__(self, arg0: BoardConfig.GPIO.Direction, arg1: BoardConfig.GPIO.Mode) -> None:
            """__init__(*args, **kwargs)
            Overloaded function.

            1. __init__(self: depthai.BoardConfig.GPIO) -> None

            2. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction) -> None

            3. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level) -> None

            4. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level, arg2: depthai.BoardConfig.GPIO.Pull) -> None

            5. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode) -> None

            6. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode, arg2: depthai.BoardConfig.GPIO.Pull) -> None
            """
        @overload
        def __init__(self, arg0: BoardConfig.GPIO.Direction, arg1: BoardConfig.GPIO.Mode, arg2: BoardConfig.GPIO.Pull) -> None:
            """__init__(*args, **kwargs)
            Overloaded function.

            1. __init__(self: depthai.BoardConfig.GPIO) -> None

            2. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction) -> None

            3. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level) -> None

            4. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Level, arg2: depthai.BoardConfig.GPIO.Pull) -> None

            5. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode) -> None

            6. __init__(self: depthai.BoardConfig.GPIO, arg0: depthai.BoardConfig.GPIO.Direction, arg1: depthai.BoardConfig.GPIO.Mode, arg2: depthai.BoardConfig.GPIO.Pull) -> None
            """

    class GPIOMap:
        def __init__(self) -> None:
            """__init__(self: depthai.BoardConfig.GPIOMap) -> None"""
        def items(self) -> BoardConfig.ItemsView:
            """items(self: depthai.BoardConfig.GPIOMap) -> depthai.BoardConfig.ItemsView"""
        def keys(self) -> BoardConfig.KeysView:
            """keys(self: depthai.BoardConfig.GPIOMap) -> depthai.BoardConfig.KeysView"""
        def values(self) -> BoardConfig.ValuesView:
            """values(self: depthai.BoardConfig.GPIOMap) -> depthai.BoardConfig.ValuesView"""
        def __bool__(self) -> bool:
            """__bool__(self: depthai.BoardConfig.GPIOMap) -> bool

            Check whether the map is nonempty
            """
        @overload
        def __contains__(self, arg0: int) -> bool:
            """__contains__(*args, **kwargs)
            Overloaded function.

            1. __contains__(self: depthai.BoardConfig.GPIOMap, arg0: int) -> bool

            2. __contains__(self: depthai.BoardConfig.GPIOMap, arg0: object) -> bool
            """
        @overload
        def __contains__(self, arg0: object) -> bool:
            """__contains__(*args, **kwargs)
            Overloaded function.

            1. __contains__(self: depthai.BoardConfig.GPIOMap, arg0: int) -> bool

            2. __contains__(self: depthai.BoardConfig.GPIOMap, arg0: object) -> bool
            """
        def __delitem__(self, arg0: int) -> None:
            """__delitem__(self: depthai.BoardConfig.GPIOMap, arg0: int) -> None"""
        def __getitem__(self, arg0: int) -> BoardConfig.GPIO:
            """__getitem__(self: depthai.BoardConfig.GPIOMap, arg0: int) -> depthai.BoardConfig.GPIO"""
        def __iter__(self) -> Iterator[int]:
            """__iter__(self: depthai.BoardConfig.GPIOMap) -> Iterator[int]"""
        def __len__(self) -> int:
            """__len__(self: depthai.BoardConfig.GPIOMap) -> int"""
        def __setitem__(self, arg0: int, arg1: BoardConfig.GPIO) -> None:
            """__setitem__(self: depthai.BoardConfig.GPIOMap, arg0: int, arg1: depthai.BoardConfig.GPIO) -> None"""

    class ItemsView:
        def __init__(self, *args, **kwargs) -> None:
            """Initialize self.  See help(type(self)) for accurate signature."""
        def __iter__(self) -> Iterator:
            """__iter__(self: depthai.BoardConfig.ItemsView) -> Iterator"""
        def __len__(self) -> int:
            """__len__(self: depthai.BoardConfig.ItemsView) -> int"""

    class KeysView:
        def __init__(self, *args, **kwargs) -> None:
            """Initialize self.  See help(type(self)) for accurate signature."""
        def __contains__(self, arg0: object) -> bool:
            """__contains__(self: depthai.BoardConfig.KeysView, arg0: object) -> bool"""
        def __iter__(self) -> Iterator:
            """__iter__(self: depthai.BoardConfig.KeysView) -> Iterator"""
        def __len__(self) -> int:
            """__len__(self: depthai.BoardConfig.KeysView) -> int"""

    class Network:
        mtu: int
        xlinkTcpNoDelay: bool
        def __init__(self) -> None:
            """__init__(self: depthai.BoardConfig.Network) -> None"""

    class UART:
        tmp: int
        def __init__(self) -> None:
            """__init__(self: depthai.BoardConfig.UART) -> None"""

    class UARTMap:
        def __init__(self) -> None:
            """__init__(self: depthai.BoardConfig.UARTMap) -> None"""
        def items(self) -> BoardConfig.ItemsView:
            """items(self: depthai.BoardConfig.UARTMap) -> depthai.BoardConfig.ItemsView"""
        def keys(self) -> BoardConfig.KeysView:
            """keys(self: depthai.BoardConfig.UARTMap) -> depthai.BoardConfig.KeysView"""
        def values(self) -> BoardConfig.ValuesView:
            """values(self: depthai.BoardConfig.UARTMap) -> depthai.BoardConfig.ValuesView"""
        def __bool__(self) -> bool:
            """__bool__(self: depthai.BoardConfig.UARTMap) -> bool

            Check whether the map is nonempty
            """
        @overload
        def __contains__(self, arg0: int) -> bool:
            """__contains__(*args, **kwargs)
            Overloaded function.

            1. __contains__(self: depthai.BoardConfig.UARTMap, arg0: int) -> bool

            2. __contains__(self: depthai.BoardConfig.UARTMap, arg0: object) -> bool
            """
        @overload
        def __contains__(self, arg0: object) -> bool:
            """__contains__(*args, **kwargs)
            Overloaded function.

            1. __contains__(self: depthai.BoardConfig.UARTMap, arg0: int) -> bool

            2. __contains__(self: depthai.BoardConfig.UARTMap, arg0: object) -> bool
            """
        def __delitem__(self, arg0: int) -> None:
            """__delitem__(self: depthai.BoardConfig.UARTMap, arg0: int) -> None"""
        def __getitem__(self, arg0: int) -> BoardConfig.UART:
            """__getitem__(self: depthai.BoardConfig.UARTMap, arg0: int) -> depthai.BoardConfig.UART"""
        def __iter__(self) -> Iterator[int]:
            """__iter__(self: depthai.BoardConfig.UARTMap) -> Iterator[int]"""
        def __len__(self) -> int:
            """__len__(self: depthai.BoardConfig.UARTMap) -> int"""
        def __setitem__(self, arg0: int, arg1: BoardConfig.UART) -> None:
            """__setitem__(self: depthai.BoardConfig.UARTMap, arg0: int, arg1: depthai.BoardConfig.UART) -> None"""

    class USB:
        flashBootedPid: int
        flashBootedVid: int
        manufacturer: str
        maxSpeed: UsbSpeed
        pid: int
        productName: str
        vid: int
        def __init__(self) -> None:
            """__init__(self: depthai.BoardConfig.USB) -> None"""

    class UVC:
        cameraName: str
        enable: bool
        frameType: RawImgFrame.Type
        height: int
        width: int
        @overload
        def __init__(self) -> None:
            """__init__(*args, **kwargs)
            Overloaded function.

            1. __init__(self: depthai.BoardConfig.UVC) -> None

            2. __init__(self: depthai.BoardConfig.UVC, arg0: int, arg1: int) -> None
            """
        @overload
        def __init__(self, arg0: int, arg1: int) -> None:
            """__init__(*args, **kwargs)
            Overloaded function.

            1. __init__(self: depthai.BoardConfig.UVC) -> None

            2. __init__(self: depthai.BoardConfig.UVC, arg0: int, arg1: int) -> None
            """

    class ValuesView:
        def __init__(self, *args, **kwargs) -> None:
            """Initialize self.  See help(type(self)) for accurate signature."""
        def __iter__(self) -> Iterator:
            """__iter__(self: depthai.BoardConfig.ValuesView) -> Iterator"""
        def __len__(self) -> int:
            """__len__(self: depthai.BoardConfig.ValuesView) -> int"""
    emmc: bool | None
    gpio: BoardConfig.GPIOMap
    logDevicePrints: bool | None
    logPath: str | None
    logSizeMax: int | None
    logVerbosity: LogLevel | None
    mipi4LaneRgb: bool | None
    network: BoardConfig.Network
    pcieInternalClock: bool | None
    sysctl: list[str]
    uart: BoardConfig.UARTMap
    usb: BoardConfig.USB
    usb3PhyInternalClock: bool | None
    uvc: BoardConfig.UVC | None
    watchdogInitialDelayMs: int | None
    watchdogTimeoutMs: int | None
    def __init__(self) -> None:
        """__init__(self: depthai.BoardConfig) -> None"""

class Buffer(ADatatype):
    def __init__(self) -> None:
        """__init__(self: depthai.Buffer) -> None

        Creates Buffer message
        """
    def getData(self) -> numpy.ndarray[numpy.uint8]:
        """getData(self: object) -> numpy.ndarray[numpy.uint8]

        Get non-owning reference to internal buffer

        Returns:
            Reference to internal buffer
        """
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.Buffer) -> int

        Retrieves sequence number
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.Buffer) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.Buffer) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """
    @overload
    def setData(self, arg0: list[int]) -> None:
        """setData(*args, **kwargs)
        Overloaded function.

        1. setData(self: depthai.Buffer, arg0: list[int]) -> None

        Parameter ``data``:
            Copies data to internal buffer

        2. setData(self: depthai.Buffer, arg0: numpy.ndarray[numpy.uint8]) -> None

        Parameter ``data``:
            Copies data to internal buffer
        """
    @overload
    def setData(self, arg0: numpy.ndarray[numpy.uint8]) -> None:
        """setData(*args, **kwargs)
        Overloaded function.

        1. setData(self: depthai.Buffer, arg0: list[int]) -> None

        Parameter ``data``:
            Copies data to internal buffer

        2. setData(self: depthai.Buffer, arg0: numpy.ndarray[numpy.uint8]) -> None

        Parameter ``data``:
            Copies data to internal buffer
        """
    def setSequenceNum(self, arg0: int) -> Buffer:
        """setSequenceNum(self: depthai.Buffer, arg0: int) -> depthai.Buffer

        Retrieves sequence number
        """
    def setTimestamp(self, arg0: datetime.timedelta) -> Buffer:
        """setTimestamp(self: depthai.Buffer, arg0: datetime.timedelta) -> depthai.Buffer

        Sets timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> Buffer:
        """setTimestampDevice(self: depthai.Buffer, arg0: datetime.timedelta) -> depthai.Buffer

        Sets timestamp related to dai::Clock::now()
        """

class CalibrationHandler:
    @overload
    def __init__(self) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.CalibrationHandler) -> None

        2. __init__(self: depthai.CalibrationHandler, arg0: Path) -> None

        Construct a new Calibration Handler object using the eeprom json file created
        from calibration procedure.

        Parameter ``eepromDataPath``:
            takes the full path to the json file containing the calibration and device
            info.

        3. __init__(self: depthai.CalibrationHandler, arg0: Path, arg1: Path) -> None

        Construct a new Calibration Handler object using the board config json file and
        .calib binary files created using gen1 calibration.

        Parameter ``calibrationDataPath``:
            Full Path to the .calib binary file from the gen1 calibration. (Supports
            only Version 5)

        Parameter ``boardConfigPath``:
            Full Path to the board config json file containing device information.

        4. __init__(self: depthai.CalibrationHandler, arg0: depthai.EepromData) -> None

        Construct a new Calibration Handler object from EepromData object.

        Parameter ``eepromData``:
            EepromData data structure containing the calibration data.
        """
    @overload
    def __init__(self, arg0: Path) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.CalibrationHandler) -> None

        2. __init__(self: depthai.CalibrationHandler, arg0: Path) -> None

        Construct a new Calibration Handler object using the eeprom json file created
        from calibration procedure.

        Parameter ``eepromDataPath``:
            takes the full path to the json file containing the calibration and device
            info.

        3. __init__(self: depthai.CalibrationHandler, arg0: Path, arg1: Path) -> None

        Construct a new Calibration Handler object using the board config json file and
        .calib binary files created using gen1 calibration.

        Parameter ``calibrationDataPath``:
            Full Path to the .calib binary file from the gen1 calibration. (Supports
            only Version 5)

        Parameter ``boardConfigPath``:
            Full Path to the board config json file containing device information.

        4. __init__(self: depthai.CalibrationHandler, arg0: depthai.EepromData) -> None

        Construct a new Calibration Handler object from EepromData object.

        Parameter ``eepromData``:
            EepromData data structure containing the calibration data.
        """
    @overload
    def __init__(self, arg0: Path, arg1: Path) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.CalibrationHandler) -> None

        2. __init__(self: depthai.CalibrationHandler, arg0: Path) -> None

        Construct a new Calibration Handler object using the eeprom json file created
        from calibration procedure.

        Parameter ``eepromDataPath``:
            takes the full path to the json file containing the calibration and device
            info.

        3. __init__(self: depthai.CalibrationHandler, arg0: Path, arg1: Path) -> None

        Construct a new Calibration Handler object using the board config json file and
        .calib binary files created using gen1 calibration.

        Parameter ``calibrationDataPath``:
            Full Path to the .calib binary file from the gen1 calibration. (Supports
            only Version 5)

        Parameter ``boardConfigPath``:
            Full Path to the board config json file containing device information.

        4. __init__(self: depthai.CalibrationHandler, arg0: depthai.EepromData) -> None

        Construct a new Calibration Handler object from EepromData object.

        Parameter ``eepromData``:
            EepromData data structure containing the calibration data.
        """
    @overload
    def __init__(self, arg0: EepromData) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.CalibrationHandler) -> None

        2. __init__(self: depthai.CalibrationHandler, arg0: Path) -> None

        Construct a new Calibration Handler object using the eeprom json file created
        from calibration procedure.

        Parameter ``eepromDataPath``:
            takes the full path to the json file containing the calibration and device
            info.

        3. __init__(self: depthai.CalibrationHandler, arg0: Path, arg1: Path) -> None

        Construct a new Calibration Handler object using the board config json file and
        .calib binary files created using gen1 calibration.

        Parameter ``calibrationDataPath``:
            Full Path to the .calib binary file from the gen1 calibration. (Supports
            only Version 5)

        Parameter ``boardConfigPath``:
            Full Path to the board config json file containing device information.

        4. __init__(self: depthai.CalibrationHandler, arg0: depthai.EepromData) -> None

        Construct a new Calibration Handler object from EepromData object.

        Parameter ``eepromData``:
            EepromData data structure containing the calibration data.
        """
    def eepromToJson(self) -> json:
        """eepromToJson(self: depthai.CalibrationHandler) -> json

        Get JSON representation of calibration data

        Returns:
            JSON structure
        """
    def eepromToJsonFile(self, destPath: Path) -> bool:
        """eepromToJsonFile(self: depthai.CalibrationHandler, destPath: Path) -> bool

        Write raw calibration/board data to json file.

        Parameter ``destPath``:
            Full path to the json file in which raw calibration data will be stored

        Returns:
            True on success, false otherwise
        """
    @staticmethod
    def fromJson(arg0: json) -> CalibrationHandler:
        """fromJson(arg0: json) -> depthai.CalibrationHandler

        Construct a new Calibration Handler object from JSON EepromData.

        Parameter ``eepromDataJson``:
            EepromData as JSON
        """
    def getBaselineDistance(self, cam1: CameraBoardSocket = ..., cam2: CameraBoardSocket = ..., useSpecTranslation: bool = ...) -> float:
        """getBaselineDistance(self: depthai.CalibrationHandler, cam1: depthai.CameraBoardSocket = <CameraBoardSocket.???: 2>, cam2: depthai.CameraBoardSocket = <CameraBoardSocket.???: 1>, useSpecTranslation: bool = True) -> float

        Get the baseline distance between two specified cameras. By default it will get
        the baseline between CameraBoardSocket.CAM_C and CameraBoardSocket.CAM_B.

        Parameter ``cam1``:
            First camera

        Parameter ``cam2``:
            Second camera

        Parameter ``useSpecTranslation``:
            Enabling this bool uses the translation information from the board design
            data (not the calibration data)

        Returns:
            baseline distance in centimeters
        """
    def getCameraExtrinsics(self, srcCamera: CameraBoardSocket, dstCamera: CameraBoardSocket, useSpecTranslation: bool = ...) -> list[list[float]]:
        """getCameraExtrinsics(self: depthai.CalibrationHandler, srcCamera: depthai.CameraBoardSocket, dstCamera: depthai.CameraBoardSocket, useSpecTranslation: bool = False) -> list[list[float]]

        Get the Camera Extrinsics object between two cameras from the calibration data
        if there is a linked connection between any two cameras then the relative
        rotation and translation (in centimeters) is returned by this function.

        Parameter ``srcCamera``:
            Camera Id of the camera which will be considered as origin.

        Parameter ``dstCamera``:
            Camera Id of the destination camera to which we are fetching the rotation
            and translation from the SrcCamera

        Parameter ``useSpecTranslation``:
            Enabling this bool uses the translation information from the board design
            data

        Returns:
            a transformationMatrix which is 4x4 in homogeneous coordinate system

        Matrix representation of transformation matrix \\f[ \\text{Transformation Matrix}
        = \\left [ \\begin{matrix} r_{00} & r_{01} & r_{02} & T_x \\\\ r_{10} & r_{11} &
        r_{12} & T_y \\\\ r_{20} & r_{21} & r_{22} & T_z \\\\ 0 & 0 & 0 & 1 \\end{matrix}
        \\right ] \\f]
        """
    @overload
    def getCameraIntrinsics(self, cameraId: CameraBoardSocket, resizeWidth: int = ..., resizeHeight: int = ..., topLeftPixelId: Point2f = ..., bottomRightPixelId: Point2f = ..., keepAspectRatio: bool = ...) -> list[list[float]]:
        """getCameraIntrinsics(*args, **kwargs)
        Overloaded function.

        1. getCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, resizeWidth: int = -1, resizeHeight: int = -1, topLeftPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8341b0>, bottomRightPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8b3930>, keepAspectRatio: bool = True) -> list[list[float]]

        Get the Camera Intrinsics object

        Parameter ``cameraId``:
            Uses the cameraId to identify which camera intrinsics to return

        Parameter ``resizewidth``:
            resized width of the image for which intrinsics is requested. resizewidth =
            -1 represents width is same as default intrinsics

        Parameter ``resizeHeight``:
            resized height of the image for which intrinsics is requested. resizeHeight
            = -1 represents height is same as default intrinsics

        Parameter ``topLeftPixelId``:
            (x, y) point represents the top left corner coordinates of the cropped image
            which is used to modify the intrinsics for the respective cropped image

        Parameter ``bottomRightPixelId``:
            (x, y) point represents the bottom right corner coordinates of the cropped
            image which is used to modify the intrinsics for the respective cropped
            image

        Parameter ``keepAspectRatio``:
            Enabling this will scale on width or height depending on which provides the
            max resolution and crops the remaining part of the other side

        Returns:
            Represents the 3x3 intrinsics matrix of the respective camera at the
            requested size and crop dimensions.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        2. getCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, destShape: depthai.Size2f, topLeftPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac816970>, bottomRightPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8900f0>, keepAspectRatio: bool = True) -> list[list[float]]

        Get the Camera Intrinsics object

        Parameter ``cameraId``:
            Uses the cameraId to identify which camera intrinsics to return

        Parameter ``destShape``:
            resized width and height of the image for which intrinsics is requested.

        Parameter ``topLeftPixelId``:
            (x, y) point represents the top left corner coordinates of the cropped image
            which is used to modify the intrinsics for the respective cropped image

        Parameter ``bottomRightPixelId``:
            (x, y) point represents the bottom right corner coordinates of the cropped
            image which is used to modify the intrinsics for the respective cropped
            image

        Parameter ``keepAspectRatio``:
            Enabling this will scale on width or height depending on which provides the
            max resolution and crops the remaining part of the other side

        Returns:
            Represents the 3x3 intrinsics matrix of the respective camera at the
            requested size and crop dimensions.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        3. getCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, destShape: tuple[int, int], topLeftPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac813230>, bottomRightPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8b3b30>, keepAspectRatio: bool = True) -> list[list[float]]

        Get the Camera Intrinsics object

        Parameter ``cameraId``:
            Uses the cameraId to identify which camera intrinsics to return

        Parameter ``destShape``:
            resized width and height of the image for which intrinsics is requested.

        Parameter ``topLeftPixelId``:
            (x, y) point represents the top left corner coordinates of the cropped image
            which is used to modify the intrinsics for the respective cropped image

        Parameter ``bottomRightPixelId``:
            (x, y) point represents the bottom right corner coordinates of the cropped
            image which is used to modify the intrinsics for the respective cropped
            image

        Parameter ``keepAspectRatio``:
            Enabling this will scale on width or height depending on which provides the
            max resolution and crops the remaining part of the other side

        Returns:
            Represents the 3x3 intrinsics matrix of the respective camera at the
            requested size and crop dimensions.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]
        """
    @overload
    def getCameraIntrinsics(self, cameraId: CameraBoardSocket, destShape: Size2f, topLeftPixelId: Point2f = ..., bottomRightPixelId: Point2f = ..., keepAspectRatio: bool = ...) -> list[list[float]]:
        """getCameraIntrinsics(*args, **kwargs)
        Overloaded function.

        1. getCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, resizeWidth: int = -1, resizeHeight: int = -1, topLeftPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8341b0>, bottomRightPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8b3930>, keepAspectRatio: bool = True) -> list[list[float]]

        Get the Camera Intrinsics object

        Parameter ``cameraId``:
            Uses the cameraId to identify which camera intrinsics to return

        Parameter ``resizewidth``:
            resized width of the image for which intrinsics is requested. resizewidth =
            -1 represents width is same as default intrinsics

        Parameter ``resizeHeight``:
            resized height of the image for which intrinsics is requested. resizeHeight
            = -1 represents height is same as default intrinsics

        Parameter ``topLeftPixelId``:
            (x, y) point represents the top left corner coordinates of the cropped image
            which is used to modify the intrinsics for the respective cropped image

        Parameter ``bottomRightPixelId``:
            (x, y) point represents the bottom right corner coordinates of the cropped
            image which is used to modify the intrinsics for the respective cropped
            image

        Parameter ``keepAspectRatio``:
            Enabling this will scale on width or height depending on which provides the
            max resolution and crops the remaining part of the other side

        Returns:
            Represents the 3x3 intrinsics matrix of the respective camera at the
            requested size and crop dimensions.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        2. getCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, destShape: depthai.Size2f, topLeftPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac816970>, bottomRightPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8900f0>, keepAspectRatio: bool = True) -> list[list[float]]

        Get the Camera Intrinsics object

        Parameter ``cameraId``:
            Uses the cameraId to identify which camera intrinsics to return

        Parameter ``destShape``:
            resized width and height of the image for which intrinsics is requested.

        Parameter ``topLeftPixelId``:
            (x, y) point represents the top left corner coordinates of the cropped image
            which is used to modify the intrinsics for the respective cropped image

        Parameter ``bottomRightPixelId``:
            (x, y) point represents the bottom right corner coordinates of the cropped
            image which is used to modify the intrinsics for the respective cropped
            image

        Parameter ``keepAspectRatio``:
            Enabling this will scale on width or height depending on which provides the
            max resolution and crops the remaining part of the other side

        Returns:
            Represents the 3x3 intrinsics matrix of the respective camera at the
            requested size and crop dimensions.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        3. getCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, destShape: tuple[int, int], topLeftPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac813230>, bottomRightPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8b3b30>, keepAspectRatio: bool = True) -> list[list[float]]

        Get the Camera Intrinsics object

        Parameter ``cameraId``:
            Uses the cameraId to identify which camera intrinsics to return

        Parameter ``destShape``:
            resized width and height of the image for which intrinsics is requested.

        Parameter ``topLeftPixelId``:
            (x, y) point represents the top left corner coordinates of the cropped image
            which is used to modify the intrinsics for the respective cropped image

        Parameter ``bottomRightPixelId``:
            (x, y) point represents the bottom right corner coordinates of the cropped
            image which is used to modify the intrinsics for the respective cropped
            image

        Parameter ``keepAspectRatio``:
            Enabling this will scale on width or height depending on which provides the
            max resolution and crops the remaining part of the other side

        Returns:
            Represents the 3x3 intrinsics matrix of the respective camera at the
            requested size and crop dimensions.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]
        """
    @overload
    def getCameraIntrinsics(self, cameraId: CameraBoardSocket, destShape: tuple[int, int], topLeftPixelId: Point2f = ..., bottomRightPixelId: Point2f = ..., keepAspectRatio: bool = ...) -> list[list[float]]:
        """getCameraIntrinsics(*args, **kwargs)
        Overloaded function.

        1. getCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, resizeWidth: int = -1, resizeHeight: int = -1, topLeftPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8341b0>, bottomRightPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8b3930>, keepAspectRatio: bool = True) -> list[list[float]]

        Get the Camera Intrinsics object

        Parameter ``cameraId``:
            Uses the cameraId to identify which camera intrinsics to return

        Parameter ``resizewidth``:
            resized width of the image for which intrinsics is requested. resizewidth =
            -1 represents width is same as default intrinsics

        Parameter ``resizeHeight``:
            resized height of the image for which intrinsics is requested. resizeHeight
            = -1 represents height is same as default intrinsics

        Parameter ``topLeftPixelId``:
            (x, y) point represents the top left corner coordinates of the cropped image
            which is used to modify the intrinsics for the respective cropped image

        Parameter ``bottomRightPixelId``:
            (x, y) point represents the bottom right corner coordinates of the cropped
            image which is used to modify the intrinsics for the respective cropped
            image

        Parameter ``keepAspectRatio``:
            Enabling this will scale on width or height depending on which provides the
            max resolution and crops the remaining part of the other side

        Returns:
            Represents the 3x3 intrinsics matrix of the respective camera at the
            requested size and crop dimensions.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        2. getCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, destShape: depthai.Size2f, topLeftPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac816970>, bottomRightPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8900f0>, keepAspectRatio: bool = True) -> list[list[float]]

        Get the Camera Intrinsics object

        Parameter ``cameraId``:
            Uses the cameraId to identify which camera intrinsics to return

        Parameter ``destShape``:
            resized width and height of the image for which intrinsics is requested.

        Parameter ``topLeftPixelId``:
            (x, y) point represents the top left corner coordinates of the cropped image
            which is used to modify the intrinsics for the respective cropped image

        Parameter ``bottomRightPixelId``:
            (x, y) point represents the bottom right corner coordinates of the cropped
            image which is used to modify the intrinsics for the respective cropped
            image

        Parameter ``keepAspectRatio``:
            Enabling this will scale on width or height depending on which provides the
            max resolution and crops the remaining part of the other side

        Returns:
            Represents the 3x3 intrinsics matrix of the respective camera at the
            requested size and crop dimensions.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        3. getCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, destShape: tuple[int, int], topLeftPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac813230>, bottomRightPixelId: depthai.Point2f = <depthai.Point2f object at 0xffffac8b3b30>, keepAspectRatio: bool = True) -> list[list[float]]

        Get the Camera Intrinsics object

        Parameter ``cameraId``:
            Uses the cameraId to identify which camera intrinsics to return

        Parameter ``destShape``:
            resized width and height of the image for which intrinsics is requested.

        Parameter ``topLeftPixelId``:
            (x, y) point represents the top left corner coordinates of the cropped image
            which is used to modify the intrinsics for the respective cropped image

        Parameter ``bottomRightPixelId``:
            (x, y) point represents the bottom right corner coordinates of the cropped
            image which is used to modify the intrinsics for the respective cropped
            image

        Parameter ``keepAspectRatio``:
            Enabling this will scale on width or height depending on which provides the
            max resolution and crops the remaining part of the other side

        Returns:
            Represents the 3x3 intrinsics matrix of the respective camera at the
            requested size and crop dimensions.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]
        """
    def getCameraToImuExtrinsics(self, cameraId: CameraBoardSocket, useSpecTranslation: bool = ...) -> list[list[float]]:
        """getCameraToImuExtrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, useSpecTranslation: bool = False) -> list[list[float]]

        Get the Camera To Imu Extrinsics object From the data loaded if there is a
        linked connection between IMU and the given camera then there relative rotation
        and translation from the camera to IMU is returned.

        Parameter ``cameraId``:
            Camera Id of the camera which will be considered as origin. from which
            Transformation matrix to the IMU will be found

        Parameter ``useSpecTranslation``:
            Enabling this bool uses the translation information from the board design
            data

        Returns:
            Returns a transformationMatrix which is 4x4 in homogeneous coordinate system

        Matrix representation of transformation matrix \\f[ \\text{Transformation Matrix}
        = \\left [ \\begin{matrix} r_{00} & r_{01} & r_{02} & T_x \\\\ r_{10} & r_{11} &
        r_{12} & T_y \\\\ r_{20} & r_{21} & r_{22} & T_z \\\\ 0 & 0 & 0 & 1 \\end{matrix}
        \\right ] \\f]
        """
    def getCameraTranslationVector(self, srcCamera: CameraBoardSocket, dstCamera: CameraBoardSocket, useSpecTranslation: bool = ...) -> list[float]:
        """getCameraTranslationVector(self: depthai.CalibrationHandler, srcCamera: depthai.CameraBoardSocket, dstCamera: depthai.CameraBoardSocket, useSpecTranslation: bool = True) -> list[float]

        Get the Camera translation vector between two cameras from the calibration data.

        Parameter ``srcCamera``:
            Camera Id of the camera which will be considered as origin.

        Parameter ``dstCamera``:
            Camera Id of the destination camera to which we are fetching the translation
            vector from the SrcCamera

        Parameter ``useSpecTranslation``:
            Disabling this bool uses the translation information from the calibration
            data (not the board design data)

        Returns:
            a translation vector like [x, y, z] in centimeters
        """
    def getDefaultIntrinsics(self, cameraId: CameraBoardSocket) -> tuple[list[list[float]], int, int]:
        """getDefaultIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket) -> tuple[list[list[float]], int, int]

        Get the Default Intrinsics object

        Parameter ``cameraId``:
            Uses the cameraId to identify which camera intrinsics to return

        Returns:
            Represents the 3x3 intrinsics matrix of the respective camera along with
            width and height at which it was calibrated.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]
        """
    def getDistortionCoefficients(self, cameraId: CameraBoardSocket) -> list[float]:
        """getDistortionCoefficients(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket) -> list[float]

        Get the Distortion Coefficients object

        Parameter ``cameraId``:
            Uses the cameraId to identify which distortion Coefficients to return.

        Returns:
            the distortion coefficients of the requested camera in this order:
            [k1,k2,p1,p2,k3,k4,k5,k6,s1,s2,s3,s4,tx,ty] for CameraModel::Perspective or
            [k1, k2, k3, k4] for CameraModel::Fisheye see
            https://docs.opencv.org/4.5.4/d9/d0c/group__calib3d.html for Perspective
            model (Rational Polynomial Model) see
            https://docs.opencv.org/4.5.4/db/d58/group__calib3d__fisheye.html for
            Fisheye model
        """
    def getDistortionModel(self, cameraId: CameraBoardSocket) -> CameraModel:
        """getDistortionModel(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket) -> depthai.CameraModel

        Get the distortion model of the given camera

        Parameter ``cameraId``:
            of the camera with lens position is requested.

        Returns:
            lens position of the camera with given cameraId at which it was calibrated.
        """
    def getEepromData(self) -> EepromData:
        """getEepromData(self: depthai.CalibrationHandler) -> depthai.EepromData

        Get the Eeprom Data object

        Returns:
            EepromData object which contains the raw calibration data
        """
    def getFov(self, cameraId: CameraBoardSocket, useSpec: bool = ...) -> float:
        """getFov(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, useSpec: bool = True) -> float

        Get the Fov of the camera

        Parameter ``cameraId``:
            of the camera of which we are fetching fov.

        Parameter ``useSpec``:
            Disabling this bool will calculate the fov based on intrinsics (focal
            length, image width), instead of getting it from the camera specs

        Returns:
            field of view of the camera with given cameraId.
        """
    def getImuToCameraExtrinsics(self, cameraId: CameraBoardSocket, useSpecTranslation: bool = ...) -> list[list[float]]:
        """getImuToCameraExtrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, useSpecTranslation: bool = False) -> list[list[float]]

        Get the Imu To Camera Extrinsics object from the data loaded if there is a
        linked connection between IMU and the given camera then there relative rotation
        and translation from the IMU to Camera is returned.

        Parameter ``cameraId``:
            Camera Id of the camera which will be considered as destination. To which
            Transformation matrix from the IMU will be found.

        Parameter ``useSpecTranslation``:
            Enabling this bool uses the translation information from the board design
            data

        Returns:
            Returns a transformationMatrix which is 4x4 in homogeneous coordinate system

        Matrix representation of transformation matrix \\f[ \\text{Transformation Matrix}
        = \\left [ \\begin{matrix} r_{00} & r_{01} & r_{02} & T_x \\\\ r_{10} & r_{11} &
        r_{12} & T_y \\\\ r_{20} & r_{21} & r_{22} & T_z \\\\ 0 & 0 & 0 & 1 \\end{matrix}
        \\right ] \\f]
        """
    def getLensPosition(self, cameraId: CameraBoardSocket) -> int:
        """getLensPosition(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket) -> int

        Get the lens position of the given camera

        Parameter ``cameraId``:
            of the camera with lens position is requested.

        Returns:
            lens position of the camera with given cameraId at which it was calibrated.
        """
    def getStereoLeftCameraId(self) -> CameraBoardSocket:
        """getStereoLeftCameraId(self: depthai.CalibrationHandler) -> depthai.CameraBoardSocket

        Get the camera id of the camera which is used as left camera of the stereo setup

        Returns:
            cameraID of the camera used as left camera
        """
    def getStereoLeftRectificationRotation(self) -> list[list[float]]:
        """getStereoLeftRectificationRotation(self: depthai.CalibrationHandler) -> list[list[float]]

        Get the Stereo Left Rectification Rotation object

        Returns:
            returns a 3x3 rectification rotation matrix
        """
    def getStereoRightCameraId(self) -> CameraBoardSocket:
        """getStereoRightCameraId(self: depthai.CalibrationHandler) -> depthai.CameraBoardSocket

        Get the camera id of the camera which is used as right camera of the stereo
        setup

        Returns:
            cameraID of the camera used as right camera
        """
    def getStereoRightRectificationRotation(self) -> list[list[float]]:
        """getStereoRightRectificationRotation(self: depthai.CalibrationHandler) -> list[list[float]]

        Get the Stereo Right Rectification Rotation object

        Returns:
            returns a 3x3 rectification rotation matrix
        """
    @overload
    def setBoardInfo(self, boardName: str, boardRev: str) -> None:
        """setBoardInfo(*args, **kwargs)
        Overloaded function.

        1. setBoardInfo(self: depthai.CalibrationHandler, boardName: str, boardRev: str) -> None

        Set the Board Info object

        Parameter ``version``:
            Sets the version of the Calibration data(Current version is 6)

        Parameter ``boardName``:
            Sets your board name.

        Parameter ``boardRev``:
            set your board revision id.

        2. setBoardInfo(self: depthai.CalibrationHandler, productName: str, boardName: str, boardRev: str, boardConf: str, hardwareConf: str, batchName: str, batchTime: int, boardOptions: int, boardCustom: str = '') -> None

        Set the Board Info object. Creates version 7 EEPROM data

        Parameter ``productName``:
            Sets product name (alias).

        Parameter ``boardName``:
            Sets board name.

        Parameter ``boardRev``:
            Sets board revision id.

        Parameter ``boardConf``:
            Sets board configuration id.

        Parameter ``hardwareConf``:
            Sets hardware configuration id.

        Parameter ``batchName``:
            Sets batch name.

        Parameter ``batchTime``:
            Sets batch time (unix timestamp).

        Parameter ``boardCustom``:
            Sets a custom board (Default empty string).

        3. setBoardInfo(self: depthai.CalibrationHandler, deviceName: str, productName: str, boardName: str, boardRev: str, boardConf: str, hardwareConf: str, batchName: str, batchTime: int, boardOptions: int, boardCustom: str = '') -> None

        Set the Board Info object. Creates version 7 EEPROM data

        Parameter ``deviceName``:
            Sets device name.

        Parameter ``productName``:
            Sets product name (alias).

        Parameter ``boardName``:
            Sets board name.

        Parameter ``boardRev``:
            Sets board revision id.

        Parameter ``boardConf``:
            Sets board configuration id.

        Parameter ``hardwareConf``:
            Sets hardware configuration id.

        Parameter ``batchName``:
            Sets batch name. Not supported anymore

        Parameter ``batchTime``:
            Sets batch time (unix timestamp).

        Parameter ``boardCustom``:
            Sets a custom board (Default empty string).
        """
    @overload
    def setBoardInfo(self, productName: str, boardName: str, boardRev: str, boardConf: str, hardwareConf: str, batchName: str, batchTime: int, boardOptions: int, boardCustom: str = ...) -> None:
        """setBoardInfo(*args, **kwargs)
        Overloaded function.

        1. setBoardInfo(self: depthai.CalibrationHandler, boardName: str, boardRev: str) -> None

        Set the Board Info object

        Parameter ``version``:
            Sets the version of the Calibration data(Current version is 6)

        Parameter ``boardName``:
            Sets your board name.

        Parameter ``boardRev``:
            set your board revision id.

        2. setBoardInfo(self: depthai.CalibrationHandler, productName: str, boardName: str, boardRev: str, boardConf: str, hardwareConf: str, batchName: str, batchTime: int, boardOptions: int, boardCustom: str = '') -> None

        Set the Board Info object. Creates version 7 EEPROM data

        Parameter ``productName``:
            Sets product name (alias).

        Parameter ``boardName``:
            Sets board name.

        Parameter ``boardRev``:
            Sets board revision id.

        Parameter ``boardConf``:
            Sets board configuration id.

        Parameter ``hardwareConf``:
            Sets hardware configuration id.

        Parameter ``batchName``:
            Sets batch name.

        Parameter ``batchTime``:
            Sets batch time (unix timestamp).

        Parameter ``boardCustom``:
            Sets a custom board (Default empty string).

        3. setBoardInfo(self: depthai.CalibrationHandler, deviceName: str, productName: str, boardName: str, boardRev: str, boardConf: str, hardwareConf: str, batchName: str, batchTime: int, boardOptions: int, boardCustom: str = '') -> None

        Set the Board Info object. Creates version 7 EEPROM data

        Parameter ``deviceName``:
            Sets device name.

        Parameter ``productName``:
            Sets product name (alias).

        Parameter ``boardName``:
            Sets board name.

        Parameter ``boardRev``:
            Sets board revision id.

        Parameter ``boardConf``:
            Sets board configuration id.

        Parameter ``hardwareConf``:
            Sets hardware configuration id.

        Parameter ``batchName``:
            Sets batch name. Not supported anymore

        Parameter ``batchTime``:
            Sets batch time (unix timestamp).

        Parameter ``boardCustom``:
            Sets a custom board (Default empty string).
        """
    @overload
    def setBoardInfo(self, deviceName: str, productName: str, boardName: str, boardRev: str, boardConf: str, hardwareConf: str, batchName: str, batchTime: int, boardOptions: int, boardCustom: str = ...) -> None:
        """setBoardInfo(*args, **kwargs)
        Overloaded function.

        1. setBoardInfo(self: depthai.CalibrationHandler, boardName: str, boardRev: str) -> None

        Set the Board Info object

        Parameter ``version``:
            Sets the version of the Calibration data(Current version is 6)

        Parameter ``boardName``:
            Sets your board name.

        Parameter ``boardRev``:
            set your board revision id.

        2. setBoardInfo(self: depthai.CalibrationHandler, productName: str, boardName: str, boardRev: str, boardConf: str, hardwareConf: str, batchName: str, batchTime: int, boardOptions: int, boardCustom: str = '') -> None

        Set the Board Info object. Creates version 7 EEPROM data

        Parameter ``productName``:
            Sets product name (alias).

        Parameter ``boardName``:
            Sets board name.

        Parameter ``boardRev``:
            Sets board revision id.

        Parameter ``boardConf``:
            Sets board configuration id.

        Parameter ``hardwareConf``:
            Sets hardware configuration id.

        Parameter ``batchName``:
            Sets batch name.

        Parameter ``batchTime``:
            Sets batch time (unix timestamp).

        Parameter ``boardCustom``:
            Sets a custom board (Default empty string).

        3. setBoardInfo(self: depthai.CalibrationHandler, deviceName: str, productName: str, boardName: str, boardRev: str, boardConf: str, hardwareConf: str, batchName: str, batchTime: int, boardOptions: int, boardCustom: str = '') -> None

        Set the Board Info object. Creates version 7 EEPROM data

        Parameter ``deviceName``:
            Sets device name.

        Parameter ``productName``:
            Sets product name (alias).

        Parameter ``boardName``:
            Sets board name.

        Parameter ``boardRev``:
            Sets board revision id.

        Parameter ``boardConf``:
            Sets board configuration id.

        Parameter ``hardwareConf``:
            Sets hardware configuration id.

        Parameter ``batchName``:
            Sets batch name. Not supported anymore

        Parameter ``batchTime``:
            Sets batch time (unix timestamp).

        Parameter ``boardCustom``:
            Sets a custom board (Default empty string).
        """
    def setCameraExtrinsics(self, srcCameraId: CameraBoardSocket, destCameraId: CameraBoardSocket, rotationMatrix: list[list[float]], translation: list[float], specTranslation: list[float] = ...) -> None:
        """setCameraExtrinsics(self: depthai.CalibrationHandler, srcCameraId: depthai.CameraBoardSocket, destCameraId: depthai.CameraBoardSocket, rotationMatrix: list[list[float]], translation: list[float], specTranslation: list[float] = [0.0, 0.0, 0.0]) -> None

        Set the Camera Extrinsics object

        Parameter ``srcCameraId``:
            Camera Id of the camera which will be considered as relative origin.

        Parameter ``destCameraId``:
            Camera Id of the camera which will be considered as destination from
            srcCameraId.

        Parameter ``rotationMatrix``:
            Rotation between srcCameraId and destCameraId origins.

        Parameter ``translation``:
            Translation between srcCameraId and destCameraId origins.

        Parameter ``specTranslation``:
            Translation between srcCameraId and destCameraId origins from the design.
        """
    @overload
    def setCameraIntrinsics(self, cameraId: CameraBoardSocket, intrinsics: list[list[float]], frameSize: Size2f) -> None:
        """setCameraIntrinsics(*args, **kwargs)
        Overloaded function.

        1. setCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, intrinsics: list[list[float]], frameSize: depthai.Size2f) -> None

        Set the Camera Intrinsics object

        Parameter ``cameraId``:
            CameraId of the camera for which Camera intrinsics are being loaded

        Parameter ``intrinsics``:
            3x3 intrinsics matrix

        Parameter ``frameSize``:
            Represents the width and height of the image at which intrinsics are
            calculated.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        2. setCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, intrinsics: list[list[float]], width: int, height: int) -> None

        Set the Camera Intrinsics object

        Parameter ``cameraId``:
            CameraId of the camera for which Camera intrinsics are being loaded

        Parameter ``intrinsics``:
            3x3 intrinsics matrix

        Parameter ``width``:
            Represents the width of the image at which intrinsics are calculated.

        Parameter ``height``:
            Represents the height of the image at which intrinsics are calculated.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        3. setCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, intrinsics: list[list[float]], frameSize: tuple[int, int]) -> None

        Set the Camera Intrinsics object

        Parameter ``cameraId``:
            CameraId of the camera for which Camera intrinsics are being loaded

        Parameter ``intrinsics``:
            3x3 intrinsics matrix

        Parameter ``frameSize``:
            Represents the width and height of the image at which intrinsics are
            calculated.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]
        """
    @overload
    def setCameraIntrinsics(self, cameraId: CameraBoardSocket, intrinsics: list[list[float]], width: int, height: int) -> None:
        """setCameraIntrinsics(*args, **kwargs)
        Overloaded function.

        1. setCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, intrinsics: list[list[float]], frameSize: depthai.Size2f) -> None

        Set the Camera Intrinsics object

        Parameter ``cameraId``:
            CameraId of the camera for which Camera intrinsics are being loaded

        Parameter ``intrinsics``:
            3x3 intrinsics matrix

        Parameter ``frameSize``:
            Represents the width and height of the image at which intrinsics are
            calculated.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        2. setCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, intrinsics: list[list[float]], width: int, height: int) -> None

        Set the Camera Intrinsics object

        Parameter ``cameraId``:
            CameraId of the camera for which Camera intrinsics are being loaded

        Parameter ``intrinsics``:
            3x3 intrinsics matrix

        Parameter ``width``:
            Represents the width of the image at which intrinsics are calculated.

        Parameter ``height``:
            Represents the height of the image at which intrinsics are calculated.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        3. setCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, intrinsics: list[list[float]], frameSize: tuple[int, int]) -> None

        Set the Camera Intrinsics object

        Parameter ``cameraId``:
            CameraId of the camera for which Camera intrinsics are being loaded

        Parameter ``intrinsics``:
            3x3 intrinsics matrix

        Parameter ``frameSize``:
            Represents the width and height of the image at which intrinsics are
            calculated.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]
        """
    @overload
    def setCameraIntrinsics(self, cameraId: CameraBoardSocket, intrinsics: list[list[float]], frameSize: tuple[int, int]) -> None:
        """setCameraIntrinsics(*args, **kwargs)
        Overloaded function.

        1. setCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, intrinsics: list[list[float]], frameSize: depthai.Size2f) -> None

        Set the Camera Intrinsics object

        Parameter ``cameraId``:
            CameraId of the camera for which Camera intrinsics are being loaded

        Parameter ``intrinsics``:
            3x3 intrinsics matrix

        Parameter ``frameSize``:
            Represents the width and height of the image at which intrinsics are
            calculated.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        2. setCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, intrinsics: list[list[float]], width: int, height: int) -> None

        Set the Camera Intrinsics object

        Parameter ``cameraId``:
            CameraId of the camera for which Camera intrinsics are being loaded

        Parameter ``intrinsics``:
            3x3 intrinsics matrix

        Parameter ``width``:
            Represents the width of the image at which intrinsics are calculated.

        Parameter ``height``:
            Represents the height of the image at which intrinsics are calculated.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]

        3. setCameraIntrinsics(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, intrinsics: list[list[float]], frameSize: tuple[int, int]) -> None

        Set the Camera Intrinsics object

        Parameter ``cameraId``:
            CameraId of the camera for which Camera intrinsics are being loaded

        Parameter ``intrinsics``:
            3x3 intrinsics matrix

        Parameter ``frameSize``:
            Represents the width and height of the image at which intrinsics are
            calculated.

        Matrix representation of intrinsic matrix \\f[ \\text{Intrinsic Matrix} = \\left [
        \\begin{matrix} f_x & 0 & c_x \\\\ 0 & f_y & c_y \\\\ 0 & 0 & 1 \\end{matrix} \\right ]
        \\f]
        """
    def setCameraType(self, cameraId: CameraBoardSocket, cameraModel: CameraModel) -> None:
        """setCameraType(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, cameraModel: depthai.CameraModel) -> None

        Set the Camera Type object

        Parameter ``cameraId``:
            CameraId of the camera for which cameraModel Type is being updated.

        Parameter ``cameraModel``:
            Type of the model the camera represents
        """
    def setDeviceName(self, deviceName: str) -> None:
        """setDeviceName(self: depthai.CalibrationHandler, deviceName: str) -> None

        Set the deviceName which responses to getDeviceName of Device

        Parameter ``deviceName``:
            Sets device name.
        """
    def setDistortionCoefficients(self, cameraId: CameraBoardSocket, distortionCoefficients: list[float]) -> None:
        """setDistortionCoefficients(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, distortionCoefficients: list[float]) -> None

        Sets the distortion Coefficients obtained from camera calibration

        Parameter ``cameraId``:
            Camera Id of the camera for which distortion coefficients are computed

        Parameter ``distortionCoefficients``:
            Distortion Coefficients of the respective Camera.
        """
    def setFov(self, cameraId: CameraBoardSocket, hfov: float) -> None:
        """setFov(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, hfov: float) -> None

        Set the Fov of the Camera

        Parameter ``cameraId``:
            Camera Id of the camera

        Parameter ``hfov``:
            Horizontal fov of the camera from Camera Datasheet
        """
    def setImuExtrinsics(self, destCameraId: CameraBoardSocket, rotationMatrix: list[list[float]], translation: list[float], specTranslation: list[float] = ...) -> None:
        """setImuExtrinsics(self: depthai.CalibrationHandler, destCameraId: depthai.CameraBoardSocket, rotationMatrix: list[list[float]], translation: list[float], specTranslation: list[float] = [0.0, 0.0, 0.0]) -> None

        Set the Imu to Camera Extrinsics object

        Parameter ``destCameraId``:
            Camera Id of the camera which will be considered as destination from IMU.

        Parameter ``rotationMatrix``:
            Rotation between srcCameraId and destCameraId origins.

        Parameter ``translation``:
            Translation between IMU and destCameraId origins.

        Parameter ``specTranslation``:
            Translation between IMU and destCameraId origins from the design.
        """
    def setLensPosition(self, cameraId: CameraBoardSocket, lensPosition: int) -> None:
        """setLensPosition(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, lensPosition: int) -> None

        Sets the distortion Coefficients obtained from camera calibration

        Parameter ``cameraId``:
            Camera Id of the camera

        Parameter ``lensPosition``:
            lens posiotion value of the camera at the time of calibration
        """
    def setProductName(self, productName: str) -> None:
        """setProductName(self: depthai.CalibrationHandler, productName: str) -> None

        Set the productName which acts as alisas for users to identify the device

        Parameter ``productName``:
            Sets product name (alias).
        """
    def setStereoLeft(self, cameraId: CameraBoardSocket, rectifiedRotation: list[list[float]]) -> None:
        """setStereoLeft(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, rectifiedRotation: list[list[float]]) -> None

        Set the Stereo Left Rectification object

        Parameter ``cameraId``:
            CameraId of the camera which will be used as left Camera of stereo Setup

        Parameter ``rectifiedRotation``:
            Rectification rotation of the left camera required for feature matching

        Homography of the Left Rectification = Intrinsics_right * rectifiedRotation *
        inv(Intrinsics_left)
        """
    def setStereoRight(self, cameraId: CameraBoardSocket, rectifiedRotation: list[list[float]]) -> None:
        """setStereoRight(self: depthai.CalibrationHandler, cameraId: depthai.CameraBoardSocket, rectifiedRotation: list[list[float]]) -> None

        Set the Stereo Right Rectification object

        Parameter ``cameraId``:
            CameraId of the camera which will be used as left Camera of stereo Setup

        Parameter ``rectifiedRotation``:
            Rectification rotation of the left camera required for feature matching

        Homography of the Right Rectification = Intrinsics_right * rectifiedRotation *
        inv(Intrinsics_right)
        """

class CameraBoardSocket:
    CENTER: ClassVar[CameraBoardSocket] = ...  # read-only
    LEFT: ClassVar[CameraBoardSocket] = ...  # read-only
    RGB: ClassVar[CameraBoardSocket] = ...  # read-only
    RIGHT: ClassVar[CameraBoardSocket] = ...  # read-only
    __members__: ClassVar[dict] = ...  # read-only
    AUTO: ClassVar[CameraBoardSocket] = ...
    CAM_A: ClassVar[CameraBoardSocket] = ...
    CAM_B: ClassVar[CameraBoardSocket] = ...
    CAM_C: ClassVar[CameraBoardSocket] = ...
    CAM_D: ClassVar[CameraBoardSocket] = ...
    CAM_E: ClassVar[CameraBoardSocket] = ...
    CAM_F: ClassVar[CameraBoardSocket] = ...
    CAM_G: ClassVar[CameraBoardSocket] = ...
    CAM_H: ClassVar[CameraBoardSocket] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.CameraBoardSocket, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.CameraBoardSocket) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.CameraBoardSocket) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class CameraControl(Buffer):
    class AntiBandingMode:
        __members__: ClassVar[dict] = ...  # read-only
        AUTO: ClassVar[RawCameraControl.AntiBandingMode] = ...
        MAINS_50_HZ: ClassVar[RawCameraControl.AntiBandingMode] = ...
        MAINS_60_HZ: ClassVar[RawCameraControl.AntiBandingMode] = ...
        OFF: ClassVar[RawCameraControl.AntiBandingMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.AntiBandingMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.AntiBandingMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.AntiBandingMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class AutoFocusMode:
        __members__: ClassVar[dict] = ...  # read-only
        AUTO: ClassVar[RawCameraControl.AutoFocusMode] = ...
        CONTINUOUS_PICTURE: ClassVar[RawCameraControl.AutoFocusMode] = ...
        CONTINUOUS_VIDEO: ClassVar[RawCameraControl.AutoFocusMode] = ...
        EDOF: ClassVar[RawCameraControl.AutoFocusMode] = ...
        MACRO: ClassVar[RawCameraControl.AutoFocusMode] = ...
        OFF: ClassVar[RawCameraControl.AutoFocusMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.AutoFocusMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.AutoFocusMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.AutoFocusMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class AutoWhiteBalanceMode:
        __members__: ClassVar[dict] = ...  # read-only
        AUTO: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        CLOUDY_DAYLIGHT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        DAYLIGHT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        FLUORESCENT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        INCANDESCENT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        OFF: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        SHADE: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        TWILIGHT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        WARM_FLUORESCENT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.AutoWhiteBalanceMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.AutoWhiteBalanceMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.AutoWhiteBalanceMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class CaptureIntent:
        __members__: ClassVar[dict] = ...  # read-only
        CUSTOM: ClassVar[RawCameraControl.CaptureIntent] = ...
        PREVIEW: ClassVar[RawCameraControl.CaptureIntent] = ...
        STILL_CAPTURE: ClassVar[RawCameraControl.CaptureIntent] = ...
        VIDEO_RECORD: ClassVar[RawCameraControl.CaptureIntent] = ...
        VIDEO_SNAPSHOT: ClassVar[RawCameraControl.CaptureIntent] = ...
        ZERO_SHUTTER_LAG: ClassVar[RawCameraControl.CaptureIntent] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.CaptureIntent, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.CaptureIntent) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.CaptureIntent) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class Command:
        __members__: ClassVar[dict] = ...  # read-only
        AE_AUTO: ClassVar[RawCameraControl.Command] = ...
        AE_LOCK: ClassVar[RawCameraControl.Command] = ...
        AE_MANUAL: ClassVar[RawCameraControl.Command] = ...
        AE_REGION: ClassVar[RawCameraControl.Command] = ...
        AE_TARGET_FPS_RANGE: ClassVar[RawCameraControl.Command] = ...
        AF_MODE: ClassVar[RawCameraControl.Command] = ...
        AF_REGION: ClassVar[RawCameraControl.Command] = ...
        AF_TRIGGER: ClassVar[RawCameraControl.Command] = ...
        ANTIBANDING_MODE: ClassVar[RawCameraControl.Command] = ...
        AWB_LOCK: ClassVar[RawCameraControl.Command] = ...
        AWB_MODE: ClassVar[RawCameraControl.Command] = ...
        BRIGHTNESS: ClassVar[RawCameraControl.Command] = ...
        CAPTURE_INTENT: ClassVar[RawCameraControl.Command] = ...
        CHROMA_DENOISE: ClassVar[RawCameraControl.Command] = ...
        CONTRAST: ClassVar[RawCameraControl.Command] = ...
        CONTROL_MODE: ClassVar[RawCameraControl.Command] = ...
        CUSTOM_CAPTURE: ClassVar[RawCameraControl.Command] = ...
        CUSTOM_CAPT_MODE: ClassVar[RawCameraControl.Command] = ...
        CUSTOM_EXP_BRACKETS: ClassVar[RawCameraControl.Command] = ...
        CUSTOM_USECASE: ClassVar[RawCameraControl.Command] = ...
        EFFECT_MODE: ClassVar[RawCameraControl.Command] = ...
        EXPOSURE_COMPENSATION: ClassVar[RawCameraControl.Command] = ...
        FRAME_DURATION: ClassVar[RawCameraControl.Command] = ...
        LUMA_DENOISE: ClassVar[RawCameraControl.Command] = ...
        MOVE_LENS: ClassVar[RawCameraControl.Command] = ...
        NOISE_REDUCTION_STRENGTH: ClassVar[RawCameraControl.Command] = ...
        RESOLUTION: ClassVar[RawCameraControl.Command] = ...
        SATURATION: ClassVar[RawCameraControl.Command] = ...
        SCENE_MODE: ClassVar[RawCameraControl.Command] = ...
        SENSITIVITY: ClassVar[RawCameraControl.Command] = ...
        SHARPNESS: ClassVar[RawCameraControl.Command] = ...
        START_STREAM: ClassVar[RawCameraControl.Command] = ...
        STILL_CAPTURE: ClassVar[RawCameraControl.Command] = ...
        STOP_STREAM: ClassVar[RawCameraControl.Command] = ...
        STREAM_FORMAT: ClassVar[RawCameraControl.Command] = ...
        WB_COLOR_TEMP: ClassVar[RawCameraControl.Command] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.Command, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.Command) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.Command) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class ControlMode:
        __members__: ClassVar[dict] = ...  # read-only
        AUTO: ClassVar[RawCameraControl.ControlMode] = ...
        OFF: ClassVar[RawCameraControl.ControlMode] = ...
        USE_SCENE_MODE: ClassVar[RawCameraControl.ControlMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.ControlMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.ControlMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.ControlMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class EffectMode:
        __members__: ClassVar[dict] = ...  # read-only
        AQUA: ClassVar[RawCameraControl.EffectMode] = ...
        BLACKBOARD: ClassVar[RawCameraControl.EffectMode] = ...
        MONO: ClassVar[RawCameraControl.EffectMode] = ...
        NEGATIVE: ClassVar[RawCameraControl.EffectMode] = ...
        OFF: ClassVar[RawCameraControl.EffectMode] = ...
        POSTERIZE: ClassVar[RawCameraControl.EffectMode] = ...
        SEPIA: ClassVar[RawCameraControl.EffectMode] = ...
        SOLARIZE: ClassVar[RawCameraControl.EffectMode] = ...
        WHITEBOARD: ClassVar[RawCameraControl.EffectMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.EffectMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.EffectMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.EffectMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class FrameSyncMode:
        __members__: ClassVar[dict] = ...  # read-only
        INPUT: ClassVar[RawCameraControl.FrameSyncMode] = ...
        OFF: ClassVar[RawCameraControl.FrameSyncMode] = ...
        OUTPUT: ClassVar[RawCameraControl.FrameSyncMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.FrameSyncMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.FrameSyncMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.FrameSyncMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class SceneMode:
        __members__: ClassVar[dict] = ...  # read-only
        ACTION: ClassVar[RawCameraControl.SceneMode] = ...
        BARCODE: ClassVar[RawCameraControl.SceneMode] = ...
        BEACH: ClassVar[RawCameraControl.SceneMode] = ...
        CANDLELIGHT: ClassVar[RawCameraControl.SceneMode] = ...
        FACE_PRIORITY: ClassVar[RawCameraControl.SceneMode] = ...
        FIREWORKS: ClassVar[RawCameraControl.SceneMode] = ...
        LANDSCAPE: ClassVar[RawCameraControl.SceneMode] = ...
        NIGHT: ClassVar[RawCameraControl.SceneMode] = ...
        NIGHT_PORTRAIT: ClassVar[RawCameraControl.SceneMode] = ...
        PARTY: ClassVar[RawCameraControl.SceneMode] = ...
        PORTRAIT: ClassVar[RawCameraControl.SceneMode] = ...
        SNOW: ClassVar[RawCameraControl.SceneMode] = ...
        SPORTS: ClassVar[RawCameraControl.SceneMode] = ...
        STEADYPHOTO: ClassVar[RawCameraControl.SceneMode] = ...
        SUNSET: ClassVar[RawCameraControl.SceneMode] = ...
        THEATRE: ClassVar[RawCameraControl.SceneMode] = ...
        UNSUPPORTED: ClassVar[RawCameraControl.SceneMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.SceneMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.SceneMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.SceneMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    def __init__(self) -> None:
        """__init__(self: depthai.CameraControl) -> None

        Construct CameraControl message
        """
    def clearMiscControls(self) -> None:
        """clearMiscControls(self: depthai.CameraControl) -> None

        Clear the list of miscellaneous controls set by `setControl`
        """
    def get(self) -> RawCameraControl:
        """get(self: depthai.CameraControl) -> depthai.RawCameraControl

        Retrieve configuration data for CameraControl.

        Returns:
            config for CameraControl
        """
    def getCaptureStill(self) -> bool:
        """getCaptureStill(self: depthai.CameraControl) -> bool

        Check whether command to capture a still is set

        Returns:
            True if capture still command is set
        """
    def getExposureTime(self) -> datetime.timedelta:
        """getExposureTime(self: depthai.CameraControl) -> datetime.timedelta

        Retrieves exposure time
        """
    def getLensPosition(self) -> int:
        """getLensPosition(self: depthai.CameraControl) -> int

        Retrieves lens position, range 0..255. Returns -1 if not available
        """
    def getLensPositionRaw(self) -> float:
        """getLensPositionRaw(self: depthai.CameraControl) -> float

        Retrieves lens position, range 0.0f..1.0f.
        """
    def getMiscControls(self) -> list[tuple[str, str]]:
        """getMiscControls(self: depthai.CameraControl) -> list[tuple[str, str]]

        Get the list of miscellaneous controls set by `setControl`

        Returns:
            A list of <key, value> pairs as strings
        """
    def getSensitivity(self) -> int:
        """getSensitivity(self: depthai.CameraControl) -> int

        Retrieves sensitivity, as an ISO value
        """
    def set(self, config: RawCameraControl) -> CameraControl:
        """set(self: depthai.CameraControl, config: depthai.RawCameraControl) -> depthai.CameraControl

        Set explicit configuration.

        Parameter ``config``:
            Explicit configuration
        """
    def setAntiBandingMode(self, mode: RawCameraControl.AntiBandingMode) -> CameraControl:
        """setAntiBandingMode(self: depthai.CameraControl, mode: depthai.RawCameraControl.AntiBandingMode) -> depthai.CameraControl

        Set a command to specify anti-banding mode. Anti-banding / anti-flicker works in
        auto-exposure mode, by controlling the exposure time to be applied in multiples
        of half the mains period, for example in multiple of 10ms for 50Hz (period 20ms)
        AC-powered illumination sources.

        If the scene would be too bright for the smallest exposure step (10ms in the
        example, with ISO at a minimum of 100), anti-banding is not effective.

        Parameter ``mode``:
            Anti-banding mode to use. Default: `MAINS_50_HZ`
        """
    def setAutoExposureCompensation(self, compensation: int) -> CameraControl:
        """setAutoExposureCompensation(self: depthai.CameraControl, compensation: int) -> depthai.CameraControl

        Set a command to specify auto exposure compensation

        Parameter ``compensation``:
            Compensation value between -9..9, default 0
        """
    def setAutoExposureEnable(self) -> CameraControl:
        """setAutoExposureEnable(self: depthai.CameraControl) -> depthai.CameraControl

        Set a command to enable auto exposure
        """
    @overload
    def setAutoExposureLimit(self, maxExposureTimeUs: int) -> CameraControl:
        """setAutoExposureLimit(*args, **kwargs)
        Overloaded function.

        1. setAutoExposureLimit(self: depthai.CameraControl, maxExposureTimeUs: int) -> depthai.CameraControl

        Set a command to specify the maximum exposure time limit for auto-exposure. By
        default the AE algorithm prioritizes increasing exposure over ISO, up to around
        frame-time (subject to further limits imposed by anti-banding)

        Parameter ``maxExposureTimeUs``:
            Maximum exposure time in microseconds

        2. setAutoExposureLimit(self: depthai.CameraControl, maxExposureTime: datetime.timedelta) -> depthai.CameraControl

        Set a command to specify the maximum exposure time limit for auto-exposure. By
        default the AE algorithm prioritizes increasing exposure over ISO, up to around
        frame-time (subject to further limits imposed by anti-banding)

        Parameter ``maxExposureTime``:
            Maximum exposure time
        """
    @overload
    def setAutoExposureLimit(self, maxExposureTime: datetime.timedelta) -> CameraControl:
        """setAutoExposureLimit(*args, **kwargs)
        Overloaded function.

        1. setAutoExposureLimit(self: depthai.CameraControl, maxExposureTimeUs: int) -> depthai.CameraControl

        Set a command to specify the maximum exposure time limit for auto-exposure. By
        default the AE algorithm prioritizes increasing exposure over ISO, up to around
        frame-time (subject to further limits imposed by anti-banding)

        Parameter ``maxExposureTimeUs``:
            Maximum exposure time in microseconds

        2. setAutoExposureLimit(self: depthai.CameraControl, maxExposureTime: datetime.timedelta) -> depthai.CameraControl

        Set a command to specify the maximum exposure time limit for auto-exposure. By
        default the AE algorithm prioritizes increasing exposure over ISO, up to around
        frame-time (subject to further limits imposed by anti-banding)

        Parameter ``maxExposureTime``:
            Maximum exposure time
        """
    def setAutoExposureLock(self, lock: bool) -> CameraControl:
        """setAutoExposureLock(self: depthai.CameraControl, lock: bool) -> depthai.CameraControl

        Set a command to specify lock auto exposure

        Parameter ``lock``:
            Auto exposure lock mode enabled or disabled
        """
    def setAutoExposureRegion(self, startX: int, startY: int, width: int, height: int) -> CameraControl:
        """setAutoExposureRegion(self: depthai.CameraControl, startX: int, startY: int, width: int, height: int) -> depthai.CameraControl

        Set a command to specify auto exposure region in pixels. Note: the region should
        be mapped to the configured sensor resolution, before ISP scaling

        Parameter ``startX``:
            X coordinate of top left corner of region

        Parameter ``startY``:
            Y coordinate of top left corner of region

        Parameter ``width``:
            Region width

        Parameter ``height``:
            Region height
        """
    def setAutoFocusLensRange(self, infinityPosition: int, macroPosition: int) -> CameraControl:
        """setAutoFocusLensRange(self: depthai.CameraControl, infinityPosition: int, macroPosition: int) -> depthai.CameraControl

        Set autofocus lens range, `infinityPosition < macroPosition`, valid values
        `0..255`. May help to improve autofocus in case the lens adjustment is not
        typical/tuned
        """
    def setAutoFocusMode(self, mode: RawCameraControl.AutoFocusMode) -> CameraControl:
        """setAutoFocusMode(self: depthai.CameraControl, mode: depthai.RawCameraControl.AutoFocusMode) -> depthai.CameraControl

        Set a command to specify autofocus mode. Default `CONTINUOUS_VIDEO`
        """
    def setAutoFocusRegion(self, startX: int, startY: int, width: int, height: int) -> CameraControl:
        """setAutoFocusRegion(self: depthai.CameraControl, startX: int, startY: int, width: int, height: int) -> depthai.CameraControl

        Set a command to specify focus region in pixels. Note: the region should be
        mapped to the configured sensor resolution, before ISP scaling

        Parameter ``startX``:
            X coordinate of top left corner of region

        Parameter ``startY``:
            Y coordinate of top left corner of region

        Parameter ``width``:
            Region width

        Parameter ``height``:
            Region height
        """
    def setAutoFocusTrigger(self) -> CameraControl:
        """setAutoFocusTrigger(self: depthai.CameraControl) -> depthai.CameraControl

        Set a command to trigger autofocus
        """
    def setAutoWhiteBalanceLock(self, lock: bool) -> CameraControl:
        """setAutoWhiteBalanceLock(self: depthai.CameraControl, lock: bool) -> depthai.CameraControl

        Set a command to specify auto white balance lock

        Parameter ``lock``:
            Auto white balance lock mode enabled or disabled
        """
    def setAutoWhiteBalanceMode(self, mode: RawCameraControl.AutoWhiteBalanceMode) -> CameraControl:
        """setAutoWhiteBalanceMode(self: depthai.CameraControl, mode: depthai.RawCameraControl.AutoWhiteBalanceMode) -> depthai.CameraControl

        Set a command to specify auto white balance mode

        Parameter ``mode``:
            Auto white balance mode to use. Default `AUTO`
        """
    def setBrightness(self, value: int) -> CameraControl:
        """setBrightness(self: depthai.CameraControl, value: int) -> depthai.CameraControl

        Set a command to adjust image brightness

        Parameter ``value``:
            Brightness, range -10..10, default 0
        """
    def setCaptureIntent(self, mode: RawCameraControl.CaptureIntent) -> CameraControl:
        """setCaptureIntent(self: depthai.CameraControl, mode: depthai.RawCameraControl.CaptureIntent) -> depthai.CameraControl

        Set a command to specify capture intent mode

        Parameter ``mode``:
            Capture intent mode
        """
    def setCaptureStill(self, capture: bool) -> CameraControl:
        """setCaptureStill(self: depthai.CameraControl, capture: bool) -> depthai.CameraControl

        Set a command to capture a still image
        """
    def setChromaDenoise(self, value: int) -> CameraControl:
        """setChromaDenoise(self: depthai.CameraControl, value: int) -> depthai.CameraControl

        Set a command to adjust chroma denoise amount

        Parameter ``value``:
            Chroma denoise amount, range 0..4, default 1
        """
    def setContrast(self, value: int) -> CameraControl:
        """setContrast(self: depthai.CameraControl, value: int) -> depthai.CameraControl

        Set a command to adjust image contrast

        Parameter ``value``:
            Contrast, range -10..10, default 0
        """
    def setControlMode(self, mode: RawCameraControl.ControlMode) -> CameraControl:
        """setControlMode(self: depthai.CameraControl, mode: depthai.RawCameraControl.ControlMode) -> depthai.CameraControl

        Set a command to specify control mode

        Parameter ``mode``:
            Control mode
        """
    def setEffectMode(self, mode: RawCameraControl.EffectMode) -> CameraControl:
        """setEffectMode(self: depthai.CameraControl, mode: depthai.RawCameraControl.EffectMode) -> depthai.CameraControl

        Set a command to specify effect mode

        Parameter ``mode``:
            Effect mode
        """
    def setExternalTrigger(self, numFramesBurst: int, numFramesDiscard: int) -> CameraControl:
        """setExternalTrigger(self: depthai.CameraControl, numFramesBurst: int, numFramesDiscard: int) -> depthai.CameraControl

        Set a command to enable external trigger snapshot mode

        A rising edge on the sensor FSIN pin will make it capture a sequence of
        `numFramesBurst` frames. First `numFramesDiscard` will be skipped as configured
        (can be set to 0 as well), as they may have degraded quality
        """
    def setFrameSyncMode(self, mode: RawCameraControl.FrameSyncMode) -> CameraControl:
        """setFrameSyncMode(self: depthai.CameraControl, mode: depthai.RawCameraControl.FrameSyncMode) -> depthai.CameraControl

        Set the frame sync mode for continuous streaming operation mode, translating to
        how the camera pin FSIN/FSYNC is used: input/output/disabled
        """
    def setLumaDenoise(self, value: int) -> CameraControl:
        """setLumaDenoise(self: depthai.CameraControl, value: int) -> depthai.CameraControl

        Set a command to adjust luma denoise amount

        Parameter ``value``:
            Luma denoise amount, range 0..4, default 1
        """
    @overload
    def setManualExposure(self, exposureTimeUs: int, sensitivityIso: int) -> CameraControl:
        """setManualExposure(*args, **kwargs)
        Overloaded function.

        1. setManualExposure(self: depthai.CameraControl, exposureTimeUs: int, sensitivityIso: int) -> depthai.CameraControl

        Set a command to manually specify exposure

        Parameter ``exposureTimeUs``:
            Exposure time in microseconds

        Parameter ``sensitivityIso``:
            Sensitivity as ISO value, usual range 100..1600

        2. setManualExposure(self: depthai.CameraControl, exposureTime: datetime.timedelta, sensitivityIso: int) -> depthai.CameraControl

        Set a command to manually specify exposure

        Parameter ``exposureTime``:
            Exposure time

        Parameter ``sensitivityIso``:
            Sensitivity as ISO value, usual range 100..1600
        """
    @overload
    def setManualExposure(self, exposureTime: datetime.timedelta, sensitivityIso: int) -> CameraControl:
        """setManualExposure(*args, **kwargs)
        Overloaded function.

        1. setManualExposure(self: depthai.CameraControl, exposureTimeUs: int, sensitivityIso: int) -> depthai.CameraControl

        Set a command to manually specify exposure

        Parameter ``exposureTimeUs``:
            Exposure time in microseconds

        Parameter ``sensitivityIso``:
            Sensitivity as ISO value, usual range 100..1600

        2. setManualExposure(self: depthai.CameraControl, exposureTime: datetime.timedelta, sensitivityIso: int) -> depthai.CameraControl

        Set a command to manually specify exposure

        Parameter ``exposureTime``:
            Exposure time

        Parameter ``sensitivityIso``:
            Sensitivity as ISO value, usual range 100..1600
        """
    def setManualFocus(self, lensPosition: int) -> CameraControl:
        """setManualFocus(self: depthai.CameraControl, lensPosition: int) -> depthai.CameraControl

        Set a command to specify manual focus position

        Parameter ``lensPosition``:
            specify lens position 0..255
        """
    def setManualFocusRaw(self, lensPositionRaw: float) -> CameraControl:
        """setManualFocusRaw(self: depthai.CameraControl, lensPositionRaw: float) -> depthai.CameraControl

        Set a command to specify manual focus position (more precise control).

        Parameter ``lensPositionRaw``:
            specify lens position 0.0f .. 1.0f

        Returns:
            CameraControl&
        """
    def setManualWhiteBalance(self, colorTemperatureK: int) -> CameraControl:
        """setManualWhiteBalance(self: depthai.CameraControl, colorTemperatureK: int) -> depthai.CameraControl

        Set a command to manually specify white-balance color correction

        Parameter ``colorTemperatureK``:
            Light source color temperature in kelvins, range 1000..12000
        """
    @overload
    def setMisc(self, control: str, value: str) -> CameraControl:
        """setMisc(*args, **kwargs)
        Overloaded function.

        1. setMisc(self: depthai.CameraControl, control: str, value: str) -> depthai.CameraControl

        Set a miscellaneous control. The controls set by this function get appended to a
        list, processed after the standard controls

        Parameter ``control``:
            Control name

        Parameter ``value``:
            Value as a string

        2. setMisc(self: depthai.CameraControl, control: str, value: int) -> depthai.CameraControl

        Set a miscellaneous control. The controls set by this function get appended to a
        list, processed after the standard controls

        Parameter ``control``:
            Control name

        Parameter ``value``:
            Value as an integer number

        3. setMisc(self: depthai.CameraControl, control: str, value: float) -> depthai.CameraControl

        Set a miscellaneous control. The controls set by this function get appended to a
        list, processed after the standard controls

        Parameter ``control``:
            Control name

        Parameter ``value``:
            Value as a floating point number
        """
    @overload
    def setMisc(self, control: str, value: int) -> CameraControl:
        """setMisc(*args, **kwargs)
        Overloaded function.

        1. setMisc(self: depthai.CameraControl, control: str, value: str) -> depthai.CameraControl

        Set a miscellaneous control. The controls set by this function get appended to a
        list, processed after the standard controls

        Parameter ``control``:
            Control name

        Parameter ``value``:
            Value as a string

        2. setMisc(self: depthai.CameraControl, control: str, value: int) -> depthai.CameraControl

        Set a miscellaneous control. The controls set by this function get appended to a
        list, processed after the standard controls

        Parameter ``control``:
            Control name

        Parameter ``value``:
            Value as an integer number

        3. setMisc(self: depthai.CameraControl, control: str, value: float) -> depthai.CameraControl

        Set a miscellaneous control. The controls set by this function get appended to a
        list, processed after the standard controls

        Parameter ``control``:
            Control name

        Parameter ``value``:
            Value as a floating point number
        """
    @overload
    def setMisc(self, control: str, value: float) -> CameraControl:
        """setMisc(*args, **kwargs)
        Overloaded function.

        1. setMisc(self: depthai.CameraControl, control: str, value: str) -> depthai.CameraControl

        Set a miscellaneous control. The controls set by this function get appended to a
        list, processed after the standard controls

        Parameter ``control``:
            Control name

        Parameter ``value``:
            Value as a string

        2. setMisc(self: depthai.CameraControl, control: str, value: int) -> depthai.CameraControl

        Set a miscellaneous control. The controls set by this function get appended to a
        list, processed after the standard controls

        Parameter ``control``:
            Control name

        Parameter ``value``:
            Value as an integer number

        3. setMisc(self: depthai.CameraControl, control: str, value: float) -> depthai.CameraControl

        Set a miscellaneous control. The controls set by this function get appended to a
        list, processed after the standard controls

        Parameter ``control``:
            Control name

        Parameter ``value``:
            Value as a floating point number
        """
    def setSaturation(self, value: int) -> CameraControl:
        """setSaturation(self: depthai.CameraControl, value: int) -> depthai.CameraControl

        Set a command to adjust image saturation

        Parameter ``value``:
            Saturation, range -10..10, default 0
        """
    def setSceneMode(self, mode: RawCameraControl.SceneMode) -> CameraControl:
        """setSceneMode(self: depthai.CameraControl, mode: depthai.RawCameraControl.SceneMode) -> depthai.CameraControl

        Set a command to specify scene mode

        Parameter ``mode``:
            Scene mode
        """
    def setSharpness(self, value: int) -> CameraControl:
        """setSharpness(self: depthai.CameraControl, value: int) -> depthai.CameraControl

        Set a command to adjust image sharpness

        Parameter ``value``:
            Sharpness, range 0..4, default 1
        """
    def setStartStreaming(self) -> CameraControl:
        """setStartStreaming(self: depthai.CameraControl) -> depthai.CameraControl

        Set a command to start streaming
        """
    def setStopStreaming(self) -> CameraControl:
        """setStopStreaming(self: depthai.CameraControl) -> depthai.CameraControl

        Set a command to stop streaming
        """
    def setStrobeDisable(self) -> CameraControl:
        """setStrobeDisable(self: depthai.CameraControl) -> depthai.CameraControl

        Disable STROBE output
        """
    def setStrobeExternal(self, gpioNumber: int, activeLevel: int) -> CameraControl:
        """setStrobeExternal(self: depthai.CameraControl, gpioNumber: int, activeLevel: int) -> depthai.CameraControl

        Enable STROBE output driven by a MyriadX GPIO, optionally configuring the
        polarity This normally requires a FSIN/FSYNC/trigger input for MyriadX (usually
        GPIO 41), to generate timings
        """
    def setStrobeSensor(self, activeLevel: int) -> CameraControl:
        """setStrobeSensor(self: depthai.CameraControl, activeLevel: int) -> depthai.CameraControl

        Enable STROBE output on sensor pin, optionally configuring the polarity. Note:
        for many sensors the polarity is high-active and not configurable
        """

class CameraExposureOffset:
    __members__: ClassVar[dict] = ...  # read-only
    END: ClassVar[CameraExposureOffset] = ...
    MIDDLE: ClassVar[CameraExposureOffset] = ...
    START: ClassVar[CameraExposureOffset] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.CameraExposureOffset, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.CameraExposureOffset) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.CameraExposureOffset) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class CameraFeatures:
    calibrationResolution: CameraSensorConfig | None
    configs: list[CameraSensorConfig]
    hasAutofocus: bool
    hasAutofocusIC: bool
    height: int
    name: str
    orientation: CameraImageOrientation
    sensorName: str
    socket: CameraBoardSocket
    supportedTypes: list[CameraSensorType]
    width: int
    def __init__(self) -> None:
        """__init__(self: depthai.CameraFeatures) -> None"""

class CameraImageOrientation:
    __members__: ClassVar[dict] = ...  # read-only
    AUTO: ClassVar[CameraImageOrientation] = ...
    HORIZONTAL_MIRROR: ClassVar[CameraImageOrientation] = ...
    NORMAL: ClassVar[CameraImageOrientation] = ...
    ROTATE_180_DEG: ClassVar[CameraImageOrientation] = ...
    VERTICAL_FLIP: ClassVar[CameraImageOrientation] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.CameraImageOrientation, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.CameraImageOrientation) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.CameraImageOrientation) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class CameraInfo:
    cameraType: CameraModel
    distortionCoeff: list[float]
    extrinsics: Extrinsics
    height: int
    intrinsicMatrix: list[list[float]]
    specHfovDeg: float
    width: int
    def __init__(self) -> None:
        """__init__(self: depthai.CameraInfo) -> None"""

class CameraModel:
    __members__: ClassVar[dict] = ...  # read-only
    Equirectangular: ClassVar[CameraModel] = ...
    Fisheye: ClassVar[CameraModel] = ...
    Perspective: ClassVar[CameraModel] = ...
    RadialDivision: ClassVar[CameraModel] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.CameraModel, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.CameraModel) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.CameraModel) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class CameraProperties:
    class ColorOrder:
        __members__: ClassVar[dict] = ...  # read-only
        BGR: ClassVar[CameraProperties.ColorOrder] = ...
        RGB: ClassVar[CameraProperties.ColorOrder] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.CameraProperties.ColorOrder, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.CameraProperties.ColorOrder) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.CameraProperties.ColorOrder) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class WarpMeshSource:
        __members__: ClassVar[dict] = ...  # read-only
        AUTO: ClassVar[CameraProperties.WarpMeshSource] = ...
        CALIBRATION: ClassVar[CameraProperties.WarpMeshSource] = ...
        NONE: ClassVar[CameraProperties.WarpMeshSource] = ...
        URI: ClassVar[CameraProperties.WarpMeshSource] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.CameraProperties.WarpMeshSource, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.CameraProperties.WarpMeshSource) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.CameraProperties.WarpMeshSource) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    boardSocket: CameraBoardSocket
    calibAlpha: float | None
    cameraName: str
    colorOrder: CameraProperties.ColorOrder
    fp16: bool
    fps: float
    imageOrientation: CameraImageOrientation
    initialControl: RawCameraControl
    interleaved: bool
    isp3aFps: int
    ispScale: Incomplete
    numFramesPoolIsp: int
    numFramesPoolPreview: int
    numFramesPoolRaw: int
    numFramesPoolStill: int
    numFramesPoolVideo: int
    previewHeight: int
    previewKeepAspectRatio: bool
    previewWidth: int
    rawPacked: bool | None
    resolutionHeight: int
    resolutionWidth: int
    sensorCropX: float
    sensorCropY: float
    sensorType: CameraSensorType
    stillHeight: int
    stillWidth: int
    videoHeight: int
    videoWidth: int
    warpMeshHeight: int
    warpMeshSource: CameraProperties.WarpMeshSource
    warpMeshStepHeight: int
    warpMeshStepWidth: int
    warpMeshUri: str
    warpMeshWidth: int
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class CameraSensorConfig:
    fov: Rect
    height: int
    maxFps: float
    minFps: float
    type: CameraSensorType
    width: int
    def __init__(self) -> None:
        """__init__(self: depthai.CameraSensorConfig) -> None"""

class CameraSensorType:
    __members__: ClassVar[dict] = ...  # read-only
    COLOR: ClassVar[CameraSensorType] = ...
    MONO: ClassVar[CameraSensorType] = ...
    THERMAL: ClassVar[CameraSensorType] = ...
    TOF: ClassVar[CameraSensorType] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.CameraSensorType, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.CameraSensorType) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.CameraSensorType) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class CastProperties:
    numFramesPool: int
    offset: float | None
    outputType: RawImgFrame.Type
    scale: float | None
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class ChipTemperature:
    average: float
    css: float
    dss: float
    mss: float
    upa: float
    def __init__(self) -> None:
        """__init__(self: depthai.ChipTemperature) -> None"""

class Clock:
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""
    def now(self) -> datetime.timedelta:
        """now() -> datetime.timedelta"""

class ColorCameraProperties:
    class ColorOrder:
        __members__: ClassVar[dict] = ...  # read-only
        BGR: ClassVar[ColorCameraProperties.ColorOrder] = ...
        RGB: ClassVar[ColorCameraProperties.ColorOrder] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.ColorCameraProperties.ColorOrder, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.ColorCameraProperties.ColorOrder) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.ColorCameraProperties.ColorOrder) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class SensorResolution:
        __members__: ClassVar[dict] = ...  # read-only
        THE_1080_P: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_1200_P: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_12_MP: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_1352X1012: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_13_MP: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_1440X1080: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_2024X1520: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_4000X3000: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_48_MP: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_4_K: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_5312X6000: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_5_MP: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_720_P: ClassVar[ColorCameraProperties.SensorResolution] = ...
        THE_800_P: ClassVar[ColorCameraProperties.SensorResolution] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.ColorCameraProperties.SensorResolution, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.ColorCameraProperties.SensorResolution) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.ColorCameraProperties.SensorResolution) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    boardSocket: CameraBoardSocket
    colorOrder: ColorCameraProperties.ColorOrder
    eventFilter: list[FrameEvent]
    fp16: bool
    fps: float
    imageOrientation: CameraImageOrientation
    initialControl: RawCameraControl
    interleaved: bool
    isp3aFps: int
    ispScale: Incomplete
    numFramesPoolIsp: int
    numFramesPoolPreview: int
    numFramesPoolRaw: int
    numFramesPoolStill: int
    numFramesPoolVideo: int
    previewHeight: int
    previewKeepAspectRatio: bool
    previewWidth: int
    resolution: ColorCameraProperties.SensorResolution
    sensorCropX: float
    sensorCropY: float
    stillHeight: int
    stillWidth: int
    videoHeight: int
    videoWidth: int
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class Colormap:
    __members__: ClassVar[dict] = ...  # read-only
    JET: ClassVar[Colormap] = ...
    NONE: ClassVar[Colormap] = ...
    STEREO_JET: ClassVar[Colormap] = ...
    STEREO_TURBO: ClassVar[Colormap] = ...
    TURBO: ClassVar[Colormap] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.Colormap, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.Colormap) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.Colormap) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class CpuUsage:
    average: float
    msTime: int
    def __init__(self) -> None:
        """__init__(self: depthai.CpuUsage) -> None"""

class CrashDump:
    class CrashReport:
        class ErrorSourceInfo:
            class AssertContext:
                fileName: str
                functionName: str
                line: int
                def __init__(self) -> None:
                    """__init__(self: depthai.CrashDump.CrashReport.ErrorSourceInfo.AssertContext) -> None"""

            class TrapContext:
                trapAddress: int
                trapName: str
                trapNumber: int
                def __init__(self) -> None:
                    """__init__(self: depthai.CrashDump.CrashReport.ErrorSourceInfo.TrapContext) -> None"""
            assertContext: CrashDump.CrashReport.ErrorSourceInfo.AssertContext
            errorId: int
            trapContext: CrashDump.CrashReport.ErrorSourceInfo.TrapContext
            def __init__(self) -> None:
                """__init__(self: depthai.CrashDump.CrashReport.ErrorSourceInfo) -> None"""

        class ThreadCallstack:
            class CallstackContext:
                callSite: int
                calledTarget: int
                context: str
                framePointer: int
                def __init__(self) -> None:
                    """__init__(self: depthai.CrashDump.CrashReport.ThreadCallstack.CallstackContext) -> None"""
            callStack: list[CrashDump.CrashReport.ThreadCallstack.CallstackContext]
            instructionPointer: int
            stackBottom: int
            stackPointer: int
            stackTop: int
            threadId: int
            threadName: str
            threadStatus: str
            def __init__(self) -> None:
                """__init__(self: depthai.CrashDump.CrashReport.ThreadCallstack) -> None"""
        crashedThreadId: int
        errorSource: str
        processor: ProcessorType
        threadCallstack: list[CrashDump.CrashReport.ThreadCallstack]
        def __init__(self) -> None:
            """__init__(self: depthai.CrashDump.CrashReport) -> None"""
    crashReports: list[CrashDump.CrashReport]
    depthaiCommitHash: str
    deviceId: str
    def __init__(self) -> None:
        """__init__(self: depthai.CrashDump) -> None"""
    def serializeToJson(self) -> json:
        """serializeToJson(self: depthai.CrashDump) -> json"""

class DataInputQueue:
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""
    def close(self) -> None:
        """close(self: depthai.DataInputQueue) -> None

        Closes the queue and the underlying thread
        """
    def getBlocking(self) -> bool:
        """getBlocking(self: depthai.DataInputQueue) -> bool

        Gets current queue behavior when full (maxSize)

        Returns:
            True if blocking, false otherwise
        """
    def getMaxSize(self) -> int:
        """getMaxSize(self: depthai.DataInputQueue) -> int

        Gets queue maximum size

        Returns:
            Maximum queue size
        """
    def getName(self) -> str:
        """getName(self: depthai.DataInputQueue) -> str

        Gets queues name

        Returns:
            Queue name
        """
    def isClosed(self) -> bool:
        """isClosed(self: depthai.DataInputQueue) -> bool

        Check whether queue is closed

        .. warning::
            This function is thread-unsafe and may return outdated incorrect values. It
            is only meant for use in simple single-threaded code. Well written code
            should handle exceptions when calling any DepthAI apis to handle hardware
            events and multithreaded use.
        """
    @overload
    def send(self, msg: ADatatype) -> None:
        """send(*args, **kwargs)
        Overloaded function.

        1. send(self: depthai.DataInputQueue, msg: depthai.ADatatype) -> None

        Adds a message to the queue, which will be picked up and sent to the device. Can
        either block if 'blocking' behavior is true or overwrite oldest

        Parameter ``msg``:
            Message to add to the queue

        2. send(self: depthai.DataInputQueue, rawMsg: depthai.RawBuffer) -> None

        Adds a raw message to the queue, which will be picked up and sent to the device.
        Can either block if 'blocking' behavior is true or overwrite oldest

        Parameter ``rawMsg``:
            Message to add to the queue
        """
    @overload
    def send(self, rawMsg: RawBuffer) -> None:
        """send(*args, **kwargs)
        Overloaded function.

        1. send(self: depthai.DataInputQueue, msg: depthai.ADatatype) -> None

        Adds a message to the queue, which will be picked up and sent to the device. Can
        either block if 'blocking' behavior is true or overwrite oldest

        Parameter ``msg``:
            Message to add to the queue

        2. send(self: depthai.DataInputQueue, rawMsg: depthai.RawBuffer) -> None

        Adds a raw message to the queue, which will be picked up and sent to the device.
        Can either block if 'blocking' behavior is true or overwrite oldest

        Parameter ``rawMsg``:
            Message to add to the queue
        """
    def setBlocking(self, blocking: bool) -> None:
        """setBlocking(self: depthai.DataInputQueue, blocking: bool) -> None

        Sets queue behavior when full (maxSize)

        Parameter ``blocking``:
            Specifies if block or overwrite the oldest message in the queue
        """
    def setMaxSize(self, maxSize: int) -> None:
        """setMaxSize(self: depthai.DataInputQueue, maxSize: int) -> None

        Sets queue maximum size

        Parameter ``maxSize``:
            Specifies maximum number of messages in the queue
        """

class DataOutputQueue:
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""
    @overload
    def addCallback(self, callback: Callable) -> int:
        """addCallback(*args, **kwargs)
        Overloaded function.

        1. addCallback(self: depthai.DataOutputQueue, callback: Callable) -> int

        Adds a callback on message received

        Parameter ``callback``:
            Callback function with queue name and message pointer

        Returns:
            Callback id

        2. addCallback(self: depthai.DataOutputQueue, callback: Callable) -> int

        Adds a callback on message received

        Parameter ``callback``:
            Callback function with message pointer

        Returns:
            Callback id

        3. addCallback(self: depthai.DataOutputQueue, callback: Callable) -> int

        Adds a callback on message received

        Parameter ``callback``:
            Callback function without any parameters

        Returns:
            Callback id
        """
    @overload
    def addCallback(self, callback: Callable) -> int:
        """addCallback(*args, **kwargs)
        Overloaded function.

        1. addCallback(self: depthai.DataOutputQueue, callback: Callable) -> int

        Adds a callback on message received

        Parameter ``callback``:
            Callback function with queue name and message pointer

        Returns:
            Callback id

        2. addCallback(self: depthai.DataOutputQueue, callback: Callable) -> int

        Adds a callback on message received

        Parameter ``callback``:
            Callback function with message pointer

        Returns:
            Callback id

        3. addCallback(self: depthai.DataOutputQueue, callback: Callable) -> int

        Adds a callback on message received

        Parameter ``callback``:
            Callback function without any parameters

        Returns:
            Callback id
        """
    @overload
    def addCallback(self, callback: Callable) -> int:
        """addCallback(*args, **kwargs)
        Overloaded function.

        1. addCallback(self: depthai.DataOutputQueue, callback: Callable) -> int

        Adds a callback on message received

        Parameter ``callback``:
            Callback function with queue name and message pointer

        Returns:
            Callback id

        2. addCallback(self: depthai.DataOutputQueue, callback: Callable) -> int

        Adds a callback on message received

        Parameter ``callback``:
            Callback function with message pointer

        Returns:
            Callback id

        3. addCallback(self: depthai.DataOutputQueue, callback: Callable) -> int

        Adds a callback on message received

        Parameter ``callback``:
            Callback function without any parameters

        Returns:
            Callback id
        """
    def close(self) -> None:
        """close(self: depthai.DataOutputQueue) -> None

        Closes the queue and the underlying thread
        """
    def get(self) -> ADatatype:
        """get(self: depthai.DataOutputQueue) -> depthai.ADatatype

        Block until a message is available.

        Returns:
            Message or nullptr if no message available
        """
    def getAll(self) -> list[ADatatype]:
        """getAll(self: depthai.DataOutputQueue) -> list[depthai.ADatatype]

        Block until at least one message in the queue. Then return all messages from the
        queue.

        Returns:
            Vector of messages
        """
    def getBlocking(self) -> bool:
        """getBlocking(self: depthai.DataOutputQueue) -> bool

        Gets current queue behavior when full (maxSize)

        Returns:
            True if blocking, false otherwise
        """
    def getMaxSize(self) -> int:
        """getMaxSize(self: depthai.DataOutputQueue) -> int

        Gets queue maximum size

        Returns:
            Maximum queue size
        """
    def getName(self) -> str:
        """getName(self: depthai.DataOutputQueue) -> str

        Gets queues name

        Returns:
            Queue name
        """
    def has(self) -> bool:
        """has(self: depthai.DataOutputQueue) -> bool

        Check whether front of the queue has a message (isn't empty)

        Returns:
            True if queue isn't empty, false otherwise
        """
    def isClosed(self) -> bool:
        """isClosed(self: depthai.DataOutputQueue) -> bool

        Check whether queue is closed

        .. warning::
            This function is thread-unsafe and may return outdated incorrect values. It
            is only meant for use in simple single-threaded code. Well written code
            should handle exceptions when calling any DepthAI apis to handle hardware
            events and multithreaded use.
        """
    def removeCallback(self, callbackId: int) -> bool:
        """removeCallback(self: depthai.DataOutputQueue, callbackId: int) -> bool

        Removes a callback

        Parameter ``callbackId``:
            Id of callback to be removed

        Returns:
            True if callback was removed, false otherwise
        """
    def setBlocking(self, blocking: bool) -> None:
        """setBlocking(self: depthai.DataOutputQueue, blocking: bool) -> None

        Sets queue behavior when full (maxSize)

        Parameter ``blocking``:
            Specifies if block or overwrite the oldest message in the queue
        """
    def setMaxSize(self, maxSize: int) -> None:
        """setMaxSize(self: depthai.DataOutputQueue, maxSize: int) -> None

        Sets queue maximum size

        Parameter ``maxSize``:
            Specifies maximum number of messages in the queue
        """
    def tryGet(self) -> ADatatype:
        """tryGet(self: depthai.DataOutputQueue) -> depthai.ADatatype

        Try to retrieve message from queue. If no message available, return immediately
        with nullptr

        Returns:
            Message or nullptr if no message available
        """
    def tryGetAll(self) -> list[ADatatype]:
        """tryGetAll(self: depthai.DataOutputQueue) -> list[depthai.ADatatype]

        Try to retrieve all messages in the queue.

        Returns:
            Vector of messages
        """

class DatatypeEnum:
    __members__: ClassVar[dict] = ...  # read-only
    AprilTagConfig: ClassVar[DatatypeEnum] = ...
    AprilTags: ClassVar[DatatypeEnum] = ...
    Buffer: ClassVar[DatatypeEnum] = ...
    CameraControl: ClassVar[DatatypeEnum] = ...
    EdgeDetectorConfig: ClassVar[DatatypeEnum] = ...
    EncodedFrame: ClassVar[DatatypeEnum] = ...
    FeatureTrackerConfig: ClassVar[DatatypeEnum] = ...
    IMUData: ClassVar[DatatypeEnum] = ...
    ImageManipConfig: ClassVar[DatatypeEnum] = ...
    ImgDetections: ClassVar[DatatypeEnum] = ...
    ImgFrame: ClassVar[DatatypeEnum] = ...
    NNData: ClassVar[DatatypeEnum] = ...
    PointCloudConfig: ClassVar[DatatypeEnum] = ...
    PointCloudData: ClassVar[DatatypeEnum] = ...
    SpatialImgDetections: ClassVar[DatatypeEnum] = ...
    SpatialLocationCalculatorConfig: ClassVar[DatatypeEnum] = ...
    SpatialLocationCalculatorData: ClassVar[DatatypeEnum] = ...
    StereoDepthConfig: ClassVar[DatatypeEnum] = ...
    SystemInformation: ClassVar[DatatypeEnum] = ...
    TrackedFeatures: ClassVar[DatatypeEnum] = ...
    Tracklets: ClassVar[DatatypeEnum] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.DatatypeEnum, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.DatatypeEnum) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.DatatypeEnum) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class DetectionNetworkProperties(NeuralNetworkProperties):
    parser: DetectionParserOptions
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class DetectionNetworkType:
    __members__: ClassVar[dict] = ...  # read-only
    MOBILENET: ClassVar[DetectionNetworkType] = ...
    YOLO: ClassVar[DetectionNetworkType] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.DetectionNetworkType, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.DetectionNetworkType) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.DetectionNetworkType) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class DetectionParserOptions:
    anchorMasks: dict[str, list[int]]
    anchors: list[float]
    classes: int
    confidenceThreshold: float
    coordinates: int
    iouThreshold: float
    nnFamily: DetectionNetworkType
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class DetectionParserProperties:
    parser: DetectionParserOptions
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class Device(DeviceBase):
    class Config:
        board: BoardConfig
        logLevel: LogLevel | None
        nonExclusiveMode: bool
        outputLogLevel: LogLevel | None
        version: OpenVINO.Version
        def __init__(self) -> None:
            """__init__(self: depthai.Device.Config) -> None"""
    @overload
    def __init__(self, pipeline: Pipeline) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, usb2Mode: bool) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, pathToCmd: Path) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, devInfo: DeviceInfo, usb2Mode: bool = ...) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, deviceInfo: DeviceInfo, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, devInfo: DeviceInfo, pathToCmd: Path) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, deviceInfo: DeviceInfo) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version = ...) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, usb2Mode: bool = ...) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, pathToCmd: Path) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, deviceInfo: DeviceInfo, usb2Mode: bool = ...) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, deviceInfo: DeviceInfo, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, deviceDesc: DeviceInfo, pathToCmd: Path) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, config: Device.Config) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, config: Device.Config, deviceInfo: DeviceInfo) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, deviceInfo: DeviceInfo) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, deviceInfo: DeviceInfo, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, nameOrDeviceId: str) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, nameOrDeviceId: str, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Device, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.Device, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.Device, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.Device, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.Device, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.Device, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.Device, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.Device, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.Device, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.Device, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.Device, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.Device, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.Device, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def getInputQueue(self, name: str) -> DataInputQueue:
        """getInputQueue(*args, **kwargs)
        Overloaded function.

        1. getInputQueue(self: depthai.Device, name: str) -> depthai.DataInputQueue

        Gets an input queue corresponding to stream name. If it doesn't exist it throws

        Parameter ``name``:
            Queue/stream name, set in XLinkIn node

        Returns:
            Smart pointer to DataInputQueue

        2. getInputQueue(self: depthai.Device, name: str, maxSize: int, blocking: bool = True) -> depthai.DataInputQueue

        Gets an input queue corresponding to stream name. If it doesn't exist it throws.
        Also sets queue options

        Parameter ``name``:
            Queue/stream name, set in XLinkIn node

        Parameter ``maxSize``:
            Maximum number of messages in queue

        Parameter ``blocking``:
            Queue behavior once full. True: blocking, false: overwriting of oldest
            messages. Default: true

        Returns:
            Smart pointer to DataInputQueue
        """
    @overload
    def getInputQueue(self, name: str, maxSize: int, blocking: bool = ...) -> DataInputQueue:
        """getInputQueue(*args, **kwargs)
        Overloaded function.

        1. getInputQueue(self: depthai.Device, name: str) -> depthai.DataInputQueue

        Gets an input queue corresponding to stream name. If it doesn't exist it throws

        Parameter ``name``:
            Queue/stream name, set in XLinkIn node

        Returns:
            Smart pointer to DataInputQueue

        2. getInputQueue(self: depthai.Device, name: str, maxSize: int, blocking: bool = True) -> depthai.DataInputQueue

        Gets an input queue corresponding to stream name. If it doesn't exist it throws.
        Also sets queue options

        Parameter ``name``:
            Queue/stream name, set in XLinkIn node

        Parameter ``maxSize``:
            Maximum number of messages in queue

        Parameter ``blocking``:
            Queue behavior once full. True: blocking, false: overwriting of oldest
            messages. Default: true

        Returns:
            Smart pointer to DataInputQueue
        """
    def getInputQueueNames(self) -> list[str]:
        """getInputQueueNames(self: depthai.Device) -> list[str]

        Get all available input queue names

        Returns:
            Vector of input queue names
        """
    @overload
    def getOutputQueue(self, name: str) -> DataOutputQueue:
        """getOutputQueue(*args, **kwargs)
        Overloaded function.

        1. getOutputQueue(self: depthai.Device, name: str) -> depthai.DataOutputQueue

        Gets an output queue corresponding to stream name. If it doesn't exist it throws

        Parameter ``name``:
            Queue/stream name, created by XLinkOut node

        Returns:
            Smart pointer to DataOutputQueue

        2. getOutputQueue(self: depthai.Device, name: str, maxSize: int, blocking: bool = True) -> depthai.DataOutputQueue

        Gets a queue corresponding to stream name, if it exists, otherwise it throws.
        Also sets queue options

        Parameter ``name``:
            Queue/stream name, set in XLinkOut node

        Parameter ``maxSize``:
            Maximum number of messages in queue

        Parameter ``blocking``:
            Queue behavior once full. True specifies blocking and false overwriting of
            oldest messages. Default: true

        Returns:
            Smart pointer to DataOutputQueue
        """
    @overload
    def getOutputQueue(self, name: str, maxSize: int, blocking: bool = ...) -> DataOutputQueue:
        """getOutputQueue(*args, **kwargs)
        Overloaded function.

        1. getOutputQueue(self: depthai.Device, name: str) -> depthai.DataOutputQueue

        Gets an output queue corresponding to stream name. If it doesn't exist it throws

        Parameter ``name``:
            Queue/stream name, created by XLinkOut node

        Returns:
            Smart pointer to DataOutputQueue

        2. getOutputQueue(self: depthai.Device, name: str, maxSize: int, blocking: bool = True) -> depthai.DataOutputQueue

        Gets a queue corresponding to stream name, if it exists, otherwise it throws.
        Also sets queue options

        Parameter ``name``:
            Queue/stream name, set in XLinkOut node

        Parameter ``maxSize``:
            Maximum number of messages in queue

        Parameter ``blocking``:
            Queue behavior once full. True specifies blocking and false overwriting of
            oldest messages. Default: true

        Returns:
            Smart pointer to DataOutputQueue
        """
    def getOutputQueueNames(self) -> list[str]:
        """getOutputQueueNames(self: depthai.Device) -> list[str]

        Get all available output queue names

        Returns:
            Vector of output queue names
        """
    @overload
    def getQueueEvent(self, queueNames: list[str], timeout: datetime.timedelta = ...) -> str:
        """getQueueEvent(*args, **kwargs)
        Overloaded function.

        1. getQueueEvent(self: depthai.Device, queueNames: list[str], timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> str

        Gets or waits until any of specified queues has received a message

        Parameter ``queueNames``:
            Names of queues for which to wait for

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Queue name which received a message first

        2. getQueueEvent(self: depthai.Device, queueName: str, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> str

        Gets or waits until specified queue has received a message

        Parameter ``queueNames``:
            Name of queues for which to wait for

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Queue name which received a message

        3. getQueueEvent(self: depthai.Device, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> str

        Gets or waits until any queue has received a message

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Queue name which received a message
        """
    @overload
    def getQueueEvent(self, queueName: str, timeout: datetime.timedelta = ...) -> str:
        """getQueueEvent(*args, **kwargs)
        Overloaded function.

        1. getQueueEvent(self: depthai.Device, queueNames: list[str], timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> str

        Gets or waits until any of specified queues has received a message

        Parameter ``queueNames``:
            Names of queues for which to wait for

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Queue name which received a message first

        2. getQueueEvent(self: depthai.Device, queueName: str, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> str

        Gets or waits until specified queue has received a message

        Parameter ``queueNames``:
            Name of queues for which to wait for

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Queue name which received a message

        3. getQueueEvent(self: depthai.Device, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> str

        Gets or waits until any queue has received a message

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Queue name which received a message
        """
    @overload
    def getQueueEvent(self, timeout: datetime.timedelta = ...) -> str:
        """getQueueEvent(*args, **kwargs)
        Overloaded function.

        1. getQueueEvent(self: depthai.Device, queueNames: list[str], timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> str

        Gets or waits until any of specified queues has received a message

        Parameter ``queueNames``:
            Names of queues for which to wait for

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Queue name which received a message first

        2. getQueueEvent(self: depthai.Device, queueName: str, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> str

        Gets or waits until specified queue has received a message

        Parameter ``queueNames``:
            Name of queues for which to wait for

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Queue name which received a message

        3. getQueueEvent(self: depthai.Device, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> str

        Gets or waits until any queue has received a message

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Queue name which received a message
        """
    @overload
    def getQueueEvents(self, queueNames: list[str], maxNumEvents: int = ..., timeout: datetime.timedelta = ...) -> list[str]:
        """getQueueEvents(*args, **kwargs)
        Overloaded function.

        1. getQueueEvents(self: depthai.Device, queueNames: list[str], maxNumEvents: int = 18446744073709551615, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> list[str]

        Gets or waits until any of specified queues has received a message

        Parameter ``queueNames``:
            Names of queues for which to block

        Parameter ``maxNumEvents``:
            Maximum number of events to remove from queue - Default is unlimited

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite -
            Default is -1

        Returns:
            Names of queues which received messages first

        2. getQueueEvents(self: depthai.Device, queueName: str, maxNumEvents: int = 18446744073709551615, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> list[str]

        Gets or waits until specified queue has received a message

        Parameter ``queueName``:
            Name of queues for which to wait for

        Parameter ``maxNumEvents``:
            Maximum number of events to remove from queue. Default is unlimited

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Names of queues which received messages first

        3. getQueueEvents(self: depthai.Device, maxNumEvents: int = 18446744073709551615, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> list[str]

        Gets or waits until any queue has received a message

        Parameter ``maxNumEvents``:
            Maximum number of events to remove from queue. Default is unlimited

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Names of queues which received messages first
        """
    @overload
    def getQueueEvents(self, queueName: str, maxNumEvents: int = ..., timeout: datetime.timedelta = ...) -> list[str]:
        """getQueueEvents(*args, **kwargs)
        Overloaded function.

        1. getQueueEvents(self: depthai.Device, queueNames: list[str], maxNumEvents: int = 18446744073709551615, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> list[str]

        Gets or waits until any of specified queues has received a message

        Parameter ``queueNames``:
            Names of queues for which to block

        Parameter ``maxNumEvents``:
            Maximum number of events to remove from queue - Default is unlimited

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite -
            Default is -1

        Returns:
            Names of queues which received messages first

        2. getQueueEvents(self: depthai.Device, queueName: str, maxNumEvents: int = 18446744073709551615, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> list[str]

        Gets or waits until specified queue has received a message

        Parameter ``queueName``:
            Name of queues for which to wait for

        Parameter ``maxNumEvents``:
            Maximum number of events to remove from queue. Default is unlimited

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Names of queues which received messages first

        3. getQueueEvents(self: depthai.Device, maxNumEvents: int = 18446744073709551615, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> list[str]

        Gets or waits until any queue has received a message

        Parameter ``maxNumEvents``:
            Maximum number of events to remove from queue. Default is unlimited

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Names of queues which received messages first
        """
    @overload
    def getQueueEvents(self, maxNumEvents: int = ..., timeout: datetime.timedelta = ...) -> list[str]:
        """getQueueEvents(*args, **kwargs)
        Overloaded function.

        1. getQueueEvents(self: depthai.Device, queueNames: list[str], maxNumEvents: int = 18446744073709551615, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> list[str]

        Gets or waits until any of specified queues has received a message

        Parameter ``queueNames``:
            Names of queues for which to block

        Parameter ``maxNumEvents``:
            Maximum number of events to remove from queue - Default is unlimited

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite -
            Default is -1

        Returns:
            Names of queues which received messages first

        2. getQueueEvents(self: depthai.Device, queueName: str, maxNumEvents: int = 18446744073709551615, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> list[str]

        Gets or waits until specified queue has received a message

        Parameter ``queueName``:
            Name of queues for which to wait for

        Parameter ``maxNumEvents``:
            Maximum number of events to remove from queue. Default is unlimited

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Names of queues which received messages first

        3. getQueueEvents(self: depthai.Device, maxNumEvents: int = 18446744073709551615, timeout: datetime.timedelta = datetime.timedelta(days=-1, seconds=86399, microseconds=999999)) -> list[str]

        Gets or waits until any queue has received a message

        Parameter ``maxNumEvents``:
            Maximum number of events to remove from queue. Default is unlimited

        Parameter ``timeout``:
            Timeout after which return regardless. If negative then wait is indefinite.
            Default is -1

        Returns:
            Names of queues which received messages first
        """
    def __enter__(self) -> Device:
        """__enter__(self: depthai.Device) -> depthai.Device"""

class DeviceBase:
    @overload
    def __init__(self, pipeline: Pipeline) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, usb2Mode: bool) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, pathToCmd: Path) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, devInfo: DeviceInfo, usb2Mode: bool = ...) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, deviceInfo: DeviceInfo, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, devInfo: DeviceInfo, pathToCmd: Path) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, pipeline: Pipeline, deviceInfo: DeviceInfo) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version = ...) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, usb2Mode: bool = ...) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, pathToCmd: Path) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, deviceInfo: DeviceInfo, usb2Mode: bool = ...) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, deviceInfo: DeviceInfo, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, version: OpenVINO.Version, deviceDesc: DeviceInfo, pathToCmd: Path) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, config: Device.Config) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, config: Device.Config, deviceInfo: DeviceInfo) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, deviceInfo: DeviceInfo) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, deviceInfo: DeviceInfo, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, nameOrDeviceId: str) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    @overload
    def __init__(self, nameOrDeviceId: str, maxUsbSpeed: UsbSpeed) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        2. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, usb2Mode: bool) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        3. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        4. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``pathToCmd``:
            Path to custom device firmware

        5. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        6. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        7. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, devInfo: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``pipeline``:
            Pipeline to be executed on the device

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        8. __init__(self: depthai.DeviceBase, pipeline: depthai.Pipeline, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        9. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version = <Version.???: 7>) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with.

        10. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, usb2Mode: bool = False) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        11. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        12. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, pathToCmd: Path) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``pathToCmd``:
            Path to custom device firmware

        13. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, usb2Mode: bool = False) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``usb2Mode``:
            Boot device using USB2 mode firmware

        14. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        15. __init__(self: depthai.DeviceBase, version: depthai.OpenVINO.Version, deviceDesc: depthai.DeviceInfo, pathToCmd: Path) -> None

        Connects to device specified by devInfo.

        Parameter ``version``:
            OpenVINO version which the device will be booted with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``pathToCmd``:
            Path to custom device firmware

        16. __init__(self: depthai.DeviceBase, config: depthai.Device.Config) -> None

        Connects to any available device with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        17. __init__(self: depthai.DeviceBase, config: depthai.Device.Config, deviceInfo: depthai.DeviceInfo) -> None

        Connects to device 'devInfo' with custom config.

        Parameter ``config``:
            Device custom configuration to boot with

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        18. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        19. __init__(self: depthai.DeviceBase, deviceInfo: depthai.DeviceInfo, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``devInfo``:
            DeviceInfo which specifies which device to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed

        20. __init__(self: depthai.DeviceBase, nameOrDeviceId: str) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        21. __init__(self: depthai.DeviceBase, nameOrDeviceId: str, maxUsbSpeed: depthai.UsbSpeed) -> None

        Connects to any available device with a DEFAULT_SEARCH_TIME timeout. Uses
        OpenVINO version OpenVINO::VERSION_UNIVERSAL

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``maxUsbSpeed``:
            Maximum allowed USB speed
        """
    def addLogCallback(self, callback: Callable[[LogMessage], None]) -> int:
        """addLogCallback(self: depthai.DeviceBase, callback: Callable[[depthai.LogMessage], None]) -> int

        Add a callback for device logging. The callback will be called from a separate
        thread with the LogMessage being passed.

        Parameter ``callback``:
            Callback to call whenever a log message arrives

        Returns:
            Id which can be used to later remove the callback
        """
    def close(self) -> None:
        """close(self: depthai.DeviceBase) -> None

        Closes the connection to device. Better alternative is the usage of context manager: `with depthai.Device(pipeline) as device:`
        """
    def factoryResetCalibration(self) -> None:
        """factoryResetCalibration(self: depthai.DeviceBase) -> None

        Factory reset EEPROM data if factory backup is available.

        Throws:
            std::runtime_exception If factory reset was unsuccessful
        """
    def flashCalibration(self, calibrationDataHandler: CalibrationHandler) -> bool:
        """flashCalibration(self: depthai.DeviceBase, calibrationDataHandler: depthai.CalibrationHandler) -> bool

        Stores the Calibration and Device information to the Device EEPROM

        Parameter ``calibrationObj``:
            CalibrationHandler object which is loaded with calibration information.

        Returns:
            true on successful flash, false on failure
        """
    def flashCalibration2(self, arg0: CalibrationHandler) -> None:
        """flashCalibration2(self: depthai.DeviceBase, arg0: depthai.CalibrationHandler) -> None

        Stores the Calibration and Device information to the Device EEPROM

        Throws:
            std::runtime_exception if failed to flash the calibration

        Parameter ``calibrationObj``:
            CalibrationHandler object which is loaded with calibration information.
        """
    def flashEepromClear(self) -> None:
        """flashEepromClear(self: depthai.DeviceBase) -> None

        Destructive action, deletes User area EEPROM contents Requires PROTECTED
        permissions

        Throws:
            std::runtime_exception if failed to flash the calibration

        Returns:
            True on successful flash, false on failure
        """
    def flashFactoryCalibration(self, arg0: CalibrationHandler) -> None:
        """flashFactoryCalibration(self: depthai.DeviceBase, arg0: depthai.CalibrationHandler) -> None

        Stores the Calibration and Device information to the Device EEPROM in Factory
        area To perform this action, correct env variable must be set

        Throws:
            std::runtime_exception if failed to flash the calibration

        Returns:
            True on successful flash, false on failure
        """
    def flashFactoryEepromClear(self) -> None:
        """flashFactoryEepromClear(self: depthai.DeviceBase) -> None

        Destructive action, deletes Factory area EEPROM contents Requires FACTORY
        PROTECTED permissions

        Throws:
            std::runtime_exception if failed to flash the calibration

        Returns:
            True on successful flash, false on failure
        """
    @staticmethod
    def getAllAvailableDevices() -> list[DeviceInfo]:
        """getAllAvailableDevices() -> list[depthai.DeviceInfo]

        Returns all available devices

        Returns:
            Vector of available devices
        """
    @staticmethod
    def getAllConnectedDevices() -> list[DeviceInfo]:
        """getAllConnectedDevices() -> list[depthai.DeviceInfo]

        Returns information of all connected devices. The devices could be both
        connectable as well as already connected to devices.

        Returns:
            Vector of connected device information
        """
    @overload
    @staticmethod
    def getAnyAvailableDevice(timeout: datetime.timedelta) -> tuple[bool, DeviceInfo]:
        """getAnyAvailableDevice(*args, **kwargs)
        Overloaded function.

        1. getAnyAvailableDevice(timeout: datetime.timedelta) -> tuple[bool, depthai.DeviceInfo]

        Waits for any available device with a timeout

        Parameter ``timeout``:
            duration of time to wait for the any device

        Returns:
            Tuple of bool and DeviceInfo. Bool specifies if device was found. DeviceInfo
            specifies the found device

        2. getAnyAvailableDevice() -> tuple[bool, depthai.DeviceInfo]

        Gets any available device

        Returns:
            Tuple of bool and DeviceInfo. Bool specifies if device was found. DeviceInfo
            specifies the found device
        """
    @overload
    @staticmethod
    def getAnyAvailableDevice() -> tuple[bool, DeviceInfo]:
        """getAnyAvailableDevice(*args, **kwargs)
        Overloaded function.

        1. getAnyAvailableDevice(timeout: datetime.timedelta) -> tuple[bool, depthai.DeviceInfo]

        Waits for any available device with a timeout

        Parameter ``timeout``:
            duration of time to wait for the any device

        Returns:
            Tuple of bool and DeviceInfo. Bool specifies if device was found. DeviceInfo
            specifies the found device

        2. getAnyAvailableDevice() -> tuple[bool, depthai.DeviceInfo]

        Gets any available device

        Returns:
            Tuple of bool and DeviceInfo. Bool specifies if device was found. DeviceInfo
            specifies the found device
        """
    def getAvailableStereoPairs(self) -> list[StereoPair]:
        """getAvailableStereoPairs(self: depthai.DeviceBase) -> list[depthai.StereoPair]

        Get stereo pairs taking into account the calibration and connected cameras.

        @note This method will always return a subset of `getStereoPairs`.

        Returns:
            Vector of stereo pairs
        """
    def getBootloaderVersion(self) -> Version | None:
        """getBootloaderVersion(self: depthai.DeviceBase) -> Optional[depthai.Version]

        Gets Bootloader version if it was booted through Bootloader

        Returns:
            DeviceBootloader::Version if booted through Bootloader or none otherwise
        """
    def getCalibration(self) -> CalibrationHandler:
        """getCalibration(self: depthai.DeviceBase) -> depthai.CalibrationHandler

        Retrieves the CalibrationHandler object containing the non-persistent
        calibration

        Throws:
            std::runtime_exception if failed to get the calibration

        Returns:
            The CalibrationHandler object containing the non-persistent calibration
        """
    def getCameraSensorNames(self) -> dict[CameraBoardSocket, str]:
        """getCameraSensorNames(self: depthai.DeviceBase) -> dict[depthai.CameraBoardSocket, str]

        Get sensor names for cameras that are connected to the device

        Returns:
            Map/dictionary with camera sensor names, indexed by socket
        """
    def getChipTemperature(self) -> ChipTemperature:
        """getChipTemperature(self: depthai.DeviceBase) -> depthai.ChipTemperature

        Retrieves current chip temperature as measured by device

        Returns:
            Temperature of various onboard sensors
        """
    def getCmxMemoryUsage(self) -> MemoryInfo:
        """getCmxMemoryUsage(self: depthai.DeviceBase) -> depthai.MemoryInfo

        Retrieves current CMX memory information from device

        Returns:
            Used, remaining and total cmx memory
        """
    def getConnectedCameraFeatures(self) -> list[CameraFeatures]:
        """getConnectedCameraFeatures(self: depthai.DeviceBase) -> list[depthai.CameraFeatures]

        Get cameras that are connected to the device with their features/properties

        Returns:
            Vector of connected camera features
        """
    def getConnectedCameras(self) -> list[CameraBoardSocket]:
        """getConnectedCameras(self: depthai.DeviceBase) -> list[depthai.CameraBoardSocket]

        Get cameras that are connected to the device

        Returns:
            Vector of connected cameras
        """
    def getConnectedIMU(self) -> str:
        """getConnectedIMU(self: depthai.DeviceBase) -> str

        Get connected IMU type

        Returns:
            IMU type
        """
    def getConnectionInterfaces(self) -> list[connectionInterface]:
        """getConnectionInterfaces(self: depthai.DeviceBase) -> list[depthai.connectionInterface]

        Get connection interfaces for device

        Returns:
            Vector of connection type
        """
    def getCrashDump(self, clearCrashDump: bool = ...) -> CrashDump:
        """getCrashDump(self: depthai.DeviceBase, clearCrashDump: bool = True) -> depthai.CrashDump

        Retrieves crash dump for debugging.
        """
    def getDdrMemoryUsage(self) -> MemoryInfo:
        """getDdrMemoryUsage(self: depthai.DeviceBase) -> depthai.MemoryInfo

        Retrieves current DDR memory information from device

        Returns:
            Used, remaining and total ddr memory
        """
    @staticmethod
    def getDeviceByMxId(mxId: str) -> tuple[bool, DeviceInfo]:
        """getDeviceByMxId(mxId: str) -> tuple[bool, depthai.DeviceInfo]

        Finds a device by MX ID. Example: 14442C10D13EABCE00

        Parameter ``mxId``:
            MyraidX ID which uniquely specifies a device

        Returns:
            Tuple of bool and DeviceInfo. Bool specifies if device was found. DeviceInfo
            specifies the found device
        """
    def getDeviceInfo(self) -> DeviceInfo:
        """getDeviceInfo(self: depthai.DeviceBase) -> depthai.DeviceInfo

        Get the Device Info object o the device which is currently running

        Returns:
            DeviceInfo of the current device in execution
        """
    def getDeviceName(self) -> object:
        """getDeviceName(self: depthai.DeviceBase) -> object

        Get device name if available

        Returns:
            device name or empty string if not available
        """
    @overload
    @staticmethod
    def getEmbeddedDeviceBinary(usb2Mode: bool, version: OpenVINO.Version = ...) -> list[int]:
        """getEmbeddedDeviceBinary(*args, **kwargs)
        Overloaded function.

        1. getEmbeddedDeviceBinary(usb2Mode: bool, version: depthai.OpenVINO.Version = <Version.???: 7>) -> list[int]

        Gets device firmware binary for a specific OpenVINO version

        Parameter ``usb2Mode``:
            USB2 mode firmware

        Parameter ``version``:
            Version of OpenVINO which firmware will support

        Returns:
            Firmware binary

        2. getEmbeddedDeviceBinary(config: depthai.Device.Config) -> list[int]

        Gets device firmware binary for a specific configuration

        Parameter ``config``:
            FW with applied configuration

        Returns:
            Firmware binary
        """
    @overload
    @staticmethod
    def getEmbeddedDeviceBinary(config: Device.Config) -> list[int]:
        """getEmbeddedDeviceBinary(*args, **kwargs)
        Overloaded function.

        1. getEmbeddedDeviceBinary(usb2Mode: bool, version: depthai.OpenVINO.Version = <Version.???: 7>) -> list[int]

        Gets device firmware binary for a specific OpenVINO version

        Parameter ``usb2Mode``:
            USB2 mode firmware

        Parameter ``version``:
            Version of OpenVINO which firmware will support

        Returns:
            Firmware binary

        2. getEmbeddedDeviceBinary(config: depthai.Device.Config) -> list[int]

        Gets device firmware binary for a specific configuration

        Parameter ``config``:
            FW with applied configuration

        Returns:
            Firmware binary
        """
    def getEmbeddedIMUFirmwareVersion(self) -> Version:
        """getEmbeddedIMUFirmwareVersion(self: depthai.DeviceBase) -> depthai.Version

        Get embedded IMU firmware version to which IMU can be upgraded

        Returns:
            Get embedded IMU firmware version to which IMU can be upgraded.
        """
    @staticmethod
    def getFirstAvailableDevice(skipInvalidDevices: bool = ...) -> tuple[bool, DeviceInfo]:
        """getFirstAvailableDevice(skipInvalidDevices: bool = True) -> tuple[bool, depthai.DeviceInfo]

        Gets first available device. Device can be either in XLINK_UNBOOTED or
        XLINK_BOOTLOADER state

        Returns:
            Tuple of bool and DeviceInfo. Bool specifies if device was found. DeviceInfo
            specifies the found device
        """
    @staticmethod
    def getGlobalProfilingData() -> ProfilingData:
        """getGlobalProfilingData() -> depthai.ProfilingData

        Get current global accumulated profiling data

        Returns:
            ProfilingData from all devices
        """
    def getIMUFirmwareUpdateStatus(self) -> tuple[bool, int]:
        """getIMUFirmwareUpdateStatus(self: depthai.DeviceBase) -> tuple[bool, int]

        Get IMU firmware update status

        Returns:
            Whether IMU firmware update is done and last firmware update progress as
            percentage. return value true and 100 means that the update was successful
            return value true and other than 100 means that the update failed
        """
    def getIMUFirmwareVersion(self) -> Version:
        """getIMUFirmwareVersion(self: depthai.DeviceBase) -> depthai.Version

        Get connected IMU firmware version

        Returns:
            IMU firmware version
        """
    def getIrDrivers(self) -> list[tuple[str, int, int]]:
        '''getIrDrivers(self: depthai.DeviceBase) -> list[tuple[str, int, int]]

        Retrieves detected IR laser/LED drivers.

        Returns:
            Vector of tuples containing: driver name, I2C bus, I2C address. For OAK-D-
            Pro it should be `[{"LM3644", 2, 0x63}]`
        '''
    def getLeonCssCpuUsage(self) -> CpuUsage:
        """getLeonCssCpuUsage(self: depthai.DeviceBase) -> depthai.CpuUsage

        Retrieves average CSS Leon CPU usage

        Returns:
            Average CPU usage and sampling duration
        """
    def getLeonCssHeapUsage(self) -> MemoryInfo:
        """getLeonCssHeapUsage(self: depthai.DeviceBase) -> depthai.MemoryInfo

        Retrieves current CSS Leon CPU heap information from device

        Returns:
            Used, remaining and total heap memory
        """
    def getLeonMssCpuUsage(self) -> CpuUsage:
        """getLeonMssCpuUsage(self: depthai.DeviceBase) -> depthai.CpuUsage

        Retrieves average MSS Leon CPU usage

        Returns:
            Average CPU usage and sampling duration
        """
    def getLeonMssHeapUsage(self) -> MemoryInfo:
        """getLeonMssHeapUsage(self: depthai.DeviceBase) -> depthai.MemoryInfo

        Retrieves current MSS Leon CPU heap information from device

        Returns:
            Used, remaining and total heap memory
        """
    def getLogLevel(self) -> LogLevel:
        """getLogLevel(self: depthai.DeviceBase) -> depthai.LogLevel

        Gets current logging severity level of the device.

        Returns:
            Logging severity level
        """
    def getLogOutputLevel(self) -> LogLevel:
        """getLogOutputLevel(self: depthai.DeviceBase) -> depthai.LogLevel

        Gets logging level which decides printing level to standard output.

        Returns:
            Standard output printing severity
        """
    def getMxId(self) -> str:
        """getMxId(self: depthai.DeviceBase) -> str

        Get MxId of device

        Returns:
            MxId of connected device
        """
    def getProductName(self) -> object:
        """getProductName(self: depthai.DeviceBase) -> object

        Get product name if available

        Returns:
            product name or empty string if not available
        """
    def getProfilingData(self) -> ProfilingData:
        """getProfilingData(self: depthai.DeviceBase) -> depthai.ProfilingData

        Get current accumulated profiling data

        Returns:
            ProfilingData from the specific device
        """
    def getStereoPairs(self) -> list[StereoPair]:
        """getStereoPairs(self: depthai.DeviceBase) -> list[depthai.StereoPair]

        Get stereo pairs based on the device type.

        Returns:
            Vector of stereo pairs
        """
    def getSystemInformationLoggingRate(self) -> float:
        '''getSystemInformationLoggingRate(self: depthai.DeviceBase) -> float

        Gets current rate of system information logging ("info" severity) in Hz.

        Returns:
            Logging rate in Hz
        '''
    def getUsbSpeed(self) -> UsbSpeed:
        """getUsbSpeed(self: depthai.DeviceBase) -> depthai.UsbSpeed

        Retrieves USB connection speed

        Returns:
            USB connection speed of connected device if applicable. Unknown otherwise.
        """
    def getXLinkChunkSize(self) -> int:
        """getXLinkChunkSize(self: depthai.DeviceBase) -> int

        Gets current XLink chunk size.

        Returns:
            XLink chunk size in bytes
        """
    def hasCrashDump(self) -> bool:
        """hasCrashDump(self: depthai.DeviceBase) -> bool

        Retrieves whether the is crash dump stored on device or not.
        """
    def isClosed(self) -> bool:
        """isClosed(self: depthai.DeviceBase) -> bool

        Is the device already closed (or disconnected)

        .. warning::
            This function is thread-unsafe and may return outdated incorrect values. It
            is only meant for use in simple single-threaded code. Well written code
            should handle exceptions when calling any DepthAI apis to handle hardware
            events and multithreaded use.
        """
    def isEepromAvailable(self) -> bool:
        """isEepromAvailable(self: depthai.DeviceBase) -> bool

        Check if EEPROM is available

        Returns:
            True if EEPROM is present on board, false otherwise
        """
    def isPipelineRunning(self) -> bool:
        """isPipelineRunning(self: depthai.DeviceBase) -> bool

        Checks if devices pipeline is already running

        Returns:
            True if running, false otherwise
        """
    def readCalibration(self) -> CalibrationHandler:
        """readCalibration(self: depthai.DeviceBase) -> depthai.CalibrationHandler

        Fetches the EEPROM data from the device and loads it into CalibrationHandler
        object If no calibration is flashed, it returns default

        Returns:
            The CalibrationHandler object containing the calibration currently flashed
            on device EEPROM
        """
    def readCalibration2(self) -> CalibrationHandler:
        """readCalibration2(self: depthai.DeviceBase) -> depthai.CalibrationHandler

        Fetches the EEPROM data from the device and loads it into CalibrationHandler
        object

        Throws:
            std::runtime_exception if no calibration is flashed

        Returns:
            The CalibrationHandler object containing the calibration currently flashed
            on device EEPROM
        """
    def readCalibrationOrDefault(self) -> CalibrationHandler:
        """readCalibrationOrDefault(self: depthai.DeviceBase) -> depthai.CalibrationHandler

        Fetches the EEPROM data from the device and loads it into CalibrationHandler
        object If no calibration is flashed, it returns default

        Returns:
            The CalibrationHandler object containing the calibration currently flashed
            on device EEPROM
        """
    def readCalibrationRaw(self) -> list[int]:
        """readCalibrationRaw(self: depthai.DeviceBase) -> list[int]

        Fetches the raw EEPROM data from User area

        Throws:
            std::runtime_exception if any error occurred

        Returns:
            Binary dump of User area EEPROM data
        """
    def readFactoryCalibration(self) -> CalibrationHandler:
        """readFactoryCalibration(self: depthai.DeviceBase) -> depthai.CalibrationHandler

        Fetches the EEPROM data from Factory area and loads it into CalibrationHandler
        object

        Throws:
            std::runtime_exception if no calibration is flashed

        Returns:
            The CalibrationHandler object containing the calibration currently flashed
            on device EEPROM in Factory Area
        """
    def readFactoryCalibrationOrDefault(self) -> CalibrationHandler:
        """readFactoryCalibrationOrDefault(self: depthai.DeviceBase) -> depthai.CalibrationHandler

        Fetches the EEPROM data from Factory area and loads it into CalibrationHandler
        object If no calibration is flashed, it returns default

        Returns:
            The CalibrationHandler object containing the calibration currently flashed
            on device EEPROM in Factory Area
        """
    def readFactoryCalibrationRaw(self) -> list[int]:
        """readFactoryCalibrationRaw(self: depthai.DeviceBase) -> list[int]

        Fetches the raw EEPROM data from Factory area

        Throws:
            std::runtime_exception if any error occurred

        Returns:
            Binary dump of Factory area EEPROM data
        """
    def removeLogCallback(self, callbackId: int) -> bool:
        """removeLogCallback(self: depthai.DeviceBase, callbackId: int) -> bool

        Removes a callback

        Parameter ``callbackId``:
            Id of callback to be removed

        Returns:
            True if callback was removed, false otherwise
        """
    def setCalibration(self, calibrationDataHandler: CalibrationHandler) -> None:
        """setCalibration(self: depthai.DeviceBase, calibrationDataHandler: depthai.CalibrationHandler) -> None

        Sets the Calibration at runtime. This is not persistent and will be lost after
        device reset.

        Throws:
            std::runtime_exception if failed to set the calibration

        Parameter ``calibrationObj``:
            CalibrationHandler object which is loaded with calibration information.
        """
    def setIrFloodLightBrightness(self, mA: float, mask: int = ...) -> bool:
        """setIrFloodLightBrightness(self: depthai.DeviceBase, mA: float, mask: int = -1) -> bool

        Sets the brightness of the IR Flood Light. Limits: up to 1500mA at 30% duty
        cycle. The duty cycle is controlled by the `left` camera STROBE, aligned to
        start of exposure. If the dot projector is also enabled, its lower duty cycle
        limits take precedence. The emitter is turned off by default

        Parameter ``mA``:
            Current in mA that will determine brightness, 0 or negative to turn off

        Parameter ``mask``:
            Optional mask to modify only Left (0x1) or Right (0x2) sides on OAK-D-Pro-W-
            DEV

        Returns:
            True on success, false if not found or other failure
        """
    def setIrFloodLightIntensity(self, intensity: float, mask: int = ...) -> bool:
        """setIrFloodLightIntensity(self: depthai.DeviceBase, intensity: float, mask: int = -1) -> bool

        Sets the intensity of the IR Flood Light. Limits: Intensity is directly
        normalized to 0 - 1500mA current. The duty cycle is 30% when exposure time is
        longer than 30% frame time. Otherwise, duty cycle is 100% of exposure time. The
        duty cycle is controlled by the `left` camera STROBE, aligned to start of
        exposure. The emitter is turned off by default

        Parameter ``intensity``:
            Intensity on range 0 to 1, that will determine brightness, 0 or negative to
            turn off

        Parameter ``mask``:
            Optional mask to modify only Left (0x1) or Right (0x2) sides on OAK-D-Pro-W-
            DEV

        Returns:
            True on success, false if not found or other failure
        """
    def setIrLaserDotProjectorBrightness(self, mA: float, mask: int = ...) -> bool:
        """setIrLaserDotProjectorBrightness(self: depthai.DeviceBase, mA: float, mask: int = -1) -> bool

        Sets the brightness of the IR Laser Dot Projector. Limits: up to 765mA at 30%
        duty cycle, up to 1200mA at 6% duty cycle. The duty cycle is controlled by
        `left` camera STROBE, aligned to start of exposure. The emitter is turned off by
        default

        Parameter ``mA``:
            Current in mA that will determine brightness, 0 or negative to turn off

        Parameter ``mask``:
            Optional mask to modify only Left (0x1) or Right (0x2) sides on OAK-D-Pro-W-
            DEV

        Returns:
            True on success, false if not found or other failure
        """
    def setIrLaserDotProjectorIntensity(self, intensity: float, mask: int = ...) -> bool:
        """setIrLaserDotProjectorIntensity(self: depthai.DeviceBase, intensity: float, mask: int = -1) -> bool

        Sets the intensity of the IR Laser Dot Projector. Limits: up to 765mA at 30%
        frame time duty cycle when exposure time is longer than 30% frame time.
        Otherwise, duty cycle is 100% of exposure time, with current increased up to max
        1200mA to make up for shorter duty cycle. The duty cycle is controlled by `left`
        camera STROBE, aligned to start of exposure. The emitter is turned off by
        default

        Parameter ``intensity``:
            Intensity on range 0 to 1, that will determine brightness. 0 or negative to
            turn off

        Parameter ``mask``:
            Optional mask to modify only Left (0x1) or Right (0x2) sides on OAK-D-Pro-W-
            DEV

        Returns:
            True on success, false if not found or other failure
        """
    def setLogLevel(self, level: LogLevel) -> None:
        """setLogLevel(self: depthai.DeviceBase, level: depthai.LogLevel) -> None

        Sets the devices logging severity level. This level affects which logs are
        transferred from device to host.

        Parameter ``level``:
            Logging severity
        """
    def setLogOutputLevel(self, level: LogLevel) -> None:
        """setLogOutputLevel(self: depthai.DeviceBase, level: depthai.LogLevel) -> None

        Sets logging level which decides printing level to standard output. If lower
        than setLogLevel, no messages will be printed

        Parameter ``level``:
            Standard output printing severity
        """
    def setSystemInformationLoggingRate(self, rateHz: float) -> None:
        '''setSystemInformationLoggingRate(self: depthai.DeviceBase, rateHz: float) -> None

        Sets rate of system information logging ("info" severity). Default 1Hz If
        parameter is less or equal to zero, then system information logging will be
        disabled

        Parameter ``rateHz``:
            Logging rate in Hz
        '''
    @overload
    def setTimesync(self, arg0: datetime.timedelta, arg1: int, arg2: bool) -> None:
        """setTimesync(*args, **kwargs)
        Overloaded function.

        1. setTimesync(self: depthai.DeviceBase, arg0: datetime.timedelta, arg1: int, arg2: bool) -> None

        Configures Timesync service on device. It keeps host and device clocks in sync
        First time timesync is started it waits until the initial sync is completed
        Afterwards the function changes the following parameters

        Parameter ``period``:
            Interval between timesync runs

        Parameter ``numSamples``:
            Number of timesync samples per run which are used to compute a better value.
            Set to zero to disable timesync

        Parameter ``random``:
            If true partial timesync requests will be performed at random intervals,
            otherwise at fixed intervals

        2. setTimesync(self: depthai.DeviceBase, enable: bool) -> None

        Enables or disables Timesync service on device. It keeps host and device clocks
        in sync.

        Parameter ``enable``:
            Enables or disables consistent timesyncing
        """
    @overload
    def setTimesync(self, enable: bool) -> None:
        """setTimesync(*args, **kwargs)
        Overloaded function.

        1. setTimesync(self: depthai.DeviceBase, arg0: datetime.timedelta, arg1: int, arg2: bool) -> None

        Configures Timesync service on device. It keeps host and device clocks in sync
        First time timesync is started it waits until the initial sync is completed
        Afterwards the function changes the following parameters

        Parameter ``period``:
            Interval between timesync runs

        Parameter ``numSamples``:
            Number of timesync samples per run which are used to compute a better value.
            Set to zero to disable timesync

        Parameter ``random``:
            If true partial timesync requests will be performed at random intervals,
            otherwise at fixed intervals

        2. setTimesync(self: depthai.DeviceBase, enable: bool) -> None

        Enables or disables Timesync service on device. It keeps host and device clocks
        in sync.

        Parameter ``enable``:
            Enables or disables consistent timesyncing
        """
    def setXLinkChunkSize(self, sizeBytes: int) -> None:
        """setXLinkChunkSize(self: depthai.DeviceBase, sizeBytes: int) -> None

        Sets the chunk size for splitting device-sent XLink packets. A larger value
        could increase performance, and 0 disables chunking. A negative value is
        ignored. Device defaults are configured per protocol, currently 64*1024 for both
        USB and Ethernet.

        Parameter ``sizeBytes``:
            XLink chunk size in bytes
        """
    def startIMUFirmwareUpdate(self, forceUpdate: bool = ...) -> bool:
        """startIMUFirmwareUpdate(self: depthai.DeviceBase, forceUpdate: bool = False) -> bool

        Starts IMU firmware update asynchronously only if IMU node is not running. If
        current firmware version is the same as embedded firmware version then it's no-
        op. Can be overridden by forceUpdate parameter. State of firmware update can be
        monitored using getIMUFirmwareUpdateStatus API.

        Parameter ``forceUpdate``:
            Force firmware update or not. Will perform FW update regardless of current
            version and embedded firmware version.

        Returns:
            Returns whether firmware update can be started. Returns false if IMU node is
            started.
        """
    @overload
    def startPipeline(self) -> None:
        """startPipeline(*args, **kwargs)
        Overloaded function.

        1. startPipeline(self: depthai.DeviceBase) -> None

        Starts the execution of the devices pipeline

        Returns:
            True if pipeline started, false otherwise

        2. startPipeline(self: depthai.DeviceBase, arg0: depthai.Pipeline) -> bool

        Starts the execution of a given pipeline

        Parameter ``pipeline``:
            OpenVINO version of the pipeline must match the one which the device was
            booted with.

        Returns:
            True if pipeline started, false otherwise
        """
    @overload
    def startPipeline(self, arg0: Pipeline) -> bool:
        """startPipeline(*args, **kwargs)
        Overloaded function.

        1. startPipeline(self: depthai.DeviceBase) -> None

        Starts the execution of the devices pipeline

        Returns:
            True if pipeline started, false otherwise

        2. startPipeline(self: depthai.DeviceBase, arg0: depthai.Pipeline) -> bool

        Starts the execution of a given pipeline

        Parameter ``pipeline``:
            OpenVINO version of the pipeline must match the one which the device was
            booted with.

        Returns:
            True if pipeline started, false otherwise
        """
    def __enter__(self) -> DeviceBase:
        """__enter__(self: depthai.DeviceBase) -> depthai.DeviceBase"""
    def __exit__(self, arg0: object, arg1: object, arg2: object) -> None:
        """__exit__(self: depthai.DeviceBase, arg0: object, arg1: object, arg2: object) -> None"""

class DeviceBootloader:
    class ApplicationInfo:
        applicationName: str
        firmwareVersion: str
        hasApplication: bool
        def __init__(self) -> None:
            """__init__(self: depthai.DeviceBootloader.ApplicationInfo) -> None"""

    class Config:
        appMem: DeviceBootloader.Memory
        network: DeviceBootloader.NetworkConfig
        usb: DeviceBootloader.UsbConfig
        def __init__(self) -> None:
            """__init__(self: depthai.DeviceBootloader.Config) -> None"""
        def fromJson(self) -> DeviceBootloader.Config:
            """fromJson(self: json) -> depthai.DeviceBootloader.Config"""
        def getDnsAltIPv4(self) -> str:
            """getDnsAltIPv4(self: depthai.DeviceBootloader.Config) -> str"""
        def getDnsIPv4(self) -> str:
            """getDnsIPv4(self: depthai.DeviceBootloader.Config) -> str"""
        def getIPv4(self) -> str:
            """getIPv4(self: depthai.DeviceBootloader.Config) -> str"""
        def getIPv4Gateway(self) -> str:
            """getIPv4Gateway(self: depthai.DeviceBootloader.Config) -> str"""
        def getIPv4Mask(self) -> str:
            """getIPv4Mask(self: depthai.DeviceBootloader.Config) -> str"""
        def getMacAddress(self) -> str:
            """getMacAddress(self: depthai.DeviceBootloader.Config) -> str"""
        def getNetworkTimeout(self) -> datetime.timedelta:
            """getNetworkTimeout(self: depthai.DeviceBootloader.Config) -> datetime.timedelta"""
        def getUsbMaxSpeed(self) -> UsbSpeed:
            """getUsbMaxSpeed(self: depthai.DeviceBootloader.Config) -> depthai.UsbSpeed"""
        def getUsbTimeout(self) -> datetime.timedelta:
            """getUsbTimeout(self: depthai.DeviceBootloader.Config) -> datetime.timedelta"""
        def isStaticIPV4(self) -> bool:
            """isStaticIPV4(self: depthai.DeviceBootloader.Config) -> bool"""
        def setDnsIPv4(self, arg0: str, arg1: str) -> None:
            """setDnsIPv4(self: depthai.DeviceBootloader.Config, arg0: str, arg1: str) -> None"""
        def setDynamicIPv4(self, arg0: str, arg1: str, arg2: str) -> None:
            """setDynamicIPv4(self: depthai.DeviceBootloader.Config, arg0: str, arg1: str, arg2: str) -> None"""
        def setMacAddress(self, arg0: str) -> None:
            """setMacAddress(self: depthai.DeviceBootloader.Config, arg0: str) -> None"""
        def setNetworkTimeout(self, arg0: datetime.timedelta) -> None:
            """setNetworkTimeout(self: depthai.DeviceBootloader.Config, arg0: datetime.timedelta) -> None"""
        def setStaticIPv4(self, arg0: str, arg1: str, arg2: str) -> None:
            """setStaticIPv4(self: depthai.DeviceBootloader.Config, arg0: str, arg1: str, arg2: str) -> None"""
        def setUsbMaxSpeed(self, arg0: UsbSpeed) -> None:
            """setUsbMaxSpeed(self: depthai.DeviceBootloader.Config, arg0: depthai.UsbSpeed) -> None"""
        def setUsbTimeout(self, arg0: datetime.timedelta) -> None:
            """setUsbTimeout(self: depthai.DeviceBootloader.Config, arg0: datetime.timedelta) -> None"""
        def toJson(self) -> json:
            """toJson(self: depthai.DeviceBootloader.Config) -> json"""

    class Memory:
        __members__: ClassVar[dict] = ...  # read-only
        AUTO: ClassVar[DeviceBootloader.Memory] = ...
        EMMC: ClassVar[DeviceBootloader.Memory] = ...
        FLASH: ClassVar[DeviceBootloader.Memory] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.DeviceBootloader.Memory, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.DeviceBootloader.Memory) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.DeviceBootloader.Memory) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class MemoryInfo:
        available: bool
        info: str
        size: int
        def __init__(self) -> None:
            """__init__(self: depthai.DeviceBootloader.MemoryInfo) -> None"""

    class NetworkConfig:
        ipv4: int
        ipv4Dns: int
        ipv4DnsAlt: int
        ipv4Gateway: int
        ipv4Mask: int
        ipv6: Incomplete
        ipv6Dns: Incomplete
        ipv6DnsAlt: Incomplete
        ipv6Gateway: Incomplete
        ipv6Prefix: int
        mac: Incomplete
        staticIpv4: bool
        staticIpv6: bool
        timeoutMs: int
        def __init__(self) -> None:
            """__init__(self: depthai.DeviceBootloader.NetworkConfig) -> None"""

    class Section:
        __members__: ClassVar[dict] = ...  # read-only
        APPLICATION: ClassVar[DeviceBootloader.Section] = ...
        AUTO: ClassVar[DeviceBootloader.Section] = ...
        BOOTLOADER: ClassVar[DeviceBootloader.Section] = ...
        BOOTLOADER_CONFIG: ClassVar[DeviceBootloader.Section] = ...
        HEADER: ClassVar[DeviceBootloader.Section] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.DeviceBootloader.Section, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.DeviceBootloader.Section) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.DeviceBootloader.Section) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class Type:
        __members__: ClassVar[dict] = ...  # read-only
        AUTO: ClassVar[DeviceBootloader.Type] = ...
        NETWORK: ClassVar[DeviceBootloader.Type] = ...
        USB: ClassVar[DeviceBootloader.Type] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.DeviceBootloader.Type, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.DeviceBootloader.Type) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.DeviceBootloader.Type) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class UsbConfig:
        maxUsbSpeed: int
        pid: int
        timeoutMs: int
        vid: int
        def __init__(self) -> None:
            """__init__(self: depthai.DeviceBootloader.UsbConfig) -> None"""
    @overload
    def __init__(self, devInfo: DeviceInfo, allowFlashingBootloader: bool = ...) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBootloader, devInfo: depthai.DeviceInfo, allowFlashingBootloader: bool = False) -> None

        Connects to device in bootloader of specified type. Throws if it wasn't
        possible. This constructor will automatically boot into specified bootloader
        type if not already running

        Parameter ``devInfo``:
            DeviceInfo of which to boot or connect to

        Parameter ``type``:
            Type of bootloader to boot/connect to.

        Parameter ``allowFlashingBootloader``:
            Set to true to allow flashing the devices bootloader. Defaults to false

        2. __init__(self: depthai.DeviceBootloader, devInfo: depthai.DeviceInfo, pathToCmd: Path, allowFlashingBootloader: bool = False) -> None

        Connects to or boots device in bootloader mode depending on devInfo state with a
        custom bootloader firmware.

        Parameter ``devInfo``:
            DeviceInfo of which to boot or connect to

        Parameter ``pathToBootloader``:
            Custom bootloader firmware to boot

        Parameter ``allowFlashingBootloader``:
            Set to true to allow flashing the devices bootloader. Defaults to false

        3. __init__(self: depthai.DeviceBootloader, nameOrDeviceId: str, allowFlashingBootloader: bool = False) -> None

        Connects to device with specified name/device id

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``allowFlashingBootloader``:
            Set to true to allow flashing the devices bootloader. Defaults to false
        """
    @overload
    def __init__(self, devInfo: DeviceInfo, pathToCmd: Path, allowFlashingBootloader: bool = ...) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBootloader, devInfo: depthai.DeviceInfo, allowFlashingBootloader: bool = False) -> None

        Connects to device in bootloader of specified type. Throws if it wasn't
        possible. This constructor will automatically boot into specified bootloader
        type if not already running

        Parameter ``devInfo``:
            DeviceInfo of which to boot or connect to

        Parameter ``type``:
            Type of bootloader to boot/connect to.

        Parameter ``allowFlashingBootloader``:
            Set to true to allow flashing the devices bootloader. Defaults to false

        2. __init__(self: depthai.DeviceBootloader, devInfo: depthai.DeviceInfo, pathToCmd: Path, allowFlashingBootloader: bool = False) -> None

        Connects to or boots device in bootloader mode depending on devInfo state with a
        custom bootloader firmware.

        Parameter ``devInfo``:
            DeviceInfo of which to boot or connect to

        Parameter ``pathToBootloader``:
            Custom bootloader firmware to boot

        Parameter ``allowFlashingBootloader``:
            Set to true to allow flashing the devices bootloader. Defaults to false

        3. __init__(self: depthai.DeviceBootloader, nameOrDeviceId: str, allowFlashingBootloader: bool = False) -> None

        Connects to device with specified name/device id

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``allowFlashingBootloader``:
            Set to true to allow flashing the devices bootloader. Defaults to false
        """
    @overload
    def __init__(self, nameOrDeviceId: str, allowFlashingBootloader: bool = ...) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceBootloader, devInfo: depthai.DeviceInfo, allowFlashingBootloader: bool = False) -> None

        Connects to device in bootloader of specified type. Throws if it wasn't
        possible. This constructor will automatically boot into specified bootloader
        type if not already running

        Parameter ``devInfo``:
            DeviceInfo of which to boot or connect to

        Parameter ``type``:
            Type of bootloader to boot/connect to.

        Parameter ``allowFlashingBootloader``:
            Set to true to allow flashing the devices bootloader. Defaults to false

        2. __init__(self: depthai.DeviceBootloader, devInfo: depthai.DeviceInfo, pathToCmd: Path, allowFlashingBootloader: bool = False) -> None

        Connects to or boots device in bootloader mode depending on devInfo state with a
        custom bootloader firmware.

        Parameter ``devInfo``:
            DeviceInfo of which to boot or connect to

        Parameter ``pathToBootloader``:
            Custom bootloader firmware to boot

        Parameter ``allowFlashingBootloader``:
            Set to true to allow flashing the devices bootloader. Defaults to false

        3. __init__(self: depthai.DeviceBootloader, nameOrDeviceId: str, allowFlashingBootloader: bool = False) -> None

        Connects to device with specified name/device id

        Parameter ``nameOrDeviceId``:
            Creates DeviceInfo with nameOrDeviceId to connect to

        Parameter ``allowFlashingBootloader``:
            Set to true to allow flashing the devices bootloader. Defaults to false
        """
    def bootMemory(self, fw: list[int]) -> None:
        """bootMemory(self: depthai.DeviceBootloader, fw: list[int]) -> None

        Boots a custom FW in memory

        Parameter ``fw``:
            $Throws:

        A runtime exception if there are any communication issues
        """
    def bootUsbRomBootloader(self) -> None:
        """bootUsbRomBootloader(self: depthai.DeviceBootloader) -> None

        Boots into integrated ROM bootloader in USB mode

        Throws:
            A runtime exception if there are any communication issues
        """
    def close(self) -> None:
        """close(self: depthai.DeviceBootloader) -> None

        Closes the connection to device. Better alternative is the usage of context manager: `with depthai.DeviceBootloader(deviceInfo) as bootloader:`
        """
    @overload
    @staticmethod
    def createDepthaiApplicationPackage(pipeline: Pipeline, pathToCmd: Path = ..., compress: bool = ..., applicationName: str = ..., checkChecksum: bool = ...) -> list[int]:
        """createDepthaiApplicationPackage(*args, **kwargs)
        Overloaded function.

        1. createDepthaiApplicationPackage(pipeline: depthai.Pipeline, pathToCmd: Path = '', compress: bool = False, applicationName: str = '', checkChecksum: bool = False) -> list[int]

        Creates application package which can be flashed to depthai device.

        Parameter ``pipeline``:
            Pipeline from which to create the application package

        Parameter ``pathToCmd``:
            Optional path to custom device firmware

        Parameter ``compress``:
            Optional boolean which specifies if contents should be compressed

        Parameter ``applicationName``:
            Optional name the application that is flashed

        Returns:
            Depthai application package

        2. createDepthaiApplicationPackage(pipeline: depthai.Pipeline, compress: bool, applicationName: str = '', checkChecksum: bool = False) -> list[int]

        Creates application package which can be flashed to depthai device.

        Parameter ``pipeline``:
            Pipeline from which to create the application package

        Parameter ``compress``:
            Specifies if contents should be compressed

        Parameter ``applicationName``:
            Name the application that is flashed

        Returns:
            Depthai application package
        """
    @overload
    @staticmethod
    def createDepthaiApplicationPackage(pipeline: Pipeline, compress: bool, applicationName: str = ..., checkChecksum: bool = ...) -> list[int]:
        """createDepthaiApplicationPackage(*args, **kwargs)
        Overloaded function.

        1. createDepthaiApplicationPackage(pipeline: depthai.Pipeline, pathToCmd: Path = '', compress: bool = False, applicationName: str = '', checkChecksum: bool = False) -> list[int]

        Creates application package which can be flashed to depthai device.

        Parameter ``pipeline``:
            Pipeline from which to create the application package

        Parameter ``pathToCmd``:
            Optional path to custom device firmware

        Parameter ``compress``:
            Optional boolean which specifies if contents should be compressed

        Parameter ``applicationName``:
            Optional name the application that is flashed

        Returns:
            Depthai application package

        2. createDepthaiApplicationPackage(pipeline: depthai.Pipeline, compress: bool, applicationName: str = '', checkChecksum: bool = False) -> list[int]

        Creates application package which can be flashed to depthai device.

        Parameter ``pipeline``:
            Pipeline from which to create the application package

        Parameter ``compress``:
            Specifies if contents should be compressed

        Parameter ``applicationName``:
            Name the application that is flashed

        Returns:
            Depthai application package
        """
    @overload
    def flash(self, progressCallback: Callable[[float], None], pipeline: Pipeline, compress: bool = ..., applicationName: str = ..., memory: DeviceBootloader.Memory = ..., checkChecksum: bool = ...) -> tuple[bool, str]:
        """flash(*args, **kwargs)
        Overloaded function.

        1. flash(self: depthai.DeviceBootloader, progressCallback: Callable[[float], None], pipeline: depthai.Pipeline, compress: bool = False, applicationName: str = '', memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>, checkChecksum: bool = False) -> tuple[bool, str]

        Flashes a given pipeline to the device.

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``pipeline``:
            Pipeline to flash to the board

        Parameter ``compress``:
            Compresses application to reduce needed memory size

        Parameter ``applicationName``:
            Name the application that is flashed

        2. flash(self: depthai.DeviceBootloader, pipeline: depthai.Pipeline, compress: bool = False, applicationName: str = '', memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>, checkChecksum: bool = False) -> tuple[bool, str]

        Flashes a given pipeline to the device.

        Parameter ``pipeline``:
            Pipeline to flash to the board

        Parameter ``compress``:
            Compresses application to reduce needed memory size

        Parameter ``applicationName``:
            Optional name the application that is flashed
        """
    @overload
    def flash(self, pipeline: Pipeline, compress: bool = ..., applicationName: str = ..., memory: DeviceBootloader.Memory = ..., checkChecksum: bool = ...) -> tuple[bool, str]:
        """flash(*args, **kwargs)
        Overloaded function.

        1. flash(self: depthai.DeviceBootloader, progressCallback: Callable[[float], None], pipeline: depthai.Pipeline, compress: bool = False, applicationName: str = '', memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>, checkChecksum: bool = False) -> tuple[bool, str]

        Flashes a given pipeline to the device.

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``pipeline``:
            Pipeline to flash to the board

        Parameter ``compress``:
            Compresses application to reduce needed memory size

        Parameter ``applicationName``:
            Name the application that is flashed

        2. flash(self: depthai.DeviceBootloader, pipeline: depthai.Pipeline, compress: bool = False, applicationName: str = '', memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>, checkChecksum: bool = False) -> tuple[bool, str]

        Flashes a given pipeline to the device.

        Parameter ``pipeline``:
            Pipeline to flash to the board

        Parameter ``compress``:
            Compresses application to reduce needed memory size

        Parameter ``applicationName``:
            Optional name the application that is flashed
        """
    def flashBootHeader(self, memory: DeviceBootloader.Memory, frequency: int = ..., location: int = ..., dummyCycles: int = ..., offset: int = ...) -> tuple[bool, str]:
        """flashBootHeader(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, frequency: int = -1, location: int = -1, dummyCycles: int = -1, offset: int = -1) -> tuple[bool, str]

        Flash optimized boot header

        Parameter ``memory``:
            Which memory to flasht the header to

        Parameter ``frequency``:
            SPI specific parameter, frequency in MHz

        Parameter ``location``:
            Target location the header should boot to. Default to location of bootloader

        Parameter ``dummyCycles``:
            SPI specific parameter

        Parameter ``offset``:
            Offset in memory to flash the header to. Defaults to offset of boot header

        Returns:
            status as std::tuple<bool, std::string>
        """
    @overload
    def flashBootloader(self, progressCallback: Callable[[float], None], path: Path = ...) -> tuple[bool, str]:
        """flashBootloader(*args, **kwargs)
        Overloaded function.

        1. flashBootloader(self: depthai.DeviceBootloader, progressCallback: Callable[[float], None], path: Path = '') -> tuple[bool, str]

        Flashes bootloader to the current board

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``path``:
            Optional parameter to custom bootloader to flash

        2. flashBootloader(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, type: depthai.DeviceBootloader.Type, progressCallback: Callable[[float], None], path: Path = '') -> tuple[bool, str]

        Flash selected bootloader to the current board

        Parameter ``memory``:
            Memory to flash

        Parameter ``type``:
            Bootloader type to flash

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``path``:
            Optional parameter to custom bootloader to flash
        """
    @overload
    def flashBootloader(self, memory: DeviceBootloader.Memory, type: DeviceBootloader.Type, progressCallback: Callable[[float], None], path: Path = ...) -> tuple[bool, str]:
        """flashBootloader(*args, **kwargs)
        Overloaded function.

        1. flashBootloader(self: depthai.DeviceBootloader, progressCallback: Callable[[float], None], path: Path = '') -> tuple[bool, str]

        Flashes bootloader to the current board

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``path``:
            Optional parameter to custom bootloader to flash

        2. flashBootloader(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, type: depthai.DeviceBootloader.Type, progressCallback: Callable[[float], None], path: Path = '') -> tuple[bool, str]

        Flash selected bootloader to the current board

        Parameter ``memory``:
            Memory to flash

        Parameter ``type``:
            Bootloader type to flash

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``path``:
            Optional parameter to custom bootloader to flash
        """
    def flashClear(self, memory: DeviceBootloader.Memory = ...) -> tuple[bool, str]:
        """flashClear(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>) -> tuple[bool, str]

        Clears flashed application on the device, by removing SBR boot structure Doesn't
        remove fast boot header capability to still boot the application
        """
    def flashConfig(self, config: DeviceBootloader.Config, memory: DeviceBootloader.Memory = ..., type: DeviceBootloader.Type = ...) -> tuple[bool, str]:
        """flashConfig(self: depthai.DeviceBootloader, config: depthai.DeviceBootloader.Config, memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>, type: depthai.DeviceBootloader.Type = <Type.AUTO: -1>) -> tuple[bool, str]

        Flashes configuration to bootloader

        Parameter ``configData``:
            Configuration structure

        Parameter ``memory``:
            Optional - to which memory flash configuration

        Parameter ``type``:
            Optional - for which type of bootloader to flash configuration
        """
    def flashConfigClear(self, memory: DeviceBootloader.Memory = ..., type: DeviceBootloader.Type = ...) -> tuple[bool, str]:
        """flashConfigClear(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>, type: depthai.DeviceBootloader.Type = <Type.AUTO: -1>) -> tuple[bool, str]

        Clears configuration data

        Parameter ``memory``:
            Optional - on which memory to clear configuration data

        Parameter ``type``:
            Optional - for which type of bootloader to clear configuration data
        """
    def flashConfigData(self, configData: json, memory: DeviceBootloader.Memory = ..., type: DeviceBootloader.Type = ...) -> tuple[bool, str]:
        """flashConfigData(self: depthai.DeviceBootloader, configData: json, memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>, type: depthai.DeviceBootloader.Type = <Type.AUTO: -1>) -> tuple[bool, str]

        Flashes configuration data to bootloader

        Parameter ``configData``:
            Unstructured configuration data

        Parameter ``memory``:
            Optional - to which memory flash configuration

        Parameter ``type``:
            Optional - for which type of bootloader to flash configuration
        """
    def flashConfigFile(self, configData: Path, memory: DeviceBootloader.Memory = ..., type: DeviceBootloader.Type = ...) -> tuple[bool, str]:
        """flashConfigFile(self: depthai.DeviceBootloader, configData: Path, memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>, type: depthai.DeviceBootloader.Type = <Type.AUTO: -1>) -> tuple[bool, str]

        Flashes configuration data to bootloader

        Parameter ``configPath``:
            Unstructured configuration data

        Parameter ``memory``:
            Optional - to which memory flash configuration

        Parameter ``type``:
            Optional - for which type of bootloader to flash configuration
        """
    @overload
    def flashCustom(self, memory: DeviceBootloader.Memory, offset: int, data: list[int], progressCallback: Callable[[float], None] = ...) -> tuple[bool, str]:
        """flashCustom(*args, **kwargs)
        Overloaded function.

        1. flashCustom(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, offset: int, data: list[int], progressCallback: Callable[[float], None] = None) -> tuple[bool, str]

        Flash arbitrary data at custom offset in specified memory

        Parameter ``memory``:
            Memory to flash

        Parameter ``offset``:
            Offset at which to flash the given data in bytes

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``data``:
            Data to flash

        2. flashCustom(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, offset: int, filename: str, progressCallback: Callable[[float], None] = None) -> tuple[bool, str]

        Flash arbitrary data at custom offset in specified memory

        Parameter ``memory``:
            Memory to flash

        Parameter ``offset``:
            Offset at which to flash the given data in bytes

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``data``:
            Data to flash
        """
    @overload
    def flashCustom(self, memory: DeviceBootloader.Memory, offset: int, filename: str, progressCallback: Callable[[float], None] = ...) -> tuple[bool, str]:
        """flashCustom(*args, **kwargs)
        Overloaded function.

        1. flashCustom(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, offset: int, data: list[int], progressCallback: Callable[[float], None] = None) -> tuple[bool, str]

        Flash arbitrary data at custom offset in specified memory

        Parameter ``memory``:
            Memory to flash

        Parameter ``offset``:
            Offset at which to flash the given data in bytes

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``data``:
            Data to flash

        2. flashCustom(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, offset: int, filename: str, progressCallback: Callable[[float], None] = None) -> tuple[bool, str]

        Flash arbitrary data at custom offset in specified memory

        Parameter ``memory``:
            Memory to flash

        Parameter ``offset``:
            Offset at which to flash the given data in bytes

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``data``:
            Data to flash
        """
    @overload
    def flashDepthaiApplicationPackage(self, progressCallback: Callable[[float], None], package: list[int], memory: DeviceBootloader.Memory = ...) -> tuple[bool, str]:
        """flashDepthaiApplicationPackage(*args, **kwargs)
        Overloaded function.

        1. flashDepthaiApplicationPackage(self: depthai.DeviceBootloader, progressCallback: Callable[[float], None], package: list[int], memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>) -> tuple[bool, str]

        Flashes a specific depthai application package that was generated using
        createDepthaiApplicationPackage or saveDepthaiApplicationPackage

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``package``:
            Depthai application package to flash to the board

        2. flashDepthaiApplicationPackage(self: depthai.DeviceBootloader, package: list[int], memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>) -> tuple[bool, str]

        Flashes a specific depthai application package that was generated using
        createDepthaiApplicationPackage or saveDepthaiApplicationPackage

        Parameter ``package``:
            Depthai application package to flash to the board
        """
    @overload
    def flashDepthaiApplicationPackage(self, package: list[int], memory: DeviceBootloader.Memory = ...) -> tuple[bool, str]:
        """flashDepthaiApplicationPackage(*args, **kwargs)
        Overloaded function.

        1. flashDepthaiApplicationPackage(self: depthai.DeviceBootloader, progressCallback: Callable[[float], None], package: list[int], memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>) -> tuple[bool, str]

        Flashes a specific depthai application package that was generated using
        createDepthaiApplicationPackage or saveDepthaiApplicationPackage

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``package``:
            Depthai application package to flash to the board

        2. flashDepthaiApplicationPackage(self: depthai.DeviceBootloader, package: list[int], memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>) -> tuple[bool, str]

        Flashes a specific depthai application package that was generated using
        createDepthaiApplicationPackage or saveDepthaiApplicationPackage

        Parameter ``package``:
            Depthai application package to flash to the board
        """
    def flashFastBootHeader(self, memory: DeviceBootloader.Memory, frequency: int = ..., location: int = ..., dummyCycles: int = ..., offset: int = ...) -> tuple[bool, str]:
        """flashFastBootHeader(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, frequency: int = -1, location: int = -1, dummyCycles: int = -1, offset: int = -1) -> tuple[bool, str]

        Flash fast boot header. Application must already be present in flash, or
        location must be specified manually. Note - Can soft brick your device if
        firmware location changes.

        Parameter ``memory``:
            Which memory to flash the header to

        Parameter ``frequency``:
            SPI specific parameter, frequency in MHz

        Parameter ``location``:
            Target location the header should boot to. Default to location of bootloader

        Parameter ``dummyCycles``:
            SPI specific parameter

        Parameter ``offset``:
            Offset in memory to flash the header to. Defaults to offset of boot header

        Returns:
            status as std::tuple<bool, std::string>
        """
    def flashGpioModeBootHeader(self, memory: DeviceBootloader.Memory, mode: int) -> tuple[bool, str]:
        """flashGpioModeBootHeader(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, mode: int) -> tuple[bool, str]

        Flash boot header which boots same as equivalent GPIO mode would

        Parameter ``gpioMode``:
            GPIO mode equivalent
        """
    def flashUsbRecoveryBootHeader(self, memory: DeviceBootloader.Memory) -> tuple[bool, str]:
        """flashUsbRecoveryBootHeader(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory) -> tuple[bool, str]

        Flash USB recovery boot header. Switches to USB ROM Bootloader

        Parameter ``memory``:
            Which memory to flash the header to
        """
    def flashUserBootloader(self, progressCallback: Callable[[float], None], path: Path = ...) -> tuple[bool, str]:
        """flashUserBootloader(self: depthai.DeviceBootloader, progressCallback: Callable[[float], None], path: Path = '') -> tuple[bool, str]

        Flashes user bootloader to the current board. Available for NETWORK bootloader
        type

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            flashing progress

        Parameter ``path``:
            Optional parameter to custom bootloader to flash
        """
    @staticmethod
    def getAllAvailableDevices() -> list[DeviceInfo]:
        """getAllAvailableDevices() -> list[depthai.DeviceInfo]

        Searches for connected devices in either UNBOOTED or BOOTLOADER states.

        Returns:
            Vector of all found devices
        """
    @staticmethod
    def getEmbeddedBootloaderBinary(arg0: DeviceBootloader.Type) -> list[int]:
        """getEmbeddedBootloaderBinary(arg0: depthai.DeviceBootloader.Type) -> list[int]

        Returns:
            Embedded bootloader binary
        """
    @staticmethod
    def getEmbeddedBootloaderVersion() -> Version:
        """getEmbeddedBootloaderVersion() -> depthai.Version

        Returns:
            Embedded bootloader version
        """
    @staticmethod
    def getFirstAvailableDevice() -> tuple[bool, DeviceInfo]:
        """getFirstAvailableDevice() -> tuple[bool, depthai.DeviceInfo]

        Searches for connected devices in either UNBOOTED or BOOTLOADER states and
        returns first available.

        Returns:
            Tuple of boolean and DeviceInfo. If found boolean is true and DeviceInfo
            describes the device. Otherwise false
        """
    def getFlashedVersion(self) -> Version | None:
        """getFlashedVersion(self: depthai.DeviceBootloader) -> Optional[depthai.Version]

        Returns:
            Version of the bootloader that is flashed on the device. Nullopt when the
            version could not be retrieved because the device was in X_LINK_UNBOOTED
            state before booting the bootloader.
        """
    def getMemoryInfo(self, arg0: DeviceBootloader.Memory) -> DeviceBootloader.MemoryInfo:
        """getMemoryInfo(self: depthai.DeviceBootloader, arg0: depthai.DeviceBootloader.Memory) -> depthai.DeviceBootloader.MemoryInfo

        Retrieves information about specified memory

        Parameter ``memory``:
            Specifies which memory to query
        """
    def getType(self) -> DeviceBootloader.Type:
        """getType(self: depthai.DeviceBootloader) -> depthai.DeviceBootloader.Type

        Returns:
            Type of currently connected bootloader
        """
    def getVersion(self) -> Version:
        """getVersion(self: depthai.DeviceBootloader) -> depthai.Version

        Returns:
            Version of current running bootloader
        """
    def isAllowedFlashingBootloader(self) -> bool:
        """isAllowedFlashingBootloader(self: depthai.DeviceBootloader) -> bool

        Returns:
            True if allowed to flash bootloader
        """
    def isEmbeddedVersion(self) -> bool:
        """isEmbeddedVersion(self: depthai.DeviceBootloader) -> bool

        Returns:
            True when bootloader was booted using latest bootloader integrated in the
            library. False when bootloader is already running on the device and just
            connected to.
        """
    def isUserBootloader(self) -> bool:
        """isUserBootloader(self: depthai.DeviceBootloader) -> bool

        Retrieves whether current bootloader is User Bootloader (B out of A/B
        configuration)
        """
    def isUserBootloaderSupported(self) -> bool:
        """isUserBootloaderSupported(self: depthai.DeviceBootloader) -> bool

        Checks whether User Bootloader is supported with current bootloader

        Returns:
            true of User Bootloader is supported, false otherwise
        """
    def readApplicationInfo(self, memory: DeviceBootloader.Memory) -> DeviceBootloader.ApplicationInfo:
        """readApplicationInfo(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory) -> depthai.DeviceBootloader.ApplicationInfo

        Reads information about flashed application in specified memory from device

        Parameter ``memory``:
            Specifies which memory to query
        """
    def readConfig(self, memory: DeviceBootloader.Memory = ..., type: DeviceBootloader.Type = ...) -> DeviceBootloader.Config:
        """readConfig(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>, type: depthai.DeviceBootloader.Type = <Type.AUTO: -1>) -> depthai.DeviceBootloader.Config

        Reads configuration from bootloader

        Parameter ``memory``:
            Optional - from which memory to read configuration

        Parameter ``type``:
            Optional - from which type of bootloader to read configuration

        Returns:
            Configuration structure
        """
    def readConfigData(self, memory: DeviceBootloader.Memory = ..., type: DeviceBootloader.Type = ...) -> json:
        """readConfigData(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory = <Memory.AUTO: -1>, type: depthai.DeviceBootloader.Type = <Type.AUTO: -1>) -> json

        Reads configuration data from bootloader

        Returns:
            Unstructured configuration data

        Parameter ``memory``:
            Optional - from which memory to read configuration data

        Parameter ``type``:
            Optional - from which type of bootloader to read configuration data
        """
    @overload
    def readCustom(self, memory: DeviceBootloader.Memory, offset: int, size: int, filename: str, progressCallback: Callable[[float], None] = ...) -> tuple[bool, str]:
        """readCustom(*args, **kwargs)
        Overloaded function.

        1. readCustom(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, offset: int, size: int, filename: str, progressCallback: Callable[[float], None] = None) -> tuple[bool, str]

        Reads arbitrary data at custom offset in specified memory

        Parameter ``memory``:
            Memory to read

        Parameter ``offset``:
            Offset at which to read the specified bytes

        Parameter ``size``:
            Number of bytes to read

        Parameter ``data``:
            Data to read to. Must be at least 'size' number of bytes big

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            reading progress

        2. readCustom(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, offset: int, size: int, progressCallback: Callable[[float], None] = None) -> tuple[bool, str, list[int]]

        Reads arbitrary data at custom offset in specified memory

        Parameter ``memory``:
            Memory to read

        Parameter ``offset``:
            Offset at which to read the specified bytes

        Parameter ``size``:
            Number of bytes to read

        Parameter ``data``:
            Data to read to. Must be at least 'size' number of bytes big

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            reading progress
        """
    @overload
    def readCustom(self, memory: DeviceBootloader.Memory, offset: int, size: int, progressCallback: Callable[[float], None] = ...) -> tuple[bool, str, list[int]]:
        """readCustom(*args, **kwargs)
        Overloaded function.

        1. readCustom(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, offset: int, size: int, filename: str, progressCallback: Callable[[float], None] = None) -> tuple[bool, str]

        Reads arbitrary data at custom offset in specified memory

        Parameter ``memory``:
            Memory to read

        Parameter ``offset``:
            Offset at which to read the specified bytes

        Parameter ``size``:
            Number of bytes to read

        Parameter ``data``:
            Data to read to. Must be at least 'size' number of bytes big

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            reading progress

        2. readCustom(self: depthai.DeviceBootloader, memory: depthai.DeviceBootloader.Memory, offset: int, size: int, progressCallback: Callable[[float], None] = None) -> tuple[bool, str, list[int]]

        Reads arbitrary data at custom offset in specified memory

        Parameter ``memory``:
            Memory to read

        Parameter ``offset``:
            Offset at which to read the specified bytes

        Parameter ``size``:
            Number of bytes to read

        Parameter ``data``:
            Data to read to. Must be at least 'size' number of bytes big

        Parameter ``progressCallback``:
            Callback that sends back a value between 0..1 which signifies current
            reading progress
        """
    @overload
    @staticmethod
    def saveDepthaiApplicationPackage(path: Path, pipeline: Pipeline, pathToCmd: Path = ..., compress: bool = ..., applicationName: str = ..., checkChecksum: bool = ...) -> None:
        """saveDepthaiApplicationPackage(*args, **kwargs)
        Overloaded function.

        1. saveDepthaiApplicationPackage(path: Path, pipeline: depthai.Pipeline, pathToCmd: Path = '', compress: bool = False, applicationName: str = '', checkChecksum: bool = False) -> None

        Saves application package to a file which can be flashed to depthai device.

        Parameter ``path``:
            Path where to save the application package

        Parameter ``pipeline``:
            Pipeline from which to create the application package

        Parameter ``pathToCmd``:
            Optional path to custom device firmware

        Parameter ``compress``:
            Optional boolean which specifies if contents should be compressed

        Parameter ``applicationName``:
            Optional name the application that is flashed

        2. saveDepthaiApplicationPackage(path: Path, pipeline: depthai.Pipeline, compress: bool, applicationName: str = '', checkChecksum: bool = False) -> None

        Saves application package to a file which can be flashed to depthai device.

        Parameter ``path``:
            Path where to save the application package

        Parameter ``pipeline``:
            Pipeline from which to create the application package

        Parameter ``compress``:
            Specifies if contents should be compressed

        Parameter ``applicationName``:
            Optional name the application that is flashed
        """
    @overload
    @staticmethod
    def saveDepthaiApplicationPackage(path: Path, pipeline: Pipeline, compress: bool, applicationName: str = ..., checkChecksum: bool = ...) -> None:
        """saveDepthaiApplicationPackage(*args, **kwargs)
        Overloaded function.

        1. saveDepthaiApplicationPackage(path: Path, pipeline: depthai.Pipeline, pathToCmd: Path = '', compress: bool = False, applicationName: str = '', checkChecksum: bool = False) -> None

        Saves application package to a file which can be flashed to depthai device.

        Parameter ``path``:
            Path where to save the application package

        Parameter ``pipeline``:
            Pipeline from which to create the application package

        Parameter ``pathToCmd``:
            Optional path to custom device firmware

        Parameter ``compress``:
            Optional boolean which specifies if contents should be compressed

        Parameter ``applicationName``:
            Optional name the application that is flashed

        2. saveDepthaiApplicationPackage(path: Path, pipeline: depthai.Pipeline, compress: bool, applicationName: str = '', checkChecksum: bool = False) -> None

        Saves application package to a file which can be flashed to depthai device.

        Parameter ``path``:
            Path where to save the application package

        Parameter ``pipeline``:
            Pipeline from which to create the application package

        Parameter ``compress``:
            Specifies if contents should be compressed

        Parameter ``applicationName``:
            Optional name the application that is flashed
        """
    def __enter__(self) -> DeviceBootloader:
        """__enter__(self: depthai.DeviceBootloader) -> depthai.DeviceBootloader"""
    def __exit__(self, arg0: object, arg1: object, arg2: object) -> None:
        """__exit__(self: depthai.DeviceBootloader, arg0: object, arg1: object, arg2: object) -> None"""

class DeviceDesc:
    mxid: str
    name: str
    platform: XLinkPlatform
    protocol: XLinkProtocol
    state: XLinkDeviceState
    status: XLinkError_t
    def __init__(self) -> None:
        """__init__(self: depthai.DeviceDesc) -> None"""

class DeviceInfo:
    desc: object
    mxid: str
    name: str
    platform: XLinkPlatform
    protocol: XLinkProtocol
    state: XLinkDeviceState
    status: XLinkError_t
    @overload
    def __init__(self) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceInfo) -> None

        2. __init__(self: depthai.DeviceInfo, name: str, mxid: str, state: depthai.XLinkDeviceState, protocol: depthai.XLinkProtocol, platform: depthai.XLinkPlatform, status: depthai.XLinkError_t) -> None

        3. __init__(self: depthai.DeviceInfo, mxidOrName: str) -> None

        Creates a DeviceInfo by checking whether supplied parameter is a MXID or IP/USB
        name

        Parameter ``mxidOrName``:
            Either MXID, IP Address or USB port name

        4. __init__(self: depthai.DeviceInfo, arg0: depthai.DeviceDesc) -> None
        """
    @overload
    def __init__(self, name: str, mxid: str, state: XLinkDeviceState, protocol: XLinkProtocol, platform: XLinkPlatform, status: XLinkError_t) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceInfo) -> None

        2. __init__(self: depthai.DeviceInfo, name: str, mxid: str, state: depthai.XLinkDeviceState, protocol: depthai.XLinkProtocol, platform: depthai.XLinkPlatform, status: depthai.XLinkError_t) -> None

        3. __init__(self: depthai.DeviceInfo, mxidOrName: str) -> None

        Creates a DeviceInfo by checking whether supplied parameter is a MXID or IP/USB
        name

        Parameter ``mxidOrName``:
            Either MXID, IP Address or USB port name

        4. __init__(self: depthai.DeviceInfo, arg0: depthai.DeviceDesc) -> None
        """
    @overload
    def __init__(self, mxidOrName: str) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceInfo) -> None

        2. __init__(self: depthai.DeviceInfo, name: str, mxid: str, state: depthai.XLinkDeviceState, protocol: depthai.XLinkProtocol, platform: depthai.XLinkPlatform, status: depthai.XLinkError_t) -> None

        3. __init__(self: depthai.DeviceInfo, mxidOrName: str) -> None

        Creates a DeviceInfo by checking whether supplied parameter is a MXID or IP/USB
        name

        Parameter ``mxidOrName``:
            Either MXID, IP Address or USB port name

        4. __init__(self: depthai.DeviceInfo, arg0: depthai.DeviceDesc) -> None
        """
    @overload
    def __init__(self, arg0: DeviceDesc) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.DeviceInfo) -> None

        2. __init__(self: depthai.DeviceInfo, name: str, mxid: str, state: depthai.XLinkDeviceState, protocol: depthai.XLinkProtocol, platform: depthai.XLinkPlatform, status: depthai.XLinkError_t) -> None

        3. __init__(self: depthai.DeviceInfo, mxidOrName: str) -> None

        Creates a DeviceInfo by checking whether supplied parameter is a MXID or IP/USB
        name

        Parameter ``mxidOrName``:
            Either MXID, IP Address or USB port name

        4. __init__(self: depthai.DeviceInfo, arg0: depthai.DeviceDesc) -> None
        """
    def getMxId(self) -> str:
        """getMxId(self: depthai.DeviceInfo) -> str"""
    def getXLinkDeviceDesc(self) -> DeviceDesc:
        """getXLinkDeviceDesc(self: depthai.DeviceInfo) -> depthai.DeviceDesc"""

class EdgeDetectorConfig(Buffer):
    def __init__(self) -> None:
        """__init__(self: depthai.EdgeDetectorConfig) -> None"""
    def get(self) -> RawEdgeDetectorConfig:
        """get(self: depthai.EdgeDetectorConfig) -> depthai.RawEdgeDetectorConfig

        Retrieve configuration data for EdgeDetector.

        Returns:
            config for EdgeDetector
        """
    def getConfigData(self) -> EdgeDetectorConfigData:
        """getConfigData(self: depthai.EdgeDetectorConfig) -> depthai.EdgeDetectorConfigData

        Retrieve configuration data for EdgeDetector

        Returns:
            EdgeDetectorConfigData: sobel filter horizontal and vertical 3x3 kernels
        """
    def set(self, config: RawEdgeDetectorConfig) -> EdgeDetectorConfig:
        """set(self: depthai.EdgeDetectorConfig, config: depthai.RawEdgeDetectorConfig) -> depthai.EdgeDetectorConfig

        Set explicit configuration.

        Parameter ``config``:
            Explicit configuration
        """
    def setSobelFilterKernels(self, horizontalKernel: list[list[int]], verticalKernel: list[list[int]]) -> None:
        """setSobelFilterKernels(self: depthai.EdgeDetectorConfig, horizontalKernel: list[list[int]], verticalKernel: list[list[int]]) -> None

        Set sobel filter horizontal and vertical 3x3 kernels

        Parameter ``horizontalKernel``:
            Used for horizontal gradient computation in 3x3 Sobel filter

        Parameter ``verticalKernel``:
            Used for vertical gradient computation in 3x3 Sobel filter
        """

class EdgeDetectorConfigData:
    sobelFilterHorizontalKernel: list[list[int]]
    sobelFilterVerticalKernel: list[list[int]]
    def __init__(self) -> None:
        """__init__(self: depthai.EdgeDetectorConfigData) -> None"""

class EdgeDetectorProperties:
    initialConfig: RawEdgeDetectorConfig
    numFramesPool: int
    outputFrameSize: int
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class EepromData:
    batchName: str
    batchTime: int
    boardConf: str
    boardCustom: str
    boardName: str
    boardOptions: int
    boardRev: str
    cameraData: dict[CameraBoardSocket, CameraInfo]
    deviceName: str
    hardwareConf: str
    housingExtrinsics: Extrinsics
    imuExtrinsics: Extrinsics
    miscellaneousData: list[int]
    productName: str
    stereoEnableDistortionCorrection: bool
    stereoRectificationData: StereoRectification
    stereoUseSpecTranslation: bool
    version: int
    verticalCameraSocket: CameraBoardSocket
    def __init__(self) -> None:
        """__init__(self: depthai.EepromData) -> None"""

class EepromError(RuntimeError): ...

class EncodedFrame(Buffer):
    class FrameType:
        __members__: ClassVar[dict] = ...  # read-only
        B: ClassVar[RawEncodedFrame.FrameType] = ...
        I: ClassVar[RawEncodedFrame.FrameType] = ...
        P: ClassVar[RawEncodedFrame.FrameType] = ...
        Unknown: ClassVar[RawEncodedFrame.FrameType] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawEncodedFrame.FrameType, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawEncodedFrame.FrameType) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawEncodedFrame.FrameType) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class Profile:
        __members__: ClassVar[dict] = ...  # read-only
        AVC: ClassVar[RawEncodedFrame.Profile] = ...
        HEVC: ClassVar[RawEncodedFrame.Profile] = ...
        JPEG: ClassVar[RawEncodedFrame.Profile] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawEncodedFrame.Profile, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawEncodedFrame.Profile) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawEncodedFrame.Profile) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    def __init__(self) -> None:
        """__init__(self: depthai.EncodedFrame) -> None"""
    def getBitrate(self) -> int:
        """getBitrate(self: depthai.EncodedFrame) -> int

        Retrieves the encoding bitrate
        """
    def getColorTemperature(self) -> int:
        """getColorTemperature(self: depthai.EncodedFrame) -> int

        Retrieves white-balance color temperature of the light source, in kelvins
        """
    def getExposureTime(self) -> datetime.timedelta:
        """getExposureTime(self: depthai.EncodedFrame) -> datetime.timedelta

        Retrieves exposure time
        """
    def getFrameType(self) -> RawEncodedFrame.FrameType:
        """getFrameType(self: depthai.EncodedFrame) -> depthai.RawEncodedFrame.FrameType

        Retrieves frame type (H26x only)
        """
    def getHeight(self) -> int:
        """getHeight(self: depthai.EncodedFrame) -> int

        Retrieves image height in pixels
        """
    def getInstanceNum(self) -> int:
        """getInstanceNum(self: depthai.EncodedFrame) -> int

        Retrieves instance number
        """
    def getLensPosition(self) -> int:
        """getLensPosition(self: depthai.EncodedFrame) -> int

        Retrieves lens position, range 0..255. Returns -1 if not available
        """
    def getLensPositionRaw(self) -> float:
        """getLensPositionRaw(self: depthai.EncodedFrame) -> float

        Retrieves lens position, range 0.0f..1.0f. Returns -1 if not available
        """
    def getLossless(self) -> bool:
        """getLossless(self: depthai.EncodedFrame) -> bool

        Returns true if encoding is lossless (JPEG only)
        """
    def getProfile(self) -> RawEncodedFrame.Profile:
        """getProfile(self: depthai.EncodedFrame) -> depthai.RawEncodedFrame.Profile

        Retrieves the encoding profile (JPEG, AVC or HEVC)
        """
    def getQuality(self) -> int:
        """getQuality(self: depthai.EncodedFrame) -> int

        Retrieves the encoding quality
        """
    def getSensitivity(self) -> int:
        """getSensitivity(self: depthai.EncodedFrame) -> int

        Retrieves sensitivity, as an ISO value
        """
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.EncodedFrame) -> int

        Retrieves sequence number
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.EncodedFrame) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.EncodedFrame) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """
    def getWidth(self) -> int:
        """getWidth(self: depthai.EncodedFrame) -> int

        Retrieves image width in pixels
        """
    def setBitrate(self, arg0: int) -> EncodedFrame:
        """setBitrate(self: depthai.EncodedFrame, arg0: int) -> depthai.EncodedFrame

        Retrieves the encoding bitrate
        """
    def setFrameType(self, arg0: RawEncodedFrame.FrameType) -> EncodedFrame:
        """setFrameType(self: depthai.EncodedFrame, arg0: depthai.RawEncodedFrame.FrameType) -> depthai.EncodedFrame

        Retrieves frame type (H26x only)
        """
    def setHeight(self, arg0: int) -> EncodedFrame:
        """setHeight(self: depthai.EncodedFrame, arg0: int) -> depthai.EncodedFrame

        Specifies frame height

        Parameter ``height``:
            frame height
        """
    def setLossless(self, arg0: bool) -> EncodedFrame:
        """setLossless(self: depthai.EncodedFrame, arg0: bool) -> depthai.EncodedFrame

        Returns true if encoding is lossless (JPEG only)
        """
    def setProfile(self, arg0: RawEncodedFrame.Profile) -> EncodedFrame:
        """setProfile(self: depthai.EncodedFrame, arg0: depthai.RawEncodedFrame.Profile) -> depthai.EncodedFrame

        Retrieves the encoding profile (JPEG, AVC or HEVC)
        """
    def setQuality(self, arg0: int) -> EncodedFrame:
        """setQuality(self: depthai.EncodedFrame, arg0: int) -> depthai.EncodedFrame

        Retrieves the encoding quality
        """
    def setSequenceNum(self, arg0: int) -> EncodedFrame:
        """setSequenceNum(self: depthai.EncodedFrame, arg0: int) -> depthai.EncodedFrame

        Specifies sequence number

        Parameter ``seq``:
            Sequence number
        """
    def setTimestamp(self, arg0: datetime.timedelta) -> EncodedFrame:
        """setTimestamp(self: depthai.EncodedFrame, arg0: datetime.timedelta) -> depthai.EncodedFrame

        Retrieves image timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> EncodedFrame:
        """setTimestampDevice(self: depthai.EncodedFrame, arg0: datetime.timedelta) -> depthai.EncodedFrame

        Sets image timestamp related to dai::Clock::now()
        """
    def setWidth(self, arg0: int) -> EncodedFrame:
        """setWidth(self: depthai.EncodedFrame, arg0: int) -> depthai.EncodedFrame

        Specifies frame width

        Parameter ``width``:
            frame width
        """

class Extrinsics:
    rotationMatrix: list[list[float]]
    specTranslation: Point3f
    toCameraSocket: CameraBoardSocket
    translation: Point3f
    def __init__(self) -> None:
        """__init__(self: depthai.Extrinsics) -> None"""

class FeatureTrackerConfig(Buffer):
    class CornerDetector:
        class Thresholds:
            decreaseFactor: float
            increaseFactor: float
            initialValue: float
            max: float
            min: float
            def __init__(self) -> None:
                """__init__(self: depthai.RawFeatureTrackerConfig.CornerDetector.Thresholds) -> None"""

        class Type:
            __members__: ClassVar[dict] = ...  # read-only
            HARRIS: ClassVar[RawFeatureTrackerConfig.CornerDetector.Type] = ...
            SHI_THOMASI: ClassVar[RawFeatureTrackerConfig.CornerDetector.Type] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawFeatureTrackerConfig.CornerDetector.Type, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawFeatureTrackerConfig.CornerDetector.Type) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawFeatureTrackerConfig.CornerDetector.Type) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...
        cellGridDimension: int
        enableSobel: bool
        enableSorting: bool
        numMaxFeatures: int
        numTargetFeatures: int
        thresholds: RawFeatureTrackerConfig.CornerDetector.Thresholds
        type: RawFeatureTrackerConfig.CornerDetector.Type
        def __init__(self) -> None:
            """__init__(self: depthai.RawFeatureTrackerConfig.CornerDetector) -> None"""

    class FeatureMaintainer:
        enable: bool
        lostFeatureErrorThreshold: float
        minimumDistanceBetweenFeatures: float
        trackedFeatureThreshold: float
        def __init__(self) -> None:
            """__init__(self: depthai.RawFeatureTrackerConfig.FeatureMaintainer) -> None"""

    class MotionEstimator:
        class OpticalFlow:
            epsilon: float
            maxIterations: int
            pyramidLevels: int
            searchWindowHeight: int
            searchWindowWidth: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawFeatureTrackerConfig.MotionEstimator.OpticalFlow) -> None"""

        class Type:
            __members__: ClassVar[dict] = ...  # read-only
            HW_MOTION_ESTIMATION: ClassVar[RawFeatureTrackerConfig.MotionEstimator.Type] = ...
            LUCAS_KANADE_OPTICAL_FLOW: ClassVar[RawFeatureTrackerConfig.MotionEstimator.Type] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawFeatureTrackerConfig.MotionEstimator.Type, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawFeatureTrackerConfig.MotionEstimator.Type) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawFeatureTrackerConfig.MotionEstimator.Type) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...
        enable: bool
        opticalFlow: RawFeatureTrackerConfig.MotionEstimator.OpticalFlow
        type: RawFeatureTrackerConfig.MotionEstimator.Type
        def __init__(self) -> None:
            """__init__(self: depthai.RawFeatureTrackerConfig.MotionEstimator) -> None"""
    @overload
    def __init__(self) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.FeatureTrackerConfig) -> None

        2. __init__(self: depthai.FeatureTrackerConfig, arg0: depthai.RawFeatureTrackerConfig) -> None
        """
    @overload
    def __init__(self, arg0: RawFeatureTrackerConfig) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.FeatureTrackerConfig) -> None

        2. __init__(self: depthai.FeatureTrackerConfig, arg0: depthai.RawFeatureTrackerConfig) -> None
        """
    def get(self) -> RawFeatureTrackerConfig:
        """get(self: depthai.FeatureTrackerConfig) -> depthai.RawFeatureTrackerConfig

        Retrieve configuration data for FeatureTracker.

        Returns:
            config for feature tracking algorithm
        """
    def set(self, config: RawFeatureTrackerConfig) -> FeatureTrackerConfig:
        """set(self: depthai.FeatureTrackerConfig, config: depthai.RawFeatureTrackerConfig) -> depthai.FeatureTrackerConfig

        Set explicit configuration.

        Parameter ``config``:
            Explicit configuration
        """
    @overload
    def setCornerDetector(self, cornerDetector: RawFeatureTrackerConfig.CornerDetector.Type) -> FeatureTrackerConfig:
        """setCornerDetector(*args, **kwargs)
        Overloaded function.

        1. setCornerDetector(self: depthai.FeatureTrackerConfig, cornerDetector: depthai.RawFeatureTrackerConfig.CornerDetector.Type) -> depthai.FeatureTrackerConfig

        Set corner detector algorithm type.

        Parameter ``cornerDetector``:
            Corner detector type, HARRIS or SHI_THOMASI

        2. setCornerDetector(self: depthai.FeatureTrackerConfig, config: depthai.RawFeatureTrackerConfig.CornerDetector) -> depthai.FeatureTrackerConfig

        Set corner detector full configuration.

        Parameter ``config``:
            Corner detector configuration
        """
    @overload
    def setCornerDetector(self, config: RawFeatureTrackerConfig.CornerDetector) -> FeatureTrackerConfig:
        """setCornerDetector(*args, **kwargs)
        Overloaded function.

        1. setCornerDetector(self: depthai.FeatureTrackerConfig, cornerDetector: depthai.RawFeatureTrackerConfig.CornerDetector.Type) -> depthai.FeatureTrackerConfig

        Set corner detector algorithm type.

        Parameter ``cornerDetector``:
            Corner detector type, HARRIS or SHI_THOMASI

        2. setCornerDetector(self: depthai.FeatureTrackerConfig, config: depthai.RawFeatureTrackerConfig.CornerDetector) -> depthai.FeatureTrackerConfig

        Set corner detector full configuration.

        Parameter ``config``:
            Corner detector configuration
        """
    @overload
    def setFeatureMaintainer(self, enable: bool) -> FeatureTrackerConfig:
        """setFeatureMaintainer(*args, **kwargs)
        Overloaded function.

        1. setFeatureMaintainer(self: depthai.FeatureTrackerConfig, enable: bool) -> depthai.FeatureTrackerConfig

        Enable or disable feature maintainer.

        Parameter ``enable``:

        2. setFeatureMaintainer(self: depthai.FeatureTrackerConfig, config: depthai.RawFeatureTrackerConfig.FeatureMaintainer) -> depthai.FeatureTrackerConfig

        Set feature maintainer full configuration.

        Parameter ``config``:
            feature maintainer configuration
        """
    @overload
    def setFeatureMaintainer(self, config: RawFeatureTrackerConfig.FeatureMaintainer) -> FeatureTrackerConfig:
        """setFeatureMaintainer(*args, **kwargs)
        Overloaded function.

        1. setFeatureMaintainer(self: depthai.FeatureTrackerConfig, enable: bool) -> depthai.FeatureTrackerConfig

        Enable or disable feature maintainer.

        Parameter ``enable``:

        2. setFeatureMaintainer(self: depthai.FeatureTrackerConfig, config: depthai.RawFeatureTrackerConfig.FeatureMaintainer) -> depthai.FeatureTrackerConfig

        Set feature maintainer full configuration.

        Parameter ``config``:
            feature maintainer configuration
        """
    def setHwMotionEstimation(self) -> FeatureTrackerConfig:
        """setHwMotionEstimation(self: depthai.FeatureTrackerConfig) -> depthai.FeatureTrackerConfig

        Set hardware accelerated motion estimation using block matching. Faster than
        optical flow (software implementation) but might not be as accurate.
        """
    @overload
    def setMotionEstimator(self, enable: bool) -> FeatureTrackerConfig:
        """setMotionEstimator(*args, **kwargs)
        Overloaded function.

        1. setMotionEstimator(self: depthai.FeatureTrackerConfig, enable: bool) -> depthai.FeatureTrackerConfig

        Enable or disable motion estimator.

        Parameter ``enable``:

        2. setMotionEstimator(self: depthai.FeatureTrackerConfig, config: depthai.RawFeatureTrackerConfig.MotionEstimator) -> depthai.FeatureTrackerConfig

        Set motion estimator full configuration.

        Parameter ``config``:
            Motion estimator configuration
        """
    @overload
    def setMotionEstimator(self, config: RawFeatureTrackerConfig.MotionEstimator) -> FeatureTrackerConfig:
        """setMotionEstimator(*args, **kwargs)
        Overloaded function.

        1. setMotionEstimator(self: depthai.FeatureTrackerConfig, enable: bool) -> depthai.FeatureTrackerConfig

        Enable or disable motion estimator.

        Parameter ``enable``:

        2. setMotionEstimator(self: depthai.FeatureTrackerConfig, config: depthai.RawFeatureTrackerConfig.MotionEstimator) -> depthai.FeatureTrackerConfig

        Set motion estimator full configuration.

        Parameter ``config``:
            Motion estimator configuration
        """
    def setNumTargetFeatures(self, numTargetFeatures: int) -> FeatureTrackerConfig:
        """setNumTargetFeatures(self: depthai.FeatureTrackerConfig, numTargetFeatures: int) -> depthai.FeatureTrackerConfig

        Set number of target features to detect.

        Parameter ``numTargetFeatures``:
            Number of features
        """
    @overload
    def setOpticalFlow(self) -> FeatureTrackerConfig:
        """setOpticalFlow(*args, **kwargs)
        Overloaded function.

        1. setOpticalFlow(self: depthai.FeatureTrackerConfig) -> depthai.FeatureTrackerConfig

        Set optical flow as motion estimation algorithm type.

        2. setOpticalFlow(self: depthai.FeatureTrackerConfig, config: depthai.RawFeatureTrackerConfig.MotionEstimator.OpticalFlow) -> depthai.FeatureTrackerConfig

        Set optical flow full configuration.

        Parameter ``config``:
            Optical flow configuration
        """
    @overload
    def setOpticalFlow(self, config: RawFeatureTrackerConfig.MotionEstimator.OpticalFlow) -> FeatureTrackerConfig:
        """setOpticalFlow(*args, **kwargs)
        Overloaded function.

        1. setOpticalFlow(self: depthai.FeatureTrackerConfig) -> depthai.FeatureTrackerConfig

        Set optical flow as motion estimation algorithm type.

        2. setOpticalFlow(self: depthai.FeatureTrackerConfig, config: depthai.RawFeatureTrackerConfig.MotionEstimator.OpticalFlow) -> depthai.FeatureTrackerConfig

        Set optical flow full configuration.

        Parameter ``config``:
            Optical flow configuration
        """

class FeatureTrackerProperties:
    initialConfig: RawFeatureTrackerConfig
    numMemorySlices: int
    numShaves: int
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class FrameEvent:
    __members__: ClassVar[dict] = ...  # read-only
    NONE: ClassVar[FrameEvent] = ...
    READOUT_END: ClassVar[FrameEvent] = ...
    READOUT_START: ClassVar[FrameEvent] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.FrameEvent, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.FrameEvent) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.FrameEvent) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class GlobalProperties:
    cameraTuningBlobSize: int | None
    cameraTuningBlobUri: str
    leonOsFrequencyHz: float
    leonRtFrequencyHz: float
    pipelineName: str | None
    pipelineVersion: str | None
    sippBufferSize: int
    sippDmaBufferSize: int
    xlinkChunkSize: int
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class IMUData(Buffer):
    packets: list[IMUPacket]
    def __init__(self) -> None:
        """__init__(self: depthai.IMUData) -> None"""

class IMUPacket:
    acceleroMeter: IMUReportAccelerometer
    gyroscope: IMUReportGyroscope
    magneticField: IMUReportMagneticField
    rotationVector: IMUReportRotationVectorWAcc
    def __init__(self) -> None:
        """__init__(self: depthai.IMUPacket) -> None"""

class IMUProperties:
    batchReportThreshold: int
    enableFirmwareUpdate: bool | None
    imuSensors: list[IMUSensorConfig]
    maxBatchReports: int
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class IMUReport:
    class Accuracy:
        __members__: ClassVar[dict] = ...  # read-only
        HIGH: ClassVar[IMUReport.Accuracy] = ...
        LOW: ClassVar[IMUReport.Accuracy] = ...
        MEDIUM: ClassVar[IMUReport.Accuracy] = ...
        UNRELIABLE: ClassVar[IMUReport.Accuracy] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.IMUReport.Accuracy, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.IMUReport.Accuracy) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.IMUReport.Accuracy) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    accuracy: IMUReport.Accuracy
    sequence: int
    timestamp: Timestamp
    tsDevice: Timestamp
    def __init__(self) -> None:
        """__init__(self: depthai.IMUReport) -> None"""
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.IMUReport) -> int

        Retrieves IMU report sequence number
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.IMUReport) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.IMUReport) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """

class IMUReportAccelerometer(IMUReport):
    x: float
    y: float
    z: float
    def __init__(self) -> None:
        """__init__(self: depthai.IMUReportAccelerometer) -> None"""

class IMUReportGyroscope(IMUReport):
    x: float
    y: float
    z: float
    def __init__(self) -> None:
        """__init__(self: depthai.IMUReportGyroscope) -> None"""

class IMUReportMagneticField(IMUReport):
    x: float
    y: float
    z: float
    def __init__(self) -> None:
        """__init__(self: depthai.IMUReportMagneticField) -> None"""

class IMUReportRotationVectorWAcc(IMUReport):
    i: float
    j: float
    k: float
    real: float
    rotationVectorAccuracy: float
    def __init__(self) -> None:
        """__init__(self: depthai.IMUReportRotationVectorWAcc) -> None"""

class IMUSensor:
    __members__: ClassVar[dict] = ...  # read-only
    ACCELEROMETER: ClassVar[IMUSensor] = ...
    ACCELEROMETER_RAW: ClassVar[IMUSensor] = ...
    ARVR_STABILIZED_GAME_ROTATION_VECTOR: ClassVar[IMUSensor] = ...
    ARVR_STABILIZED_ROTATION_VECTOR: ClassVar[IMUSensor] = ...
    GAME_ROTATION_VECTOR: ClassVar[IMUSensor] = ...
    GEOMAGNETIC_ROTATION_VECTOR: ClassVar[IMUSensor] = ...
    GRAVITY: ClassVar[IMUSensor] = ...
    GYROSCOPE_CALIBRATED: ClassVar[IMUSensor] = ...
    GYROSCOPE_RAW: ClassVar[IMUSensor] = ...
    GYROSCOPE_UNCALIBRATED: ClassVar[IMUSensor] = ...
    LINEAR_ACCELERATION: ClassVar[IMUSensor] = ...
    MAGNETOMETER_CALIBRATED: ClassVar[IMUSensor] = ...
    MAGNETOMETER_RAW: ClassVar[IMUSensor] = ...
    MAGNETOMETER_UNCALIBRATED: ClassVar[IMUSensor] = ...
    ROTATION_VECTOR: ClassVar[IMUSensor] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.IMUSensor, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.IMUSensor) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.IMUSensor) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class IMUSensorConfig:
    changeSensitivity: int
    reportRate: int
    sensitivityEnabled: bool
    sensitivityRelative: bool
    sensorId: IMUSensor
    def __init__(self) -> None:
        """__init__(self: depthai.IMUSensorConfig) -> None"""

class ImageAlignConfig(Buffer):
    def __init__(self) -> None:
        """__init__(self: depthai.ImageAlignConfig) -> None"""
    def get(self) -> RawImageAlignConfig:
        """get(self: depthai.ImageAlignConfig) -> depthai.RawImageAlignConfig

        Retrieve configuration data for SpatialLocationCalculator.

        Returns:
            config for SpatialLocationCalculator
        """
    def set(self, config: RawImageAlignConfig) -> ImageAlignConfig:
        """set(self: depthai.ImageAlignConfig, config: depthai.RawImageAlignConfig) -> depthai.ImageAlignConfig

        Set explicit configuration.

        Parameter ``config``:
            Explicit configuration
        """

class ImageAlignProperties:
    alignHeight: int
    alignWidth: int
    initialConfig: RawImageAlignConfig
    interpolation: Interpolation
    numFramesPool: int
    numShaves: int
    outKeepAspectRatio: bool
    warpHwIds: list[int]
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class ImageManipConfig(Buffer):
    def __init__(self) -> None:
        """__init__(self: depthai.ImageManipConfig) -> None"""
    def get(self) -> RawImageManipConfig:
        """get(self: depthai.ImageManipConfig) -> depthai.RawImageManipConfig

        Retrieve configuration data for ImageManip.

        Returns:
            config for ImageManip
        """
    def getColormap(self) -> Colormap:
        """getColormap(self: depthai.ImageManipConfig) -> depthai.Colormap

        Returns:
            specified colormap
        """
    def getCropConfig(self) -> RawImageManipConfig.CropConfig:
        """getCropConfig(self: depthai.ImageManipConfig) -> depthai.RawImageManipConfig.CropConfig

        Returns:
            Crop configuration
        """
    def getCropXMax(self) -> float:
        """getCropXMax(self: depthai.ImageManipConfig) -> float

        Returns:
            Bottom right X coordinate of crop region
        """
    def getCropXMin(self) -> float:
        """getCropXMin(self: depthai.ImageManipConfig) -> float

        Returns:
            Top left X coordinate of crop region
        """
    def getCropYMax(self) -> float:
        """getCropYMax(self: depthai.ImageManipConfig) -> float

        Returns:
            Bottom right Y coordinate of crop region
        """
    def getCropYMin(self) -> float:
        """getCropYMin(self: depthai.ImageManipConfig) -> float

        Returns:
            Top left Y coordinate of crop region
        """
    def getFormatConfig(self) -> RawImageManipConfig.FormatConfig:
        """getFormatConfig(self: depthai.ImageManipConfig) -> depthai.RawImageManipConfig.FormatConfig

        Returns:
            Format configuration
        """
    def getInterpolation(self) -> Interpolation:
        """getInterpolation(self: depthai.ImageManipConfig) -> depthai.Interpolation

        Retrieve which interpolation method to use
        """
    def getResizeConfig(self) -> RawImageManipConfig.ResizeConfig:
        """getResizeConfig(self: depthai.ImageManipConfig) -> depthai.RawImageManipConfig.ResizeConfig

        Returns:
            Resize configuration
        """
    def getResizeHeight(self) -> int:
        """getResizeHeight(self: depthai.ImageManipConfig) -> int

        Returns:
            Output image height
        """
    def getResizeWidth(self) -> int:
        """getResizeWidth(self: depthai.ImageManipConfig) -> int

        Returns:
            Output image width
        """
    def isResizeThumbnail(self) -> bool:
        """isResizeThumbnail(self: depthai.ImageManipConfig) -> bool

        Returns:
            True if resize thumbnail mode is set, false otherwise
        """
    def set(self, config: RawImageManipConfig) -> ImageManipConfig:
        """set(self: depthai.ImageManipConfig, config: depthai.RawImageManipConfig) -> depthai.ImageManipConfig

        Set explicit configuration.

        Parameter ``config``:
            Explicit configuration
        """
    def setCenterCrop(self, ratio: float, whRatio: float = ...) -> ImageManipConfig:
        """setCenterCrop(self: depthai.ImageManipConfig, ratio: float, whRatio: float = 1.0) -> depthai.ImageManipConfig

        Specifies a centered crop.

        Parameter ``ratio``:
            Ratio between input image and crop region (0..1)

        Parameter ``whRatio``:
            Crop region aspect ratio - 1 equals to square, 1.7 equals to 16:9, ...
        """
    @overload
    def setColormap(self, colormap: Colormap, min: int, max: int) -> ImageManipConfig:
        """setColormap(*args, **kwargs)
        Overloaded function.

        1. setColormap(self: depthai.ImageManipConfig, colormap: depthai.Colormap, min: int, max: int) -> depthai.ImageManipConfig

        Specify gray to color conversion map

        Parameter ``colormap``:
            map from Colormap enum or Colormap::NONE to disable

        2. setColormap(self: depthai.ImageManipConfig, colormap: depthai.Colormap, max: int = 255) -> depthai.ImageManipConfig

        Specify gray to color conversion map

        Parameter ``colormap``:
            map from Colormap enum or Colormap::NONE to disable

        3. setColormap(self: depthai.ImageManipConfig, colormap: depthai.Colormap, max: float = 255.0) -> depthai.ImageManipConfig

        Specify gray to color conversion map

        Parameter ``colormap``:
            map from Colormap enum or Colormap::NONE to disable
        """
    @overload
    def setColormap(self, colormap: Colormap, max: int = ...) -> ImageManipConfig:
        """setColormap(*args, **kwargs)
        Overloaded function.

        1. setColormap(self: depthai.ImageManipConfig, colormap: depthai.Colormap, min: int, max: int) -> depthai.ImageManipConfig

        Specify gray to color conversion map

        Parameter ``colormap``:
            map from Colormap enum or Colormap::NONE to disable

        2. setColormap(self: depthai.ImageManipConfig, colormap: depthai.Colormap, max: int = 255) -> depthai.ImageManipConfig

        Specify gray to color conversion map

        Parameter ``colormap``:
            map from Colormap enum or Colormap::NONE to disable

        3. setColormap(self: depthai.ImageManipConfig, colormap: depthai.Colormap, max: float = 255.0) -> depthai.ImageManipConfig

        Specify gray to color conversion map

        Parameter ``colormap``:
            map from Colormap enum or Colormap::NONE to disable
        """
    @overload
    def setColormap(self, colormap: Colormap, max: float = ...) -> ImageManipConfig:
        """setColormap(*args, **kwargs)
        Overloaded function.

        1. setColormap(self: depthai.ImageManipConfig, colormap: depthai.Colormap, min: int, max: int) -> depthai.ImageManipConfig

        Specify gray to color conversion map

        Parameter ``colormap``:
            map from Colormap enum or Colormap::NONE to disable

        2. setColormap(self: depthai.ImageManipConfig, colormap: depthai.Colormap, max: int = 255) -> depthai.ImageManipConfig

        Specify gray to color conversion map

        Parameter ``colormap``:
            map from Colormap enum or Colormap::NONE to disable

        3. setColormap(self: depthai.ImageManipConfig, colormap: depthai.Colormap, max: float = 255.0) -> depthai.ImageManipConfig

        Specify gray to color conversion map

        Parameter ``colormap``:
            map from Colormap enum or Colormap::NONE to disable
        """
    @overload
    def setCropRect(self, xmin: float, ymin: float, xmax: float, ymax: float) -> ImageManipConfig:
        """setCropRect(*args, **kwargs)
        Overloaded function.

        1. setCropRect(self: depthai.ImageManipConfig, xmin: float, ymin: float, xmax: float, ymax: float) -> depthai.ImageManipConfig

        Specifies crop with rectangle with normalized values (0..1)

        Parameter ``xmin``:
            Top left X coordinate of rectangle

        Parameter ``ymin``:
            Top left Y coordinate of rectangle

        Parameter ``xmax``:
            Bottom right X coordinate of rectangle

        Parameter ``ymax``:
            Bottom right Y coordinate of rectangle

        2. setCropRect(self: depthai.ImageManipConfig, coordinates: tuple[float, float, float, float]) -> depthai.ImageManipConfig

        Specifies crop with rectangle with normalized values (0..1)

        Parameter ``coordinates``:
            Coordinate of rectangle
        """
    @overload
    def setCropRect(self, coordinates: tuple[float, float, float, float]) -> ImageManipConfig:
        """setCropRect(*args, **kwargs)
        Overloaded function.

        1. setCropRect(self: depthai.ImageManipConfig, xmin: float, ymin: float, xmax: float, ymax: float) -> depthai.ImageManipConfig

        Specifies crop with rectangle with normalized values (0..1)

        Parameter ``xmin``:
            Top left X coordinate of rectangle

        Parameter ``ymin``:
            Top left Y coordinate of rectangle

        Parameter ``xmax``:
            Bottom right X coordinate of rectangle

        Parameter ``ymax``:
            Bottom right Y coordinate of rectangle

        2. setCropRect(self: depthai.ImageManipConfig, coordinates: tuple[float, float, float, float]) -> depthai.ImageManipConfig

        Specifies crop with rectangle with normalized values (0..1)

        Parameter ``coordinates``:
            Coordinate of rectangle
        """
    def setCropRotatedRect(self, rr: RotatedRect, normalizedCoords: bool = ...) -> ImageManipConfig:
        """setCropRotatedRect(self: depthai.ImageManipConfig, rr: depthai.RotatedRect, normalizedCoords: bool = True) -> depthai.ImageManipConfig

        Specifies crop with rotated rectangle. Optionally as non normalized coordinates

        Parameter ``rr``:
            Rotated rectangle which specifies crop

        Parameter ``normalizedCoords``:
            If true coordinates are in normalized range (0..1) otherwise absolute
        """
    def setFrameType(self, type: RawImgFrame.Type) -> ImageManipConfig:
        """setFrameType(self: depthai.ImageManipConfig, type: depthai.RawImgFrame.Type) -> depthai.ImageManipConfig

        Specify output frame type.

        Parameter ``name``:
            Frame type
        """
    def setHorizontalFlip(self, flip: bool) -> ImageManipConfig:
        """setHorizontalFlip(self: depthai.ImageManipConfig, flip: bool) -> depthai.ImageManipConfig

        Specify horizontal flip

        Parameter ``flip``:
            True to enable flip, false otherwise
        """
    def setInterpolation(self, interpolation: Interpolation) -> ImageManipConfig:
        """setInterpolation(self: depthai.ImageManipConfig, interpolation: depthai.Interpolation) -> depthai.ImageManipConfig

        Specify which interpolation method to use

        Parameter ``interpolation``:
            type of interpolation
        """
    def setKeepAspectRatio(self, keep: bool) -> ImageManipConfig:
        """setKeepAspectRatio(self: depthai.ImageManipConfig, keep: bool) -> depthai.ImageManipConfig

        Specifies to whether to keep aspect ratio or not
        """
    @overload
    def setResize(self, w: int, h: int) -> ImageManipConfig:
        """setResize(*args, **kwargs)
        Overloaded function.

        1. setResize(self: depthai.ImageManipConfig, w: int, h: int) -> depthai.ImageManipConfig

        Specifies output image size. After crop stage the image will be stretched to
        fit.

        Parameter ``w``:
            Width in pixels

        Parameter ``h``:
            Height in pixels

        2. setResize(self: depthai.ImageManipConfig, size: tuple[int, int]) -> depthai.ImageManipConfig

        Specifies output image size. After crop stage the image will be stretched to
        fit.

        Parameter ``size``:
            Size in pixels
        """
    @overload
    def setResize(self, size: tuple[int, int]) -> ImageManipConfig:
        """setResize(*args, **kwargs)
        Overloaded function.

        1. setResize(self: depthai.ImageManipConfig, w: int, h: int) -> depthai.ImageManipConfig

        Specifies output image size. After crop stage the image will be stretched to
        fit.

        Parameter ``w``:
            Width in pixels

        Parameter ``h``:
            Height in pixels

        2. setResize(self: depthai.ImageManipConfig, size: tuple[int, int]) -> depthai.ImageManipConfig

        Specifies output image size. After crop stage the image will be stretched to
        fit.

        Parameter ``size``:
            Size in pixels
        """
    @overload
    def setResizeThumbnail(self, w: int, h: int, bgRed: int = ..., bgGreen: int = ..., bgBlue: int = ...) -> ImageManipConfig:
        """setResizeThumbnail(*args, **kwargs)
        Overloaded function.

        1. setResizeThumbnail(self: depthai.ImageManipConfig, w: int, h: int, bgRed: int = 0, bgGreen: int = 0, bgBlue: int = 0) -> depthai.ImageManipConfig

        Specifies output image size. After crop stage the image will be resized by
        preserving aspect ration. Optionally background can be specified.

        Parameter ``w``:
            Width in pixels

        Parameter ``h``:
            Height in pixels

        Parameter ``bgRed``:
            Red component

        Parameter ``bgGreen``:
            Green component

        Parameter ``bgBlue``:
            Blue component

        2. setResizeThumbnail(self: depthai.ImageManipConfig, size: tuple[int, int], bgRed: int = 0, bgGreen: int = 0, bgBlue: int = 0) -> depthai.ImageManipConfig

        Specifies output image size. After crop stage the image will be resized by
        preserving aspect ration. Optionally background can be specified.

        Parameter ``size``:
            Size in pixels

        Parameter ``bgRed``:
            Red component

        Parameter ``bgGreen``:
            Green component

        Parameter ``bgBlue``:
            Blue component
        """
    @overload
    def setResizeThumbnail(self, size: tuple[int, int], bgRed: int = ..., bgGreen: int = ..., bgBlue: int = ...) -> ImageManipConfig:
        """setResizeThumbnail(*args, **kwargs)
        Overloaded function.

        1. setResizeThumbnail(self: depthai.ImageManipConfig, w: int, h: int, bgRed: int = 0, bgGreen: int = 0, bgBlue: int = 0) -> depthai.ImageManipConfig

        Specifies output image size. After crop stage the image will be resized by
        preserving aspect ration. Optionally background can be specified.

        Parameter ``w``:
            Width in pixels

        Parameter ``h``:
            Height in pixels

        Parameter ``bgRed``:
            Red component

        Parameter ``bgGreen``:
            Green component

        Parameter ``bgBlue``:
            Blue component

        2. setResizeThumbnail(self: depthai.ImageManipConfig, size: tuple[int, int], bgRed: int = 0, bgGreen: int = 0, bgBlue: int = 0) -> depthai.ImageManipConfig

        Specifies output image size. After crop stage the image will be resized by
        preserving aspect ration. Optionally background can be specified.

        Parameter ``size``:
            Size in pixels

        Parameter ``bgRed``:
            Red component

        Parameter ``bgGreen``:
            Green component

        Parameter ``bgBlue``:
            Blue component
        """
    def setReusePreviousImage(self, reuse: bool) -> ImageManipConfig:
        """setReusePreviousImage(self: depthai.ImageManipConfig, reuse: bool) -> depthai.ImageManipConfig

        Instruct ImageManip to not remove current image from its queue and use the same
        for next message.

        Parameter ``reuse``:
            True to enable reuse, false otherwise
        """
    def setRotationDegrees(self, deg: float) -> ImageManipConfig:
        """setRotationDegrees(self: depthai.ImageManipConfig, deg: float) -> depthai.ImageManipConfig

        Specifies clockwise rotation in degrees

        Parameter ``deg``:
            Rotation in degrees
        """
    def setRotationRadians(self, rad: float) -> ImageManipConfig:
        """setRotationRadians(self: depthai.ImageManipConfig, rad: float) -> depthai.ImageManipConfig

        Specifies clockwise rotation in radians

        Parameter ``rad``:
            Rotation in radians
        """
    def setSkipCurrentImage(self, skip: bool) -> ImageManipConfig:
        """setSkipCurrentImage(self: depthai.ImageManipConfig, skip: bool) -> depthai.ImageManipConfig

        Instructs ImageManip to skip current image and wait for next in queue.

        Parameter ``skip``:
            True to skip current image, false otherwise
        """
    def setVerticalFlip(self, flip: bool) -> None:
        """setVerticalFlip(self: depthai.ImageManipConfig, flip: bool) -> None

        Specify vertical flip

        Parameter ``flip``:
            True to enable vertical flip, false otherwise
        """
    def setWarpBorderFillColor(self, red: int, green: int, blue: int) -> ImageManipConfig:
        """setWarpBorderFillColor(self: depthai.ImageManipConfig, red: int, green: int, blue: int) -> depthai.ImageManipConfig

        Specifies fill color for border pixels. Example:

        - setWarpBorderFillColor(255,255,255) -> white

        - setWarpBorderFillColor(0,0,255) -> blue

        Parameter ``red``:
            Red component

        Parameter ``green``:
            Green component

        Parameter ``blue``:
            Blue component
        """
    def setWarpBorderReplicatePixels(self) -> ImageManipConfig:
        """setWarpBorderReplicatePixels(self: depthai.ImageManipConfig) -> depthai.ImageManipConfig

        Specifies that warp replicates border pixels
        """
    def setWarpTransformFourPoints(self, pt: list[Point2f], normalizedCoords: bool) -> ImageManipConfig:
        """setWarpTransformFourPoints(self: depthai.ImageManipConfig, pt: list[depthai.Point2f], normalizedCoords: bool) -> depthai.ImageManipConfig

        Specifies warp by supplying 4 points in either absolute or normalized
        coordinates

        Parameter ``pt``:
            4 points specifying warp

        Parameter ``normalizedCoords``:
            If true pt is interpreted as normalized, absolute otherwise
        """
    def setWarpTransformMatrix3x3(self, mat: list[float]) -> ImageManipConfig:
        """setWarpTransformMatrix3x3(self: depthai.ImageManipConfig, mat: list[float]) -> depthai.ImageManipConfig

        Specifies warp with a 3x3 matrix

        Parameter ``mat``:
            3x3 matrix
        """

class ImgDetection:
    confidence: float
    label: int
    xmax: float
    xmin: float
    ymax: float
    ymin: float
    def __init__(self) -> None:
        """__init__(self: depthai.ImgDetection) -> None"""

class ImgDetections(Buffer):
    detections: list[ImgDetection]
    def __init__(self) -> None:
        """__init__(self: depthai.ImgDetections) -> None

        Construct ImgDetections message
        """
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.ImgDetections) -> int

        Retrieves sequence number
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.ImgDetections) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.ImgDetections) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """
    def setSequenceNum(self, arg0: int) -> ImgDetections:
        """setSequenceNum(self: depthai.ImgDetections, arg0: int) -> depthai.ImgDetections

        Retrieves image sequence number
        """
    def setTimestamp(self, arg0: datetime.timedelta) -> ImgDetections:
        """setTimestamp(self: depthai.ImgDetections, arg0: datetime.timedelta) -> depthai.ImgDetections

        Sets image timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> ImgDetections:
        """setTimestampDevice(self: depthai.ImgDetections, arg0: datetime.timedelta) -> depthai.ImgDetections

        Sets image timestamp related to dai::Clock::now()
        """

class ImgFrame(Buffer):
    class Specs:
        bytesPP: int
        height: int
        p1Offset: int
        p2Offset: int
        p3Offset: int
        stride: int
        type: RawImgFrame.Type
        width: int
        def __init__(self) -> None:
            """__init__(self: depthai.RawImgFrame.Specs) -> None"""

    class Type:
        __members__: ClassVar[dict] = ...  # read-only
        BGR888i: ClassVar[RawImgFrame.Type] = ...
        BGR888p: ClassVar[RawImgFrame.Type] = ...
        BGRF16F16F16i: ClassVar[RawImgFrame.Type] = ...
        BGRF16F16F16p: ClassVar[RawImgFrame.Type] = ...
        BITSTREAM: ClassVar[RawImgFrame.Type] = ...
        GRAY8: ClassVar[RawImgFrame.Type] = ...
        GRAYF16: ClassVar[RawImgFrame.Type] = ...
        HDR: ClassVar[RawImgFrame.Type] = ...
        LUT16: ClassVar[RawImgFrame.Type] = ...
        LUT2: ClassVar[RawImgFrame.Type] = ...
        LUT4: ClassVar[RawImgFrame.Type] = ...
        NONE: ClassVar[RawImgFrame.Type] = ...
        NV12: ClassVar[RawImgFrame.Type] = ...
        NV21: ClassVar[RawImgFrame.Type] = ...
        PACK10: ClassVar[RawImgFrame.Type] = ...
        PACK12: ClassVar[RawImgFrame.Type] = ...
        RAW10: ClassVar[RawImgFrame.Type] = ...
        RAW12: ClassVar[RawImgFrame.Type] = ...
        RAW14: ClassVar[RawImgFrame.Type] = ...
        RAW16: ClassVar[RawImgFrame.Type] = ...
        RAW8: ClassVar[RawImgFrame.Type] = ...
        RGB161616: ClassVar[RawImgFrame.Type] = ...
        RGB888i: ClassVar[RawImgFrame.Type] = ...
        RGB888p: ClassVar[RawImgFrame.Type] = ...
        RGBA8888: ClassVar[RawImgFrame.Type] = ...
        RGBF16F16F16i: ClassVar[RawImgFrame.Type] = ...
        RGBF16F16F16p: ClassVar[RawImgFrame.Type] = ...
        YUV400p: ClassVar[RawImgFrame.Type] = ...
        YUV420p: ClassVar[RawImgFrame.Type] = ...
        YUV422i: ClassVar[RawImgFrame.Type] = ...
        YUV422p: ClassVar[RawImgFrame.Type] = ...
        YUV444i: ClassVar[RawImgFrame.Type] = ...
        YUV444p: ClassVar[RawImgFrame.Type] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawImgFrame.Type, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawImgFrame.Type) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawImgFrame.Type) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    def __init__(self) -> None:
        """__init__(self: depthai.ImgFrame) -> None"""
    def getCategory(self) -> int:
        """getCategory(self: depthai.ImgFrame) -> int

        Retrieves image category
        """
    def getColorTemperature(self) -> int:
        """getColorTemperature(self: depthai.ImgFrame) -> int

        Retrieves white-balance color temperature of the light source, in kelvins
        """
    def getCvFrame(self) -> numpy.ndarray:
        """getCvFrame(self: object) -> object

        Returns BGR or grayscale frame compatible with use in other opencv functions
        """
    def getExposureTime(self) -> datetime.timedelta:
        """getExposureTime(self: depthai.ImgFrame) -> datetime.timedelta

        Retrieves exposure time
        """
    def getFrame(self, copy: bool = ...) -> numpy.ndarray:
        """getFrame(self: object, copy: bool = False) -> numpy.ndarray

        Returns numpy array with shape as specified by width, height and type
        """
    def getHeight(self) -> int:
        """getHeight(self: depthai.ImgFrame) -> int

        Retrieves image height in pixels
        """
    def getInstanceNum(self) -> int:
        """getInstanceNum(self: depthai.ImgFrame) -> int

        Retrieves instance number
        """
    def getLensPosition(self) -> int:
        """getLensPosition(self: depthai.ImgFrame) -> int

        Retrieves lens position, range 0..255. Returns -1 if not available
        """
    def getLensPositionRaw(self) -> float:
        """getLensPositionRaw(self: depthai.ImgFrame) -> float

        Retrieves lens position, range 0.0f..1.0f. Returns -1 if not available
        """
    def getSensitivity(self) -> int:
        """getSensitivity(self: depthai.ImgFrame) -> int

        Retrieves sensitivity, as an ISO value
        """
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.ImgFrame) -> int

        Retrieves sequence number
        """
    @overload
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(*args, **kwargs)
        Overloaded function.

        1. getTimestamp(self: depthai.ImgFrame) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()

        2. getTimestamp(self: depthai.ImgFrame, offset: depthai.CameraExposureOffset) -> datetime.timedelta

        Retrieves image timestamp (at the specified offset of exposure) related to
        dai::Clock::now()
        """
    @overload
    def getTimestamp(self, offset: CameraExposureOffset) -> datetime.timedelta:
        """getTimestamp(*args, **kwargs)
        Overloaded function.

        1. getTimestamp(self: depthai.ImgFrame) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()

        2. getTimestamp(self: depthai.ImgFrame, offset: depthai.CameraExposureOffset) -> datetime.timedelta

        Retrieves image timestamp (at the specified offset of exposure) related to
        dai::Clock::now()
        """
    @overload
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(*args, **kwargs)
        Overloaded function.

        1. getTimestampDevice(self: depthai.ImgFrame) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging

        2. getTimestampDevice(self: depthai.ImgFrame, offset: depthai.CameraExposureOffset) -> datetime.timedelta

        Retrieves image timestamp (at the specified offset of exposure) directly
        captured from device's monotonic clock, not synchronized to host time. Used when
        monotonicity is required.
        """
    @overload
    def getTimestampDevice(self, offset: CameraExposureOffset) -> datetime.timedelta:
        """getTimestampDevice(*args, **kwargs)
        Overloaded function.

        1. getTimestampDevice(self: depthai.ImgFrame) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging

        2. getTimestampDevice(self: depthai.ImgFrame, offset: depthai.CameraExposureOffset) -> datetime.timedelta

        Retrieves image timestamp (at the specified offset of exposure) directly
        captured from device's monotonic clock, not synchronized to host time. Used when
        monotonicity is required.
        """
    def getType(self) -> RawImgFrame.Type:
        """getType(self: depthai.ImgFrame) -> depthai.RawImgFrame.Type

        Retrieves image type
        """
    def getWidth(self) -> int:
        """getWidth(self: depthai.ImgFrame) -> int

        Retrieves image width in pixels
        """
    def setCategory(self, category: int) -> ImgFrame:
        """setCategory(self: depthai.ImgFrame, category: int) -> depthai.ImgFrame

        Parameter ``category``:
            Image category
        """
    def setFrame(self, array: numpy.ndarray) -> None:
        """setFrame(self: depthai.ImgFrame, array: numpy.ndarray) -> None

        Copies array bytes to ImgFrame buffer
        """
    def setHeight(self, height: int) -> ImgFrame:
        """setHeight(self: depthai.ImgFrame, height: int) -> depthai.ImgFrame

        Specifies frame height

        Parameter ``height``:
            frame height
        """
    def setInstanceNum(self, instance: int) -> ImgFrame:
        """setInstanceNum(self: depthai.ImgFrame, instance: int) -> depthai.ImgFrame

        Instance number relates to the origin of the frame (which camera)

        Parameter ``instance``:
            Instance number
        """
    def setSequenceNum(self, seq: int) -> ImgFrame:
        """setSequenceNum(self: depthai.ImgFrame, seq: int) -> depthai.ImgFrame

        Specifies sequence number

        Parameter ``seq``:
            Sequence number
        """
    @overload
    def setSize(self, width: int, height: int) -> ImgFrame:
        """setSize(*args, **kwargs)
        Overloaded function.

        1. setSize(self: depthai.ImgFrame, width: int, height: int) -> depthai.ImgFrame

        Specifies frame size

        Parameter ``height``:
            frame height

        Parameter ``width``:
            frame width

        2. setSize(self: depthai.ImgFrame, sizer: tuple[int, int]) -> depthai.ImgFrame

        Specifies frame size

        Parameter ``size``:
            frame size
        """
    @overload
    def setSize(self, sizer: tuple[int, int]) -> ImgFrame:
        """setSize(*args, **kwargs)
        Overloaded function.

        1. setSize(self: depthai.ImgFrame, width: int, height: int) -> depthai.ImgFrame

        Specifies frame size

        Parameter ``height``:
            frame height

        Parameter ``width``:
            frame width

        2. setSize(self: depthai.ImgFrame, sizer: tuple[int, int]) -> depthai.ImgFrame

        Specifies frame size

        Parameter ``size``:
            frame size
        """
    def setTimestamp(self, timestamp: datetime.timedelta) -> ImgFrame:
        """setTimestamp(self: depthai.ImgFrame, timestamp: datetime.timedelta) -> depthai.ImgFrame

        Retrieves image timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> ImgFrame:
        """setTimestampDevice(self: depthai.ImgFrame, arg0: datetime.timedelta) -> depthai.ImgFrame

        Sets image timestamp related to dai::Clock::now()
        """
    def setType(self, type: RawImgFrame.Type) -> ImgFrame:
        """setType(self: depthai.ImgFrame, type: depthai.RawImgFrame.Type) -> depthai.ImgFrame

        Specifies frame type, RGB, BGR, ...

        Parameter ``type``:
            Type of image
        """
    def setWidth(self, width: int) -> ImgFrame:
        """setWidth(self: depthai.ImgFrame, width: int) -> depthai.ImgFrame

        Specifies frame width

        Parameter ``width``:
            frame width
        """

class Interpolation:
    __members__: ClassVar[dict] = ...  # read-only
    BICUBIC: ClassVar[Interpolation] = ...
    BILINEAR: ClassVar[Interpolation] = ...
    BYPASS: ClassVar[Interpolation] = ...
    DEFAULT: ClassVar[Interpolation] = ...
    DEFAULT_DISPARITY_DEPTH: ClassVar[Interpolation] = ...
    NEAREST_NEIGHBOR: ClassVar[Interpolation] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.Interpolation, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.Interpolation) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.Interpolation) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class LogLevel:
    __members__: ClassVar[dict] = ...  # read-only
    CRITICAL: ClassVar[LogLevel] = ...
    DEBUG: ClassVar[LogLevel] = ...
    ERR: ClassVar[LogLevel] = ...
    INFO: ClassVar[LogLevel] = ...
    OFF: ClassVar[LogLevel] = ...
    TRACE: ClassVar[LogLevel] = ...
    WARN: ClassVar[LogLevel] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.LogLevel, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.LogLevel) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.LogLevel) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class LogMessage:
    colorRangeEnd: int
    colorRangeStart: int
    level: LogLevel
    nodeIdName: str
    payload: str
    time: Timestamp
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class MedianFilter:
    __members__: ClassVar[dict] = ...  # read-only
    KERNEL_3x3: ClassVar[MedianFilter] = ...
    KERNEL_5x5: ClassVar[MedianFilter] = ...
    KERNEL_7x7: ClassVar[MedianFilter] = ...
    MEDIAN_OFF: ClassVar[MedianFilter] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.MedianFilter, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.MedianFilter) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.MedianFilter) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class MemoryInfo:
    remaining: int
    total: int
    used: int
    def __init__(self) -> None:
        """__init__(self: depthai.MemoryInfo) -> None"""

class MessageDemuxProperties:
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class MessageGroup(Buffer):
    def __init__(self) -> None:
        """__init__(self: depthai.MessageGroup) -> None"""
    def getIntervalNs(self) -> int:
        """getIntervalNs(self: depthai.MessageGroup) -> int

        Retrieves interval between the first and the last message in the group.
        """
    def getMessageNames(self) -> list[str]:
        """getMessageNames(self: depthai.MessageGroup) -> list[str]

        Gets the names of messages in the group
        """
    def getNumMessages(self) -> int:
        """getNumMessages(self: depthai.MessageGroup) -> int"""
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.MessageGroup) -> int

        Retrieves sequence number
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.MessageGroup) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.MessageGroup) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """
    def isSynced(self, arg0: int) -> bool:
        """isSynced(self: depthai.MessageGroup, arg0: int) -> bool

        True if all messages in the group are in the interval

        Parameter ``thresholdNs``:
            Maximal interval between messages
        """
    def setSequenceNum(self, arg0: int) -> MessageGroup:
        """setSequenceNum(self: depthai.MessageGroup, arg0: int) -> depthai.MessageGroup

        Retrieves image sequence number
        """
    def setTimestamp(self, arg0: datetime.timedelta) -> MessageGroup:
        """setTimestamp(self: depthai.MessageGroup, arg0: datetime.timedelta) -> depthai.MessageGroup

        Sets image timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> MessageGroup:
        """setTimestampDevice(self: depthai.MessageGroup, arg0: datetime.timedelta) -> depthai.MessageGroup

        Sets image timestamp related to dai::Clock::now()
        """
    def __getitem__(self, arg0: str) -> ADatatype:
        """__getitem__(self: depthai.MessageGroup, arg0: str) -> depthai.ADatatype"""
    def __iter__(self) -> Iterator[tuple[str, ADatatype]]:
        """__iter__(self: depthai.MessageGroup) -> Iterator[tuple[str, depthai.ADatatype]]"""
    def __setitem__(self, arg0: str, arg1: ADatatype) -> None:
        """__setitem__(self: depthai.MessageGroup, arg0: str, arg1: depthai.ADatatype) -> None"""

class MonoCameraProperties:
    class SensorResolution:
        __members__: ClassVar[dict] = ...  # read-only
        THE_1200_P: ClassVar[MonoCameraProperties.SensorResolution] = ...
        THE_400_P: ClassVar[MonoCameraProperties.SensorResolution] = ...
        THE_480_P: ClassVar[MonoCameraProperties.SensorResolution] = ...
        THE_720_P: ClassVar[MonoCameraProperties.SensorResolution] = ...
        THE_800_P: ClassVar[MonoCameraProperties.SensorResolution] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.MonoCameraProperties.SensorResolution, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.MonoCameraProperties.SensorResolution) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.MonoCameraProperties.SensorResolution) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    boardSocket: CameraBoardSocket
    eventFilter: list[FrameEvent]
    fps: float
    initialControl: RawCameraControl
    isp3aFps: int
    numFramesPool: int
    numFramesPoolRaw: int
    resolution: MonoCameraProperties.SensorResolution
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class NNData(Buffer):
    def __init__(self) -> None:
        """__init__(self: depthai.NNData) -> None

        Construct NNData message.
        """
    def getAllLayerNames(self) -> list[str]:
        """getAllLayerNames(self: depthai.NNData) -> list[str]

        Returns:
            Names of all layers added
        """
    def getAllLayers(self) -> list[TensorInfo]:
        """getAllLayers(self: depthai.NNData) -> list[depthai.TensorInfo]

        Returns:
            All layers and their information
        """
    def getFirstLayerFp16(self) -> list[float]:
        """getFirstLayerFp16(self: depthai.NNData) -> list[float]

        Convenience function to retrieve float values from first layers FP16 tensor

        Returns:
            Float data
        """
    def getFirstLayerInt32(self) -> list[int]:
        """getFirstLayerInt32(self: depthai.NNData) -> list[int]

        Convenience function to retrieve INT32 values from first layers tensor

        Returns:
            INT32 data
        """
    def getFirstLayerUInt8(self) -> list[int]:
        """getFirstLayerUInt8(self: depthai.NNData) -> list[int]

        Convenience function to retrieve U8 data from first layer

        Returns:
            U8 binary data
        """
    def getLayer(self, name: str, tensor: TensorInfo) -> bool:
        """getLayer(self: depthai.NNData, name: str, tensor: depthai.TensorInfo) -> bool

        Retrieve layers tensor information

        Parameter ``name``:
            Name of the layer

        Parameter ``tensor``:
            Outputs tensor information of that layer

        Returns:
            True if layer exists, false otherwise
        """
    def getLayerDatatype(self, name: str, datatype: TensorInfo.DataType) -> bool:
        """getLayerDatatype(self: depthai.NNData, name: str, datatype: depthai.TensorInfo.DataType) -> bool

        Retrieve datatype of a layers tensor

        Parameter ``name``:
            Name of the layer

        Parameter ``datatype``:
            Datatype of layers tensor

        Returns:
            True if layer exists, false otherwise
        """
    def getLayerFp16(self, name: str) -> list[float]:
        """getLayerFp16(self: depthai.NNData, name: str) -> list[float]

        Convenience function to retrieve float values from layers FP16 tensor

        Parameter ``name``:
            Name of the layer

        Returns:
            Float data
        """
    def getLayerInt32(self, name: str) -> list[int]:
        """getLayerInt32(self: depthai.NNData, name: str) -> list[int]

        Convenience function to retrieve INT32 values from layers tensor

        Parameter ``name``:
            Name of the layer

        Returns:
            INT32 data
        """
    def getLayerUInt8(self, name: str) -> list[int]:
        """getLayerUInt8(self: depthai.NNData, name: str) -> list[int]

        Convenience function to retrieve U8 data from layer

        Parameter ``name``:
            Name of the layer

        Returns:
            U8 binary data
        """
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.NNData) -> int

        Retrieves sequence number
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.NNData) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.NNData) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """
    def hasLayer(self, name: str) -> bool:
        """hasLayer(self: depthai.NNData, name: str) -> bool

        Checks if given layer exists

        Parameter ``name``:
            Name of the layer

        Returns:
            True if layer exists, false otherwise
        """
    @overload
    def setLayer(self, name: str, data: numpy.ndarray[numpy.uint8]) -> None:
        """setLayer(*args, **kwargs)
        Overloaded function.

        1. setLayer(self: depthai.NNData, name: str, data: numpy.ndarray[numpy.uint8]) -> None

        Set a layer with datatype U8.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        2. setLayer(self: depthai.NNData, name: str, data: list[int]) -> depthai.NNData

        Set a layer with datatype U8. Integers are cast to bytes.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        3. setLayer(self: depthai.NNData, name: str, data: list[float]) -> depthai.NNData

        Set a layer with datatype FP16. Float values are converted to FP16.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        4. setLayer(self: depthai.NNData, name: str, data: list[float]) -> depthai.NNData

        Set a layer with datatype FP16. Double values are converted to FP16.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store
        """
    @overload
    def setLayer(self, name: str, data: list[int]) -> NNData:
        """setLayer(*args, **kwargs)
        Overloaded function.

        1. setLayer(self: depthai.NNData, name: str, data: numpy.ndarray[numpy.uint8]) -> None

        Set a layer with datatype U8.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        2. setLayer(self: depthai.NNData, name: str, data: list[int]) -> depthai.NNData

        Set a layer with datatype U8. Integers are cast to bytes.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        3. setLayer(self: depthai.NNData, name: str, data: list[float]) -> depthai.NNData

        Set a layer with datatype FP16. Float values are converted to FP16.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        4. setLayer(self: depthai.NNData, name: str, data: list[float]) -> depthai.NNData

        Set a layer with datatype FP16. Double values are converted to FP16.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store
        """
    @overload
    def setLayer(self, name: str, data: list[float]) -> NNData:
        """setLayer(*args, **kwargs)
        Overloaded function.

        1. setLayer(self: depthai.NNData, name: str, data: numpy.ndarray[numpy.uint8]) -> None

        Set a layer with datatype U8.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        2. setLayer(self: depthai.NNData, name: str, data: list[int]) -> depthai.NNData

        Set a layer with datatype U8. Integers are cast to bytes.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        3. setLayer(self: depthai.NNData, name: str, data: list[float]) -> depthai.NNData

        Set a layer with datatype FP16. Float values are converted to FP16.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        4. setLayer(self: depthai.NNData, name: str, data: list[float]) -> depthai.NNData

        Set a layer with datatype FP16. Double values are converted to FP16.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store
        """
    @overload
    def setLayer(self, name: str, data: list[float]) -> NNData:
        """setLayer(*args, **kwargs)
        Overloaded function.

        1. setLayer(self: depthai.NNData, name: str, data: numpy.ndarray[numpy.uint8]) -> None

        Set a layer with datatype U8.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        2. setLayer(self: depthai.NNData, name: str, data: list[int]) -> depthai.NNData

        Set a layer with datatype U8. Integers are cast to bytes.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        3. setLayer(self: depthai.NNData, name: str, data: list[float]) -> depthai.NNData

        Set a layer with datatype FP16. Float values are converted to FP16.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store

        4. setLayer(self: depthai.NNData, name: str, data: list[float]) -> depthai.NNData

        Set a layer with datatype FP16. Double values are converted to FP16.

        Parameter ``name``:
            Name of the layer

        Parameter ``data``:
            Data to store
        """
    def setSequenceNum(self, arg0: int) -> NNData:
        """setSequenceNum(self: depthai.NNData, arg0: int) -> depthai.NNData

        Retrieves image sequence number
        """
    def setTimestamp(self, arg0: datetime.timedelta) -> NNData:
        """setTimestamp(self: depthai.NNData, arg0: datetime.timedelta) -> depthai.NNData

        Sets image timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> NNData:
        """setTimestampDevice(self: depthai.NNData, arg0: datetime.timedelta) -> depthai.NNData

        Sets image timestamp related to dai::Clock::now()
        """

class NeuralNetworkProperties:
    blobSize: int | None
    blobUri: str
    numFrames: int
    numNCEPerThread: int
    numThreads: int
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class Node:
    class Connection:
        inputGroup: str
        inputId: int
        inputName: str
        outputGroup: str
        outputId: int
        outputName: str
        def __init__(self, *args, **kwargs) -> None:
            """Initialize self.  See help(type(self)) for accurate signature."""

    class DatatypeHierarchy:
        datatype: DatatypeEnum
        descendants: bool
        def __init__(self, arg0: DatatypeEnum, arg1: bool) -> None:
            """__init__(self: depthai.Node.DatatypeHierarchy, arg0: depthai.DatatypeEnum, arg1: bool) -> None"""

    class Id:
        def __init__(self, *args, **kwargs) -> None:
            """Initialize self.  See help(type(self)) for accurate signature."""

    class Input:
        class Type:
            __members__: ClassVar[dict] = ...  # read-only
            MReceiver: ClassVar[Node.Input.Type] = ...
            SReceiver: ClassVar[Node.Input.Type] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.Node.Input.Type, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.Node.Input.Type) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.Node.Input.Type) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...
        group: str
        name: str
        possibleDatatypes: list[Node.DatatypeHierarchy]
        type: Node.Input.Type
        waitForMessage: bool | None
        def __init__(self, *args, **kwargs) -> None:
            """Initialize self.  See help(type(self)) for accurate signature."""
        def getBlocking(self) -> bool:
            """getBlocking(self: depthai.Node.Input) -> bool

            Get input queue behavior

            Returns:
                True blocking, false overwriting
            """
        @overload
        def getParent(self) -> Node:
            """getParent(*args, **kwargs)
            Overloaded function.

            1. getParent(self: depthai.Node.Input) -> depthai.Node

            2. getParent(self: depthai.Node.Input) -> depthai.Node
            """
        @overload
        def getParent(self) -> Node:
            """getParent(*args, **kwargs)
            Overloaded function.

            1. getParent(self: depthai.Node.Input) -> depthai.Node

            2. getParent(self: depthai.Node.Input) -> depthai.Node
            """
        def getQueueSize(self) -> int:
            """getQueueSize(self: depthai.Node.Input) -> int

            Get input queue size.

            Returns:
                Maximum input queue size
            """
        def getReusePreviousMessage(self) -> bool:
            """getReusePreviousMessage(self: depthai.Node.Input) -> bool

            Equivalent to getWaitForMessage but with inverted logic.
            """
        def getWaitForMessage(self) -> bool:
            """getWaitForMessage(self: depthai.Node.Input) -> bool

            Get behavior whether to wait for this input when a Node processes certain data
            or not

            Returns:
                Whether to wait for message to arrive to this input or not
            """
        def setBlocking(self, blocking: bool) -> None:
            """setBlocking(self: depthai.Node.Input, blocking: bool) -> None

            Overrides default input queue behavior.

            Parameter ``blocking``:
                True blocking, false overwriting
            """
        def setQueueSize(self, size: int) -> None:
            """setQueueSize(self: depthai.Node.Input, size: int) -> None

            Overrides default input queue size. If queue size fills up, behavior depends on
            `blocking` attribute

            Parameter ``size``:
                Maximum input queue size
            """
        def setReusePreviousMessage(self, reusePreviousMessage: bool) -> None:
            """setReusePreviousMessage(self: depthai.Node.Input, reusePreviousMessage: bool) -> None

            Equivalent to setWaitForMessage but with inverted logic.
            """
        def setWaitForMessage(self, waitForMessage: bool) -> None:
            """setWaitForMessage(self: depthai.Node.Input, waitForMessage: bool) -> None

            Overrides default wait for message behavior. Applicable for nodes with multiple
            inputs. Specifies behavior whether to wait for this input when a Node processes
            certain data or not.

            Parameter ``waitForMessage``:
                Whether to wait for message to arrive to this input or not
            """

    class InputMap:
        def __init__(self, *args, **kwargs) -> None:
            """Initialize self.  See help(type(self)) for accurate signature."""
        def items(self) -> Iterator[tuple[str, Node.Input]]:
            """items(self: depthai.Node.InputMap) -> Iterator[tuple[str, depthai.Node.Input]]"""
        def __bool__(self) -> bool:
            """__bool__(self: depthai.Node.InputMap) -> bool

            Check whether the map is nonempty
            """
        def __contains__(self, arg0: str) -> bool:
            """__contains__(self: depthai.Node.InputMap, arg0: str) -> bool"""
        def __delitem__(self, arg0: str) -> None:
            """__delitem__(self: depthai.Node.InputMap, arg0: str) -> None"""
        def __getitem__(self, arg0: str) -> Node.Input:
            """__getitem__(self: depthai.Node.InputMap, arg0: str) -> depthai.Node.Input"""
        def __iter__(self) -> Iterator[str]:
            """__iter__(self: depthai.Node.InputMap) -> Iterator[str]"""
        def __len__(self) -> int:
            """__len__(self: depthai.Node.InputMap) -> int"""
        def __setitem__(self, arg0: str, arg1: Node.Input) -> None:
            """__setitem__(self: depthai.Node.InputMap, arg0: str, arg1: depthai.Node.Input) -> None"""

    class Output:
        class Type:
            __members__: ClassVar[dict] = ...  # read-only
            MSender: ClassVar[Node.Output.Type] = ...
            SSender: ClassVar[Node.Output.Type] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.Node.Output.Type, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.Node.Output.Type) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.Node.Output.Type) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...
        group: str
        name: str
        possibleDatatypes: list[Node.DatatypeHierarchy]
        type: Node.Output.Type
        def __init__(self, *args, **kwargs) -> None:
            """Initialize self.  See help(type(self)) for accurate signature."""
        def canConnect(self, input: Node.Input) -> bool:
            """canConnect(self: depthai.Node.Output, input: depthai.Node.Input) -> bool

            Check if connection is possible

            Parameter ``in``:
                Input to connect to

            Returns:
                True if connection is possible, false otherwise
            """
        def getConnections(self) -> list[Node.Connection]:
            """getConnections(self: depthai.Node.Output) -> list[depthai.Node.Connection]

            Retrieve all connections from this output

            Returns:
                Vector of connections
            """
        @overload
        def getParent(self) -> Node:
            """getParent(*args, **kwargs)
            Overloaded function.

            1. getParent(self: depthai.Node.Output) -> depthai.Node

            2. getParent(self: depthai.Node.Output) -> depthai.Node
            """
        @overload
        def getParent(self) -> Node:
            """getParent(*args, **kwargs)
            Overloaded function.

            1. getParent(self: depthai.Node.Output) -> depthai.Node

            2. getParent(self: depthai.Node.Output) -> depthai.Node
            """
        def isSamePipeline(self, input: Node.Input) -> bool:
            """isSamePipeline(self: depthai.Node.Output, input: depthai.Node.Input) -> bool

            Check if this output and given input are on the same pipeline.

            See also:
                canConnect for checking if connection is possible

            Returns:
                True if output and input are on the same pipeline
            """
        def link(self, input: Node.Input) -> None:
            """link(self: depthai.Node.Output, input: depthai.Node.Input) -> None

            Link current output to input.

            Throws an error if this output cannot be linked to given input, or if they are
            already linked

            Parameter ``in``:
                Input to link to
            """
        def unlink(self, input: Node.Input) -> None:
            """unlink(self: depthai.Node.Output, input: depthai.Node.Input) -> None

            Unlink a previously linked connection

            Throws an error if not linked.

            Parameter ``in``:
                Input from which to unlink from
            """

    class OutputMap:
        def __init__(self, *args, **kwargs) -> None:
            """Initialize self.  See help(type(self)) for accurate signature."""
        def items(self) -> Iterator[tuple[str, Node.Output]]:
            """items(self: depthai.Node.OutputMap) -> Iterator[tuple[str, depthai.Node.Output]]"""
        def __bool__(self) -> bool:
            """__bool__(self: depthai.Node.OutputMap) -> bool

            Check whether the map is nonempty
            """
        def __contains__(self, arg0: str) -> bool:
            """__contains__(self: depthai.Node.OutputMap, arg0: str) -> bool"""
        def __delitem__(self, arg0: str) -> None:
            """__delitem__(self: depthai.Node.OutputMap, arg0: str) -> None"""
        def __getitem__(self, arg0: str) -> Node.Output:
            """__getitem__(self: depthai.Node.OutputMap, arg0: str) -> depthai.Node.Output"""
        def __iter__(self) -> Iterator[str]:
            """__iter__(self: depthai.Node.OutputMap) -> Iterator[str]"""
        def __len__(self) -> int:
            """__len__(self: depthai.Node.OutputMap) -> int"""
        def __setitem__(self, arg0: str, arg1: Node.Output) -> None:
            """__setitem__(self: depthai.Node.OutputMap, arg0: str, arg1: depthai.Node.Output) -> None"""
    properties: Properties
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""
    @overload
    def getAssetManager(self) -> AssetManager:
        """getAssetManager(*args, **kwargs)
        Overloaded function.

        1. getAssetManager(self: depthai.Node) -> depthai.AssetManager

        Get node AssetManager as a const reference

        2. getAssetManager(self: depthai.Node) -> depthai.AssetManager

        Get node AssetManager as a const reference
        """
    @overload
    def getAssetManager(self) -> AssetManager:
        """getAssetManager(*args, **kwargs)
        Overloaded function.

        1. getAssetManager(self: depthai.Node) -> depthai.AssetManager

        Get node AssetManager as a const reference

        2. getAssetManager(self: depthai.Node) -> depthai.AssetManager

        Get node AssetManager as a const reference
        """
    @overload
    def getInputRefs(self) -> list[Node.Input]:
        """getInputRefs(*args, **kwargs)
        Overloaded function.

        1. getInputRefs(self: depthai.Node) -> list[depthai.Node.Input]

        Retrieves reference to node inputs

        2. getInputRefs(self: depthai.Node) -> list[depthai.Node.Input]

        Retrieves reference to node inputs
        """
    @overload
    def getInputRefs(self) -> list[Node.Input]:
        """getInputRefs(*args, **kwargs)
        Overloaded function.

        1. getInputRefs(self: depthai.Node) -> list[depthai.Node.Input]

        Retrieves reference to node inputs

        2. getInputRefs(self: depthai.Node) -> list[depthai.Node.Input]

        Retrieves reference to node inputs
        """
    def getInputs(self) -> list[Node.Input]:
        """getInputs(self: depthai.Node) -> list[depthai.Node.Input]

        Retrieves all nodes inputs
        """
    def getName(self) -> str:
        """getName(self: depthai.Node) -> str

        Retrieves nodes name
        """
    @overload
    def getOutputRefs(self) -> list[Node.Output]:
        """getOutputRefs(*args, **kwargs)
        Overloaded function.

        1. getOutputRefs(self: depthai.Node) -> list[depthai.Node.Output]

        Retrieves reference to node outputs

        2. getOutputRefs(self: depthai.Node) -> list[depthai.Node.Output]

        Retrieves reference to node outputs
        """
    @overload
    def getOutputRefs(self) -> list[Node.Output]:
        """getOutputRefs(*args, **kwargs)
        Overloaded function.

        1. getOutputRefs(self: depthai.Node) -> list[depthai.Node.Output]

        Retrieves reference to node outputs

        2. getOutputRefs(self: depthai.Node) -> list[depthai.Node.Output]

        Retrieves reference to node outputs
        """
    def getOutputs(self) -> list[Node.Output]:
        """getOutputs(self: depthai.Node) -> list[depthai.Node.Output]

        Retrieves all nodes outputs
        """
    @overload
    def getParentPipeline(self) -> Pipeline:
        """getParentPipeline(*args, **kwargs)
        Overloaded function.

        1. getParentPipeline(self: depthai.Node) -> depthai.Pipeline

        2. getParentPipeline(self: depthai.Node) -> depthai.Pipeline
        """
    @overload
    def getParentPipeline(self) -> Pipeline:
        """getParentPipeline(*args, **kwargs)
        Overloaded function.

        1. getParentPipeline(self: depthai.Node) -> depthai.Pipeline

        2. getParentPipeline(self: depthai.Node) -> depthai.Pipeline
        """
    @property
    def id(self) -> int: ...

class ObjectTrackerProperties:
    detectionLabelsToTrack: list[int]
    maxObjectsToTrack: int
    trackerIdAssignmentPolicy: TrackerIdAssignmentPolicy
    trackerThreshold: float
    trackerType: TrackerType
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class OpenVINO:
    class Blob:
        data: list[int]
        networkInputs: dict[str, TensorInfo]
        networkOutputs: dict[str, TensorInfo]
        numShaves: int
        numSlices: int
        stageCount: int
        version: OpenVINO.Version
        @overload
        def __init__(self, arg0: list[int]) -> None:
            """__init__(*args, **kwargs)
            Overloaded function.

            1. __init__(self: depthai.OpenVINO.Blob, arg0: list[int]) -> None

            Construct a new Blob from data in memory

            Parameter ``data``:
                In memory blob

            2. __init__(self: depthai.OpenVINO.Blob, arg0: Path) -> None

            Construct a new Blob by loading from a filesystem path

            Parameter ``path``:
                Filesystem path to the blob
            """
        @overload
        def __init__(self, arg0: Path) -> None:
            """__init__(*args, **kwargs)
            Overloaded function.

            1. __init__(self: depthai.OpenVINO.Blob, arg0: list[int]) -> None

            Construct a new Blob from data in memory

            Parameter ``data``:
                In memory blob

            2. __init__(self: depthai.OpenVINO.Blob, arg0: Path) -> None

            Construct a new Blob by loading from a filesystem path

            Parameter ``path``:
                Filesystem path to the blob
            """

    class Version:
        __members__: ClassVar[dict] = ...  # read-only
        VERSION_2020_3: ClassVar[OpenVINO.Version] = ...
        VERSION_2020_4: ClassVar[OpenVINO.Version] = ...
        VERSION_2021_1: ClassVar[OpenVINO.Version] = ...
        VERSION_2021_2: ClassVar[OpenVINO.Version] = ...
        VERSION_2021_3: ClassVar[OpenVINO.Version] = ...
        VERSION_2021_4: ClassVar[OpenVINO.Version] = ...
        VERSION_2022_1: ClassVar[OpenVINO.Version] = ...
        VERSION_UNIVERSAL: ClassVar[OpenVINO.Version] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.OpenVINO.Version, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.OpenVINO.Version) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.OpenVINO.Version) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    DEFAULT_VERSION: ClassVar[OpenVINO.Version] = ...
    VERSION_2020_3: ClassVar[OpenVINO.Version] = ...
    VERSION_2020_4: ClassVar[OpenVINO.Version] = ...
    VERSION_2021_1: ClassVar[OpenVINO.Version] = ...
    VERSION_2021_2: ClassVar[OpenVINO.Version] = ...
    VERSION_2021_3: ClassVar[OpenVINO.Version] = ...
    VERSION_2021_4: ClassVar[OpenVINO.Version] = ...
    VERSION_2022_1: ClassVar[OpenVINO.Version] = ...
    VERSION_UNIVERSAL: ClassVar[OpenVINO.Version] = ...
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""
    @staticmethod
    def areVersionsBlobCompatible(v1: OpenVINO.Version, v2: OpenVINO.Version) -> bool:
        """areVersionsBlobCompatible(v1: depthai.OpenVINO.Version, v2: depthai.OpenVINO.Version) -> bool

        Checks whether two blob versions are compatible
        """
    @staticmethod
    def getBlobLatestSupportedVersion(*args, **kwargs):
        """getBlobLatestSupportedVersion(majorVersion: int, majorVersion: int) -> depthai.OpenVINO.Version

        Returns latest potentially supported version by a given blob version.

        Parameter ``majorVersion``:
            Major version from OpenVINO blob

        Parameter ``minorVersion``:
            Minor version from OpenVINO blob

        Returns:
            Latest potentially supported version
        """
    @staticmethod
    def getBlobSupportedVersions(*args, **kwargs):
        """getBlobSupportedVersions(majorVersion: int, majorVersion: int) -> list[depthai.OpenVINO.Version]

        Returns a list of potentially supported versions for a specified blob major and
        minor versions.

        Parameter ``majorVersion``:
            Major version from OpenVINO blob

        Parameter ``minorVersion``:
            Minor version from OpenVINO blob

        Returns:
            Vector of potentially supported versions
        """
    @staticmethod
    def getVersionName(version: OpenVINO.Version) -> str:
        """getVersionName(version: depthai.OpenVINO.Version) -> str

        Returns string representation of a given version

        Parameter ``version``:
            OpenVINO version

        Returns:
            Name of a given version
        """
    @staticmethod
    def getVersions() -> list[OpenVINO.Version]:
        """getVersions() -> list[depthai.OpenVINO.Version]

        Returns:
            Supported versions
        """
    @staticmethod
    def parseVersionName(versionString: str) -> OpenVINO.Version:
        """parseVersionName(versionString: str) -> depthai.OpenVINO.Version

        Creates Version from string representation. Throws if not possible.

        Parameter ``versionString``:
            Version as string

        Returns:
            Version object if successful
        """

class Pipeline:
    @overload
    def create(self, arg0: Type[T], *args, **kwargs) -> T: ...
    def __init__(self) -> None:
        """__init__(self: depthai.Pipeline) -> None

        Constructs a new pipeline
        """
    def create(self, arg0: object) -> Node:
        """create(self: depthai.Pipeline, arg0: object) -> depthai.Node"""
    def createAprilTag(self) -> node.AprilTag:
        """createAprilTag(self: depthai.Pipeline) -> depthai.node.AprilTag"""
    def createCamera(self) -> node.Camera:
        """createCamera(self: depthai.Pipeline) -> depthai.node.Camera"""
    def createColorCamera(self) -> node.ColorCamera:
        """createColorCamera(self: depthai.Pipeline) -> depthai.node.ColorCamera"""
    def createDetectionParser(self) -> node.DetectionParser:
        """createDetectionParser(self: depthai.Pipeline) -> depthai.node.DetectionParser"""
    def createEdgeDetector(self) -> node.EdgeDetector:
        """createEdgeDetector(self: depthai.Pipeline) -> depthai.node.EdgeDetector"""
    def createFeatureTracker(self) -> node.FeatureTracker:
        """createFeatureTracker(self: depthai.Pipeline) -> depthai.node.FeatureTracker"""
    def createIMU(self) -> node.IMU:
        """createIMU(self: depthai.Pipeline) -> depthai.node.IMU"""
    def createImageManip(self) -> node.ImageManip:
        """createImageManip(self: depthai.Pipeline) -> depthai.node.ImageManip"""
    def createMobileNetDetectionNetwork(self) -> node.MobileNetDetectionNetwork:
        """createMobileNetDetectionNetwork(self: depthai.Pipeline) -> depthai.node.MobileNetDetectionNetwork"""
    def createMobileNetSpatialDetectionNetwork(self) -> node.MobileNetSpatialDetectionNetwork:
        """createMobileNetSpatialDetectionNetwork(self: depthai.Pipeline) -> depthai.node.MobileNetSpatialDetectionNetwork"""
    def createMonoCamera(self) -> node.MonoCamera:
        """createMonoCamera(self: depthai.Pipeline) -> depthai.node.MonoCamera"""
    def createNeuralNetwork(self) -> node.NeuralNetwork:
        """createNeuralNetwork(self: depthai.Pipeline) -> depthai.node.NeuralNetwork"""
    def createObjectTracker(self) -> node.ObjectTracker:
        """createObjectTracker(self: depthai.Pipeline) -> depthai.node.ObjectTracker"""
    def createSPIIn(self) -> node.SPIIn:
        """createSPIIn(self: depthai.Pipeline) -> depthai.node.SPIIn"""
    def createSPIOut(self) -> node.SPIOut:
        """createSPIOut(self: depthai.Pipeline) -> depthai.node.SPIOut"""
    def createScript(self) -> node.Script:
        """createScript(self: depthai.Pipeline) -> depthai.node.Script"""
    def createSpatialLocationCalculator(self) -> node.SpatialLocationCalculator:
        """createSpatialLocationCalculator(self: depthai.Pipeline) -> depthai.node.SpatialLocationCalculator"""
    def createStereoDepth(self) -> node.StereoDepth:
        """createStereoDepth(self: depthai.Pipeline) -> depthai.node.StereoDepth"""
    def createSystemLogger(self) -> node.SystemLogger:
        """createSystemLogger(self: depthai.Pipeline) -> depthai.node.SystemLogger"""
    def createUVC(self) -> node.UVC:
        """createUVC(self: depthai.Pipeline) -> depthai.node.UVC"""
    def createVideoEncoder(self) -> node.VideoEncoder:
        """createVideoEncoder(self: depthai.Pipeline) -> depthai.node.VideoEncoder"""
    def createWarp(self) -> node.Warp:
        """createWarp(self: depthai.Pipeline) -> depthai.node.Warp"""
    def createXLinkIn(self) -> node.XLinkIn:
        """createXLinkIn(self: depthai.Pipeline) -> depthai.node.XLinkIn"""
    def createXLinkOut(self) -> node.XLinkOut:
        """createXLinkOut(self: depthai.Pipeline) -> depthai.node.XLinkOut"""
    def createYoloDetectionNetwork(self) -> node.YoloDetectionNetwork:
        """createYoloDetectionNetwork(self: depthai.Pipeline) -> depthai.node.YoloDetectionNetwork"""
    def createYoloSpatialDetectionNetwork(self) -> node.YoloSpatialDetectionNetwork:
        """createYoloSpatialDetectionNetwork(self: depthai.Pipeline) -> depthai.node.YoloSpatialDetectionNetwork"""
    @overload
    def getAllNodes(self) -> list[Node]:
        """getAllNodes(*args, **kwargs)
        Overloaded function.

        1. getAllNodes(self: depthai.Pipeline) -> list[depthai.Node]

        Get a vector of all nodes

        2. getAllNodes(self: depthai.Pipeline) -> list[depthai.Node]

        Get a vector of all nodes
        """
    @overload
    def getAllNodes(self) -> list[Node]:
        """getAllNodes(*args, **kwargs)
        Overloaded function.

        1. getAllNodes(self: depthai.Pipeline) -> list[depthai.Node]

        Get a vector of all nodes

        2. getAllNodes(self: depthai.Pipeline) -> list[depthai.Node]

        Get a vector of all nodes
        """
    @overload
    def getAssetManager(self) -> AssetManager:
        """getAssetManager(*args, **kwargs)
        Overloaded function.

        1. getAssetManager(self: depthai.Pipeline) -> depthai.AssetManager

        Get pipelines AssetManager as reference

        2. getAssetManager(self: depthai.Pipeline) -> depthai.AssetManager

        Get pipelines AssetManager as reference
        """
    @overload
    def getAssetManager(self) -> AssetManager:
        """getAssetManager(*args, **kwargs)
        Overloaded function.

        1. getAssetManager(self: depthai.Pipeline) -> depthai.AssetManager

        Get pipelines AssetManager as reference

        2. getAssetManager(self: depthai.Pipeline) -> depthai.AssetManager

        Get pipelines AssetManager as reference
        """
    def getBoardConfig(self) -> BoardConfig:
        """getBoardConfig(self: depthai.Pipeline) -> depthai.BoardConfig

        Gets board configuration
        """
    def getCalibrationData(self) -> CalibrationHandler:
        """getCalibrationData(self: depthai.Pipeline) -> depthai.CalibrationHandler

        gets the calibration data which is set through pipeline

        Returns:
            the calibrationHandler with calib data in the pipeline
        """
    def getConnectionMap(self) -> dict[int, set[Node.Connection]]:
        """getConnectionMap(self: depthai.Pipeline) -> dict[int, set[depthai.Node.Connection]]

        Get a reference to internal connection representation
        """
    def getConnections(self) -> list[Node.Connection]:
        """getConnections(self: depthai.Pipeline) -> list[depthai.Node.Connection]

        Get all connections
        """
    def getDeviceConfig(self) -> Device.Config:
        """getDeviceConfig(self: depthai.Pipeline) -> depthai.Device.Config

        Get device configuration needed for this pipeline
        """
    def getGlobalProperties(self) -> GlobalProperties:
        """getGlobalProperties(self: depthai.Pipeline) -> depthai.GlobalProperties

        Returns:
            Global properties of current pipeline
        """
    @overload
    def getNode(self, arg0: int) -> Node:
        """getNode(*args, **kwargs)
        Overloaded function.

        1. getNode(self: depthai.Pipeline, arg0: int) -> depthai.Node

        Get node with id if it exists, nullptr otherwise

        2. getNode(self: depthai.Pipeline, arg0: int) -> depthai.Node

        Get node with id if it exists, nullptr otherwise
        """
    @overload
    def getNode(self, arg0: int) -> Node:
        """getNode(*args, **kwargs)
        Overloaded function.

        1. getNode(self: depthai.Pipeline, arg0: int) -> depthai.Node

        Get node with id if it exists, nullptr otherwise

        2. getNode(self: depthai.Pipeline, arg0: int) -> depthai.Node

        Get node with id if it exists, nullptr otherwise
        """
    def getNodeMap(self) -> dict[int, Node]:
        """getNodeMap(self: depthai.Pipeline) -> dict[int, depthai.Node]

        Get a reference to internal node map
        """
    def getOpenVINOVersion(self) -> OpenVINO.Version:
        """getOpenVINOVersion(self: depthai.Pipeline) -> depthai.OpenVINO.Version

        Get possible OpenVINO version to run this pipeline
        """
    def getRequiredOpenVINOVersion(self) -> OpenVINO.Version | None:
        """getRequiredOpenVINOVersion(self: depthai.Pipeline) -> Optional[depthai.OpenVINO.Version]

        Get required OpenVINO version to run this pipeline. Can be none
        """
    def link(self, arg0: Node.Output, arg1: Node.Input) -> None:
        """link(self: depthai.Pipeline, arg0: depthai.Node.Output, arg1: depthai.Node.Input) -> None

        Link output to an input. Both nodes must be on the same pipeline

        Throws an error if they aren't or cannot be connected

        Parameter ``out``:
            Nodes output to connect from

        Parameter ``in``:
            Nodes input to connect to
        """
    def remove(self, node: Node) -> None:
        """remove(self: depthai.Pipeline, node: depthai.Node) -> None

        Removes a node from pipeline
        """
    def serializeToJson(self) -> json:
        """serializeToJson(self: depthai.Pipeline) -> json

        Returns whole pipeline represented as JSON
        """
    def setBoardConfig(self, arg0: BoardConfig) -> None:
        """setBoardConfig(self: depthai.Pipeline, arg0: depthai.BoardConfig) -> None

        Sets board configuration
        """
    def setCalibrationData(self, calibrationDataHandler: CalibrationHandler) -> None:
        """setCalibrationData(self: depthai.Pipeline, calibrationDataHandler: depthai.CalibrationHandler) -> None

        Sets the calibration in pipeline which overrides the calibration data in eeprom

        Parameter ``calibrationDataHandler``:
            CalibrationHandler object which is loaded with calibration information.
        """
    def setCameraTuningBlobPath(self, path: Path) -> None:
        """setCameraTuningBlobPath(self: depthai.Pipeline, path: Path) -> None

        Set a camera IQ (Image Quality) tuning blob, used for all cameras
        """
    def setOpenVINOVersion(self, version: OpenVINO.Version) -> None:
        """setOpenVINOVersion(self: depthai.Pipeline, version: depthai.OpenVINO.Version) -> None

        Set a specific OpenVINO version to use with this pipeline
        """
    def setSippBufferSize(self, sizeBytes: int) -> None:
        """setSippBufferSize(self: depthai.Pipeline, sizeBytes: int) -> None

        SIPP (Signal Image Processing Pipeline) internal memory pool. SIPP is a
        framework used to schedule HW filters, e.g. ISP, Warp, Median filter etc.
        Changing the size of this pool is meant for advanced use cases, pushing the
        limits of the HW. By default memory is allocated in high speed CMX memory.
        Setting to 0 will allocate in DDR 256 kilobytes. Units are bytes.
        """
    def setSippDmaBufferSize(self, sizeBytes: int) -> None:
        """setSippDmaBufferSize(self: depthai.Pipeline, sizeBytes: int) -> None

        SIPP (Signal Image Processing Pipeline) internal DMA memory pool. SIPP is a
        framework used to schedule HW filters, e.g. ISP, Warp, Median filter etc.
        Changing the size of this pool is meant for advanced use cases, pushing the
        limits of the HW. Memory is allocated in high speed CMX memory Units are bytes.
        """
    def setXLinkChunkSize(self, sizeBytes: int) -> None:
        """setXLinkChunkSize(self: depthai.Pipeline, sizeBytes: int) -> None

        Set chunk size for splitting device-sent XLink packets, in bytes. A larger value
        could increase performance, with 0 disabling chunking. A negative value won't
        modify the device defaults - configured per protocol, currently 64*1024 for both
        USB and Ethernet.
        """
    def unlink(self, arg0: Node.Output, arg1: Node.Input) -> None:
        """unlink(self: depthai.Pipeline, arg0: depthai.Node.Output, arg1: depthai.Node.Input) -> None

        Unlink output from an input.

        Throws an error if link doesn't exists

        Parameter ``out``:
            Nodes output to unlink from

        Parameter ``in``:
            Nodes input to unlink to
        """

class Point2f:
    x: float
    y: float
    @overload
    def __init__(self) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Point2f) -> None

        2. __init__(self: depthai.Point2f, arg0: float, arg1: float) -> None
        """
    @overload
    def __init__(self, arg0: float, arg1: float) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Point2f) -> None

        2. __init__(self: depthai.Point2f, arg0: float, arg1: float) -> None
        """

class Point3f:
    x: float
    y: float
    z: float
    @overload
    def __init__(self) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Point3f) -> None

        2. __init__(self: depthai.Point3f, arg0: float, arg1: float, arg2: float) -> None
        """
    @overload
    def __init__(self, arg0: float, arg1: float, arg2: float) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Point3f) -> None

        2. __init__(self: depthai.Point3f, arg0: float, arg1: float, arg2: float) -> None
        """

class PointCloudConfig(Buffer):
    @overload
    def __init__(self) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.PointCloudConfig) -> None

        2. __init__(self: depthai.PointCloudConfig, arg0: depthai.RawPointCloudConfig) -> None
        """
    @overload
    def __init__(self, arg0: RawPointCloudConfig) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.PointCloudConfig) -> None

        2. __init__(self: depthai.PointCloudConfig, arg0: depthai.RawPointCloudConfig) -> None
        """
    def get(self) -> RawPointCloudConfig:
        """get(self: depthai.PointCloudConfig) -> depthai.RawPointCloudConfig

        Retrieve configuration data for SpatialLocationCalculator.

        Returns:
            config for SpatialLocationCalculator
        """
    def getSparse(self) -> bool:
        """getSparse(self: depthai.PointCloudConfig) -> bool

        Retrieve sparse point cloud calculation status.

        Returns:
            true if sparse point cloud calculation is enabled, false otherwise
        """
    def getTransformationMatrix(self, *args, **kwargs):
        """getTransformationMatrix(self: depthai.PointCloudConfig) -> Annotated[list[Annotated[list[float], FixedSize(4)]], FixedSize(4)]

        Retrieve transformation matrix for point cloud calculation.

        Returns:
            4x4 transformation matrix
        """
    def set(self, config: RawPointCloudConfig) -> PointCloudConfig:
        """set(self: depthai.PointCloudConfig, config: depthai.RawPointCloudConfig) -> depthai.PointCloudConfig

        Set explicit configuration.

        Parameter ``config``:
            Explicit configuration
        """
    def setSparse(self, arg0: bool) -> PointCloudConfig:
        """setSparse(self: depthai.PointCloudConfig, arg0: bool) -> depthai.PointCloudConfig

        Enable or disable sparse point cloud calculation.

        Parameter ``enable``:
        """
    @overload
    def setTransformationMatrix(self, arg0) -> PointCloudConfig:
        """setTransformationMatrix(*args, **kwargs)
        Overloaded function.

        1. setTransformationMatrix(self: depthai.PointCloudConfig, arg0: Annotated[list[Annotated[list[float], FixedSize(3)]], FixedSize(3)]) -> depthai.PointCloudConfig

        Set 4x4 transformation matrix for point cloud calculation. Default is an
        identity matrix.

        Parameter ``transformationMatrix``:

        2. setTransformationMatrix(self: depthai.PointCloudConfig, arg0: Annotated[list[Annotated[list[float], FixedSize(4)]], FixedSize(4)]) -> depthai.PointCloudConfig

        Set 4x4 transformation matrix for point cloud calculation. Default is an
        identity matrix.

        Parameter ``transformationMatrix``:
        """
    @overload
    def setTransformationMatrix(self, arg0) -> PointCloudConfig:
        """setTransformationMatrix(*args, **kwargs)
        Overloaded function.

        1. setTransformationMatrix(self: depthai.PointCloudConfig, arg0: Annotated[list[Annotated[list[float], FixedSize(3)]], FixedSize(3)]) -> depthai.PointCloudConfig

        Set 4x4 transformation matrix for point cloud calculation. Default is an
        identity matrix.

        Parameter ``transformationMatrix``:

        2. setTransformationMatrix(self: depthai.PointCloudConfig, arg0: Annotated[list[Annotated[list[float], FixedSize(4)]], FixedSize(4)]) -> depthai.PointCloudConfig

        Set 4x4 transformation matrix for point cloud calculation. Default is an
        identity matrix.

        Parameter ``transformationMatrix``:
        """

class PointCloudData(Buffer):
    points: list[Point3f]
    def __init__(self) -> None:
        """__init__(self: depthai.PointCloudData) -> None"""
    def getHeight(self) -> int:
        """getHeight(self: depthai.PointCloudData) -> int

        Retrieves the height in pixels - in case of a sparse point cloud, this
        represents the hight of the frame which was used to generate the point cloud
        """
    def getInstanceNum(self) -> int:
        """getInstanceNum(self: depthai.PointCloudData) -> int

        Retrieves instance number
        """
    def getMaxX(self) -> float:
        """getMaxX(self: depthai.PointCloudData) -> float

        Retrieves maximal x coordinate in depth units (millimeter by default)
        """
    def getMaxY(self) -> float:
        """getMaxY(self: depthai.PointCloudData) -> float

        Retrieves maximal y coordinate in depth units (millimeter by default)
        """
    def getMaxZ(self) -> float:
        """getMaxZ(self: depthai.PointCloudData) -> float

        Retrieves maximal z coordinate in depth units (millimeter by default)
        """
    def getMinX(self) -> float:
        """getMinX(self: depthai.PointCloudData) -> float

        Retrieves minimal x coordinate in depth units (millimeter by default)
        """
    def getMinY(self) -> float:
        """getMinY(self: depthai.PointCloudData) -> float

        Retrieves minimal y coordinate in depth units (millimeter by default)
        """
    def getMinZ(self) -> float:
        """getMinZ(self: depthai.PointCloudData) -> float

        Retrieves minimal z coordinate in depth units (millimeter by default)
        """
    def getPoints(self) -> numpy.ndarray[numpy.float32]:
        """getPoints(self: object) -> numpy.ndarray[numpy.float32]"""
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.PointCloudData) -> int

        Retrieves sequence number
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.PointCloudData) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.PointCloudData) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """
    def getWidth(self) -> int:
        """getWidth(self: depthai.PointCloudData) -> int

        Retrieves the height in pixels - in case of a sparse point cloud, this
        represents the hight of the frame which was used to generate the point cloud
        """
    def isSparse(self) -> bool:
        """isSparse(self: depthai.PointCloudData) -> bool

        Retrieves whether point cloud is sparse
        """
    def setHeight(self, arg0: int) -> PointCloudData:
        """setHeight(self: depthai.PointCloudData, arg0: int) -> depthai.PointCloudData

        Specifies frame height

        Parameter ``height``:
            frame height
        """
    def setInstanceNum(self, arg0: int) -> PointCloudData:
        """setInstanceNum(self: depthai.PointCloudData, arg0: int) -> depthai.PointCloudData

        Instance number relates to the origin of the frame (which camera)

        Parameter ``instance``:
            Instance number
        """
    def setMaxX(self, arg0: float) -> PointCloudData:
        """setMaxX(self: depthai.PointCloudData, arg0: float) -> depthai.PointCloudData

        Specifies maximal x coordinate in depth units (millimeter by default)

        Parameter ``val``:
            maximal x coordinate in depth units (millimeter by default)
        """
    def setMaxY(self, arg0: float) -> PointCloudData:
        """setMaxY(self: depthai.PointCloudData, arg0: float) -> depthai.PointCloudData

        Specifies maximal y coordinate in depth units (millimeter by default)

        Parameter ``val``:
            maximal y coordinate in depth units (millimeter by default)
        """
    def setMaxZ(self, arg0: float) -> PointCloudData:
        """setMaxZ(self: depthai.PointCloudData, arg0: float) -> depthai.PointCloudData

        Specifies maximal z coordinate in depth units (millimeter by default)

        Parameter ``val``:
            maximal z coordinate in depth units (millimeter by default)
        """
    def setMinX(self, arg0: float) -> PointCloudData:
        """setMinX(self: depthai.PointCloudData, arg0: float) -> depthai.PointCloudData

        Specifies minimal x coordinate in depth units (millimeter by default)

        Parameter ``val``:
            minimal x coordinate in depth units (millimeter by default)
        """
    def setMinY(self, arg0: float) -> PointCloudData:
        """setMinY(self: depthai.PointCloudData, arg0: float) -> depthai.PointCloudData

        Specifies minimal y coordinate in depth units (millimeter by default)

        Parameter ``val``:
            minimal y coordinate in depth units (millimeter by default)
        """
    def setMinZ(self, arg0: float) -> PointCloudData:
        """setMinZ(self: depthai.PointCloudData, arg0: float) -> depthai.PointCloudData

        Specifies minimal z coordinate in depth units (millimeter by default)

        Parameter ``val``:
            minimal z coordinate in depth units (millimeter by default)
        """
    def setSequenceNum(self, arg0: int) -> PointCloudData:
        """setSequenceNum(self: depthai.PointCloudData, arg0: int) -> depthai.PointCloudData

        Specifies sequence number

        Parameter ``seq``:
            Sequence number
        """
    @overload
    def setSize(self, width: int, height: int) -> PointCloudData:
        """setSize(*args, **kwargs)
        Overloaded function.

        1. setSize(self: depthai.PointCloudData, width: int, height: int) -> depthai.PointCloudData

        Specifies frame size

        Parameter ``height``:
            frame height

        Parameter ``width``:
            frame width

        2. setSize(self: depthai.PointCloudData, size: tuple[int, int]) -> depthai.PointCloudData

        Specifies frame size

        Parameter ``size``:
            frame size
        """
    @overload
    def setSize(self, size: tuple[int, int]) -> PointCloudData:
        """setSize(*args, **kwargs)
        Overloaded function.

        1. setSize(self: depthai.PointCloudData, width: int, height: int) -> depthai.PointCloudData

        Specifies frame size

        Parameter ``height``:
            frame height

        Parameter ``width``:
            frame width

        2. setSize(self: depthai.PointCloudData, size: tuple[int, int]) -> depthai.PointCloudData

        Specifies frame size

        Parameter ``size``:
            frame size
        """
    def setTimestamp(self, arg0: datetime.timedelta) -> PointCloudData:
        """setTimestamp(self: depthai.PointCloudData, arg0: datetime.timedelta) -> depthai.PointCloudData

        Retrieves image timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> PointCloudData:
        """setTimestampDevice(self: depthai.PointCloudData, arg0: datetime.timedelta) -> depthai.PointCloudData

        Sets image timestamp related to dai::Clock::now()
        """
    def setWidth(self, arg0: int) -> PointCloudData:
        """setWidth(self: depthai.PointCloudData, arg0: int) -> depthai.PointCloudData

        Specifies frame width

        Parameter ``width``:
            frame width
        """

class PointCloudProperties:
    initialConfig: RawPointCloudConfig
    numFramesPool: int
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class ProcessorType:
    __members__: ClassVar[dict] = ...  # read-only
    LEON_CSS: ClassVar[ProcessorType] = ...
    LEON_MSS: ClassVar[ProcessorType] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.ProcessorType, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.ProcessorType) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.ProcessorType) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class ProfilingData:
    numBytesRead: int
    numBytesWritten: int
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class Properties:
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class RawAprilTagConfig(RawBuffer):
    class Family:
        __members__: ClassVar[dict] = ...  # read-only
        TAG_16H5: ClassVar[RawAprilTagConfig.Family] = ...
        TAG_25H9: ClassVar[RawAprilTagConfig.Family] = ...
        TAG_36H10: ClassVar[RawAprilTagConfig.Family] = ...
        TAG_36H11: ClassVar[RawAprilTagConfig.Family] = ...
        TAG_CIR21H7: ClassVar[RawAprilTagConfig.Family] = ...
        TAG_STAND41H12: ClassVar[RawAprilTagConfig.Family] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawAprilTagConfig.Family, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawAprilTagConfig.Family) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawAprilTagConfig.Family) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class QuadThresholds:
        criticalDegree: float
        deglitch: bool
        maxLineFitMse: float
        maxNmaxima: int
        minClusterPixels: int
        minWhiteBlackDiff: int
        def __init__(self) -> None:
            """__init__(self: depthai.RawAprilTagConfig.QuadThresholds) -> None"""
    decodeSharpening: float
    family: RawAprilTagConfig.Family
    maxHammingDistance: int
    quadDecimate: int
    quadSigma: float
    quadThresholds: RawAprilTagConfig.QuadThresholds
    refineEdges: bool
    def __init__(self) -> None:
        """__init__(self: depthai.RawAprilTagConfig) -> None"""

class RawBuffer:
    data: numpy.ndarray[numpy.uint8]
    sequenceNum: int
    ts: float
    tsDevice: float
    def __init__(self) -> None:
        """__init__(self: depthai.RawBuffer) -> None"""

class RawCameraControl(RawBuffer):
    class AntiBandingMode:
        __members__: ClassVar[dict] = ...  # read-only
        AUTO: ClassVar[RawCameraControl.AntiBandingMode] = ...
        MAINS_50_HZ: ClassVar[RawCameraControl.AntiBandingMode] = ...
        MAINS_60_HZ: ClassVar[RawCameraControl.AntiBandingMode] = ...
        OFF: ClassVar[RawCameraControl.AntiBandingMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.AntiBandingMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.AntiBandingMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.AntiBandingMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class AutoFocusMode:
        __members__: ClassVar[dict] = ...  # read-only
        AUTO: ClassVar[RawCameraControl.AutoFocusMode] = ...
        CONTINUOUS_PICTURE: ClassVar[RawCameraControl.AutoFocusMode] = ...
        CONTINUOUS_VIDEO: ClassVar[RawCameraControl.AutoFocusMode] = ...
        EDOF: ClassVar[RawCameraControl.AutoFocusMode] = ...
        MACRO: ClassVar[RawCameraControl.AutoFocusMode] = ...
        OFF: ClassVar[RawCameraControl.AutoFocusMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.AutoFocusMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.AutoFocusMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.AutoFocusMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class AutoWhiteBalanceMode:
        __members__: ClassVar[dict] = ...  # read-only
        AUTO: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        CLOUDY_DAYLIGHT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        DAYLIGHT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        FLUORESCENT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        INCANDESCENT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        OFF: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        SHADE: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        TWILIGHT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        WARM_FLUORESCENT: ClassVar[RawCameraControl.AutoWhiteBalanceMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.AutoWhiteBalanceMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.AutoWhiteBalanceMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.AutoWhiteBalanceMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class CaptureIntent:
        __members__: ClassVar[dict] = ...  # read-only
        CUSTOM: ClassVar[RawCameraControl.CaptureIntent] = ...
        PREVIEW: ClassVar[RawCameraControl.CaptureIntent] = ...
        STILL_CAPTURE: ClassVar[RawCameraControl.CaptureIntent] = ...
        VIDEO_RECORD: ClassVar[RawCameraControl.CaptureIntent] = ...
        VIDEO_SNAPSHOT: ClassVar[RawCameraControl.CaptureIntent] = ...
        ZERO_SHUTTER_LAG: ClassVar[RawCameraControl.CaptureIntent] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.CaptureIntent, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.CaptureIntent) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.CaptureIntent) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class Command:
        __members__: ClassVar[dict] = ...  # read-only
        AE_AUTO: ClassVar[RawCameraControl.Command] = ...
        AE_LOCK: ClassVar[RawCameraControl.Command] = ...
        AE_MANUAL: ClassVar[RawCameraControl.Command] = ...
        AE_REGION: ClassVar[RawCameraControl.Command] = ...
        AE_TARGET_FPS_RANGE: ClassVar[RawCameraControl.Command] = ...
        AF_MODE: ClassVar[RawCameraControl.Command] = ...
        AF_REGION: ClassVar[RawCameraControl.Command] = ...
        AF_TRIGGER: ClassVar[RawCameraControl.Command] = ...
        ANTIBANDING_MODE: ClassVar[RawCameraControl.Command] = ...
        AWB_LOCK: ClassVar[RawCameraControl.Command] = ...
        AWB_MODE: ClassVar[RawCameraControl.Command] = ...
        BRIGHTNESS: ClassVar[RawCameraControl.Command] = ...
        CAPTURE_INTENT: ClassVar[RawCameraControl.Command] = ...
        CHROMA_DENOISE: ClassVar[RawCameraControl.Command] = ...
        CONTRAST: ClassVar[RawCameraControl.Command] = ...
        CONTROL_MODE: ClassVar[RawCameraControl.Command] = ...
        CUSTOM_CAPTURE: ClassVar[RawCameraControl.Command] = ...
        CUSTOM_CAPT_MODE: ClassVar[RawCameraControl.Command] = ...
        CUSTOM_EXP_BRACKETS: ClassVar[RawCameraControl.Command] = ...
        CUSTOM_USECASE: ClassVar[RawCameraControl.Command] = ...
        EFFECT_MODE: ClassVar[RawCameraControl.Command] = ...
        EXPOSURE_COMPENSATION: ClassVar[RawCameraControl.Command] = ...
        FRAME_DURATION: ClassVar[RawCameraControl.Command] = ...
        LUMA_DENOISE: ClassVar[RawCameraControl.Command] = ...
        MOVE_LENS: ClassVar[RawCameraControl.Command] = ...
        NOISE_REDUCTION_STRENGTH: ClassVar[RawCameraControl.Command] = ...
        RESOLUTION: ClassVar[RawCameraControl.Command] = ...
        SATURATION: ClassVar[RawCameraControl.Command] = ...
        SCENE_MODE: ClassVar[RawCameraControl.Command] = ...
        SENSITIVITY: ClassVar[RawCameraControl.Command] = ...
        SHARPNESS: ClassVar[RawCameraControl.Command] = ...
        START_STREAM: ClassVar[RawCameraControl.Command] = ...
        STILL_CAPTURE: ClassVar[RawCameraControl.Command] = ...
        STOP_STREAM: ClassVar[RawCameraControl.Command] = ...
        STREAM_FORMAT: ClassVar[RawCameraControl.Command] = ...
        WB_COLOR_TEMP: ClassVar[RawCameraControl.Command] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.Command, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.Command) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.Command) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class ControlMode:
        __members__: ClassVar[dict] = ...  # read-only
        AUTO: ClassVar[RawCameraControl.ControlMode] = ...
        OFF: ClassVar[RawCameraControl.ControlMode] = ...
        USE_SCENE_MODE: ClassVar[RawCameraControl.ControlMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.ControlMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.ControlMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.ControlMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class EffectMode:
        __members__: ClassVar[dict] = ...  # read-only
        AQUA: ClassVar[RawCameraControl.EffectMode] = ...
        BLACKBOARD: ClassVar[RawCameraControl.EffectMode] = ...
        MONO: ClassVar[RawCameraControl.EffectMode] = ...
        NEGATIVE: ClassVar[RawCameraControl.EffectMode] = ...
        OFF: ClassVar[RawCameraControl.EffectMode] = ...
        POSTERIZE: ClassVar[RawCameraControl.EffectMode] = ...
        SEPIA: ClassVar[RawCameraControl.EffectMode] = ...
        SOLARIZE: ClassVar[RawCameraControl.EffectMode] = ...
        WHITEBOARD: ClassVar[RawCameraControl.EffectMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.EffectMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.EffectMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.EffectMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class FrameSyncMode:
        __members__: ClassVar[dict] = ...  # read-only
        INPUT: ClassVar[RawCameraControl.FrameSyncMode] = ...
        OFF: ClassVar[RawCameraControl.FrameSyncMode] = ...
        OUTPUT: ClassVar[RawCameraControl.FrameSyncMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.FrameSyncMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.FrameSyncMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.FrameSyncMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class SceneMode:
        __members__: ClassVar[dict] = ...  # read-only
        ACTION: ClassVar[RawCameraControl.SceneMode] = ...
        BARCODE: ClassVar[RawCameraControl.SceneMode] = ...
        BEACH: ClassVar[RawCameraControl.SceneMode] = ...
        CANDLELIGHT: ClassVar[RawCameraControl.SceneMode] = ...
        FACE_PRIORITY: ClassVar[RawCameraControl.SceneMode] = ...
        FIREWORKS: ClassVar[RawCameraControl.SceneMode] = ...
        LANDSCAPE: ClassVar[RawCameraControl.SceneMode] = ...
        NIGHT: ClassVar[RawCameraControl.SceneMode] = ...
        NIGHT_PORTRAIT: ClassVar[RawCameraControl.SceneMode] = ...
        PARTY: ClassVar[RawCameraControl.SceneMode] = ...
        PORTRAIT: ClassVar[RawCameraControl.SceneMode] = ...
        SNOW: ClassVar[RawCameraControl.SceneMode] = ...
        SPORTS: ClassVar[RawCameraControl.SceneMode] = ...
        STEADYPHOTO: ClassVar[RawCameraControl.SceneMode] = ...
        SUNSET: ClassVar[RawCameraControl.SceneMode] = ...
        THEATRE: ClassVar[RawCameraControl.SceneMode] = ...
        UNSUPPORTED: ClassVar[RawCameraControl.SceneMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawCameraControl.SceneMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawCameraControl.SceneMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawCameraControl.SceneMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    aeLockMode: bool
    aeMaxExposureTimeUs: int
    afRegion: Incomplete
    antiBandingMode: RawCameraControl.AntiBandingMode
    autoFocusMode: RawCameraControl.AutoFocusMode
    awbLockMode: bool
    awbMode: RawCameraControl.AutoWhiteBalanceMode
    brightness: int
    captureIntent: RawCameraControl.CaptureIntent
    chromaDenoise: int
    cmdMask: int
    contrast: int
    controlMode: RawCameraControl.ControlMode
    effectMode: RawCameraControl.EffectMode
    expCompensation: int
    expManual: Incomplete
    lensPosition: int
    lensPositionRaw: float
    lumaDenoise: int
    saturation: int
    sceneMode: RawCameraControl.SceneMode
    sharpness: int
    wbColorTemp: int
    def __init__(self) -> None:
        """__init__(self: depthai.RawCameraControl) -> None"""
    def clearCommand(self, arg0: RawCameraControl.Command) -> None:
        """clearCommand(self: depthai.RawCameraControl, arg0: depthai.RawCameraControl.Command) -> None"""
    def getCommand(self, arg0: RawCameraControl.Command) -> bool:
        """getCommand(self: depthai.RawCameraControl, arg0: depthai.RawCameraControl.Command) -> bool"""
    def setCommand(self, arg0: RawCameraControl.Command, arg1: bool) -> None:
        """setCommand(self: depthai.RawCameraControl, arg0: depthai.RawCameraControl.Command, arg1: bool) -> None"""

class RawEdgeDetectorConfig(RawBuffer):
    config: EdgeDetectorConfigData
    def __init__(self) -> None:
        """__init__(self: depthai.RawEdgeDetectorConfig) -> None"""

class RawEncodedFrame(RawBuffer):
    class FrameType:
        __members__: ClassVar[dict] = ...  # read-only
        B: ClassVar[RawEncodedFrame.FrameType] = ...
        I: ClassVar[RawEncodedFrame.FrameType] = ...
        P: ClassVar[RawEncodedFrame.FrameType] = ...
        Unknown: ClassVar[RawEncodedFrame.FrameType] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawEncodedFrame.FrameType, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawEncodedFrame.FrameType) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawEncodedFrame.FrameType) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class Profile:
        __members__: ClassVar[dict] = ...  # read-only
        AVC: ClassVar[RawEncodedFrame.Profile] = ...
        HEVC: ClassVar[RawEncodedFrame.Profile] = ...
        JPEG: ClassVar[RawEncodedFrame.Profile] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawEncodedFrame.Profile, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawEncodedFrame.Profile) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawEncodedFrame.Profile) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    bitrate: int
    height: int
    instanceNum: int
    lossless: bool
    profile: RawEncodedFrame.Profile
    quality: int
    sequenceNum: int
    ts: float
    tsDevice: float
    type: RawEncodedFrame.FrameType
    width: int
    def __init__(self) -> None:
        """__init__(self: depthai.RawEncodedFrame) -> None"""

class RawFeatureTrackerConfig(RawBuffer):
    class CornerDetector:
        class Thresholds:
            decreaseFactor: float
            increaseFactor: float
            initialValue: float
            max: float
            min: float
            def __init__(self) -> None:
                """__init__(self: depthai.RawFeatureTrackerConfig.CornerDetector.Thresholds) -> None"""

        class Type:
            __members__: ClassVar[dict] = ...  # read-only
            HARRIS: ClassVar[RawFeatureTrackerConfig.CornerDetector.Type] = ...
            SHI_THOMASI: ClassVar[RawFeatureTrackerConfig.CornerDetector.Type] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawFeatureTrackerConfig.CornerDetector.Type, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawFeatureTrackerConfig.CornerDetector.Type) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawFeatureTrackerConfig.CornerDetector.Type) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...
        cellGridDimension: int
        enableSobel: bool
        enableSorting: bool
        numMaxFeatures: int
        numTargetFeatures: int
        thresholds: RawFeatureTrackerConfig.CornerDetector.Thresholds
        type: RawFeatureTrackerConfig.CornerDetector.Type
        def __init__(self) -> None:
            """__init__(self: depthai.RawFeatureTrackerConfig.CornerDetector) -> None"""

    class FeatureMaintainer:
        enable: bool
        lostFeatureErrorThreshold: float
        minimumDistanceBetweenFeatures: float
        trackedFeatureThreshold: float
        def __init__(self) -> None:
            """__init__(self: depthai.RawFeatureTrackerConfig.FeatureMaintainer) -> None"""

    class MotionEstimator:
        class OpticalFlow:
            epsilon: float
            maxIterations: int
            pyramidLevels: int
            searchWindowHeight: int
            searchWindowWidth: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawFeatureTrackerConfig.MotionEstimator.OpticalFlow) -> None"""

        class Type:
            __members__: ClassVar[dict] = ...  # read-only
            HW_MOTION_ESTIMATION: ClassVar[RawFeatureTrackerConfig.MotionEstimator.Type] = ...
            LUCAS_KANADE_OPTICAL_FLOW: ClassVar[RawFeatureTrackerConfig.MotionEstimator.Type] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawFeatureTrackerConfig.MotionEstimator.Type, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawFeatureTrackerConfig.MotionEstimator.Type) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawFeatureTrackerConfig.MotionEstimator.Type) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...
        enable: bool
        opticalFlow: RawFeatureTrackerConfig.MotionEstimator.OpticalFlow
        type: RawFeatureTrackerConfig.MotionEstimator.Type
        def __init__(self) -> None:
            """__init__(self: depthai.RawFeatureTrackerConfig.MotionEstimator) -> None"""
    cornerDetector: RawFeatureTrackerConfig.CornerDetector
    featureMaintainer: RawFeatureTrackerConfig.FeatureMaintainer
    motionEstimator: RawFeatureTrackerConfig.MotionEstimator
    def __init__(self) -> None:
        """__init__(self: depthai.RawFeatureTrackerConfig) -> None"""

class RawIMUData(RawBuffer):
    packets: list[IMUPacket]
    def __init__(self) -> None:
        """__init__(self: depthai.RawIMUData) -> None"""

class RawImageAlignConfig(RawBuffer):
    staticDepthPlane: int
    def __init__(self) -> None:
        """__init__(self: depthai.RawImageAlignConfig) -> None"""

class RawImageManipConfig(RawBuffer):
    class CropConfig:
        cropRatio: float
        cropRect: RawImageManipConfig.CropRect
        cropRotatedRect: RotatedRect
        enableCenterCropRectangle: bool
        enableRotatedRect: bool
        normalizedCoords: bool
        widthHeightAspectRatio: float
        def __init__(self) -> None:
            """__init__(self: depthai.RawImageManipConfig.CropConfig) -> None"""

    class CropRect:
        xmax: float
        xmin: float
        ymax: float
        ymin: float
        def __init__(self) -> None:
            """__init__(self: depthai.RawImageManipConfig.CropRect) -> None"""

    class FormatConfig:
        flipHorizontal: bool
        flipVertical: bool
        type: RawImgFrame.Type
        def __init__(self) -> None:
            """__init__(self: depthai.RawImageManipConfig.FormatConfig) -> None"""

    class ResizeConfig:
        bgBlue: str
        bgGreen: str
        bgRed: str
        enableRotation: bool
        enableWarp4pt: bool
        enableWarpMatrix: bool
        height: int
        keepAspectRatio: bool
        lockAspectRatioFill: bool
        normalizedCoords: bool
        rotationAngleDeg: float
        warpBorderReplicate: bool
        warpFourPoints: list[Point2f]
        warpMatrix3x3: list[float]
        width: int
        def __init__(self) -> None:
            """__init__(self: depthai.RawImageManipConfig.ResizeConfig) -> None"""
    cropConfig: RawImageManipConfig.CropConfig
    enableCrop: bool
    enableFormat: bool
    enableResize: bool
    formatConfig: RawImageManipConfig.FormatConfig
    interpolation: Interpolation
    resizeConfig: RawImageManipConfig.ResizeConfig
    def __init__(self) -> None:
        """__init__(self: depthai.RawImageManipConfig) -> None"""

class RawImgDetections(RawBuffer):
    detections: list[ImgDetection]
    sequenceNum: int
    ts: float
    tsDevice: float
    def __init__(self) -> None:
        """__init__(self: depthai.RawImgDetections) -> None"""

class RawImgFrame(RawBuffer):
    class Specs:
        bytesPP: int
        height: int
        p1Offset: int
        p2Offset: int
        p3Offset: int
        stride: int
        type: RawImgFrame.Type
        width: int
        def __init__(self) -> None:
            """__init__(self: depthai.RawImgFrame.Specs) -> None"""

    class Type:
        __members__: ClassVar[dict] = ...  # read-only
        BGR888i: ClassVar[RawImgFrame.Type] = ...
        BGR888p: ClassVar[RawImgFrame.Type] = ...
        BGRF16F16F16i: ClassVar[RawImgFrame.Type] = ...
        BGRF16F16F16p: ClassVar[RawImgFrame.Type] = ...
        BITSTREAM: ClassVar[RawImgFrame.Type] = ...
        GRAY8: ClassVar[RawImgFrame.Type] = ...
        GRAYF16: ClassVar[RawImgFrame.Type] = ...
        HDR: ClassVar[RawImgFrame.Type] = ...
        LUT16: ClassVar[RawImgFrame.Type] = ...
        LUT2: ClassVar[RawImgFrame.Type] = ...
        LUT4: ClassVar[RawImgFrame.Type] = ...
        NONE: ClassVar[RawImgFrame.Type] = ...
        NV12: ClassVar[RawImgFrame.Type] = ...
        NV21: ClassVar[RawImgFrame.Type] = ...
        PACK10: ClassVar[RawImgFrame.Type] = ...
        PACK12: ClassVar[RawImgFrame.Type] = ...
        RAW10: ClassVar[RawImgFrame.Type] = ...
        RAW12: ClassVar[RawImgFrame.Type] = ...
        RAW14: ClassVar[RawImgFrame.Type] = ...
        RAW16: ClassVar[RawImgFrame.Type] = ...
        RAW8: ClassVar[RawImgFrame.Type] = ...
        RGB161616: ClassVar[RawImgFrame.Type] = ...
        RGB888i: ClassVar[RawImgFrame.Type] = ...
        RGB888p: ClassVar[RawImgFrame.Type] = ...
        RGBA8888: ClassVar[RawImgFrame.Type] = ...
        RGBF16F16F16i: ClassVar[RawImgFrame.Type] = ...
        RGBF16F16F16p: ClassVar[RawImgFrame.Type] = ...
        YUV400p: ClassVar[RawImgFrame.Type] = ...
        YUV420p: ClassVar[RawImgFrame.Type] = ...
        YUV422i: ClassVar[RawImgFrame.Type] = ...
        YUV422p: ClassVar[RawImgFrame.Type] = ...
        YUV444i: ClassVar[RawImgFrame.Type] = ...
        YUV444p: ClassVar[RawImgFrame.Type] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawImgFrame.Type, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawImgFrame.Type) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawImgFrame.Type) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    category: int
    fb: RawImgFrame.Specs
    instanceNum: int
    sequenceNum: int
    ts: float
    tsDevice: float
    def __init__(self) -> None:
        """__init__(self: depthai.RawImgFrame) -> None"""

class RawMessageGroup(RawBuffer):
    group: Incomplete
    def __init__(self) -> None:
        """__init__(self: depthai.RawMessageGroup) -> None"""

class RawNNData(RawBuffer):
    batchSize: int
    sequenceNum: int
    tensors: list[TensorInfo]
    ts: float
    tsDevice: float
    def __init__(self) -> None:
        """__init__(self: depthai.RawNNData) -> None"""

class RawPointCloudConfig(RawBuffer):
    sparse: bool
    transformationMatrix: Incomplete
    def __init__(self) -> None:
        """__init__(self: depthai.RawPointCloudConfig) -> None"""

class RawPointCloudData(RawBuffer):
    height: int
    instanceNum: int
    maxx: float
    maxy: float
    maxz: float
    minx: float
    miny: float
    minz: float
    sparse: bool
    width: int
    def __init__(self) -> None:
        """__init__(self: depthai.RawPointCloudData) -> None"""

class RawSpatialImgDetections(RawBuffer):
    detections: list[SpatialImgDetection]
    sequenceNum: int
    ts: float
    tsDevice: float
    def __init__(self) -> None:
        """__init__(self: depthai.RawSpatialImgDetections) -> None"""

class RawStereoDepthConfig(RawBuffer):
    class AlgorithmControl:
        class DepthAlign:
            __members__: ClassVar[dict] = ...  # read-only
            CENTER: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthAlign] = ...
            RECTIFIED_LEFT: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthAlign] = ...
            RECTIFIED_RIGHT: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthAlign] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthAlign, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthAlign) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthAlign) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...

        class DepthUnit:
            __members__: ClassVar[dict] = ...  # read-only
            CENTIMETER: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            CUSTOM: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            FOOT: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            INCH: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            METER: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            MILLIMETER: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthUnit, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthUnit) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthUnit) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...
        centerAlignmentShiftFactor: float | None
        customDepthUnitMultiplier: float
        depthAlign: RawStereoDepthConfig.AlgorithmControl.DepthAlign
        depthUnit: RawStereoDepthConfig.AlgorithmControl.DepthUnit
        disparityShift: int
        enableExtended: bool
        enableLeftRightCheck: bool
        enableSubpixel: bool
        leftRightCheckThreshold: int
        numInvalidateEdgePixels: int
        subpixelFractionalBits: int
        def __init__(self) -> None:
            """__init__(self: depthai.RawStereoDepthConfig.AlgorithmControl) -> None"""

    class CensusTransform:
        class KernelSize:
            __members__: ClassVar[dict] = ...  # read-only
            AUTO: ClassVar[RawStereoDepthConfig.CensusTransform.KernelSize] = ...
            KERNEL_5x5: ClassVar[RawStereoDepthConfig.CensusTransform.KernelSize] = ...
            KERNEL_7x7: ClassVar[RawStereoDepthConfig.CensusTransform.KernelSize] = ...
            KERNEL_7x9: ClassVar[RawStereoDepthConfig.CensusTransform.KernelSize] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.CensusTransform.KernelSize, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawStereoDepthConfig.CensusTransform.KernelSize) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawStereoDepthConfig.CensusTransform.KernelSize) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...
        enableMeanMode: bool
        kernelMask: int
        kernelSize: RawStereoDepthConfig.CensusTransform.KernelSize
        threshold: int
        def __init__(self) -> None:
            """__init__(self: depthai.RawStereoDepthConfig.CensusTransform) -> None"""

    class CostAggregation:
        divisionFactor: int
        horizontalPenaltyCostP1: int
        horizontalPenaltyCostP2: int
        verticalPenaltyCostP1: int
        verticalPenaltyCostP2: int
        def __init__(self) -> None:
            """__init__(self: depthai.RawStereoDepthConfig.CostAggregation) -> None"""

    class CostMatching:
        class DisparityWidth:
            __members__: ClassVar[dict] = ...  # read-only
            DISPARITY_64: ClassVar[RawStereoDepthConfig.CostMatching.DisparityWidth] = ...
            DISPARITY_96: ClassVar[RawStereoDepthConfig.CostMatching.DisparityWidth] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.CostMatching.DisparityWidth, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawStereoDepthConfig.CostMatching.DisparityWidth) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawStereoDepthConfig.CostMatching.DisparityWidth) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...

        class LinearEquationParameters:
            alpha: int
            beta: int
            threshold: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.CostMatching.LinearEquationParameters) -> None"""
        confidenceThreshold: int
        disparityWidth: RawStereoDepthConfig.CostMatching.DisparityWidth
        enableCompanding: bool
        invalidDisparityValue: int
        linearEquationParameters: RawStereoDepthConfig.CostMatching.LinearEquationParameters
        def __init__(self) -> None:
            """__init__(self: depthai.RawStereoDepthConfig.CostMatching) -> None"""

    class MedianFilter:
        __members__: ClassVar[dict] = ...  # read-only
        KERNEL_3x3: ClassVar[MedianFilter] = ...
        KERNEL_5x5: ClassVar[MedianFilter] = ...
        KERNEL_7x7: ClassVar[MedianFilter] = ...
        MEDIAN_OFF: ClassVar[MedianFilter] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.MedianFilter, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.MedianFilter) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.MedianFilter) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class PostProcessing:
        class BrightnessFilter:
            maxBrightness: int
            minBrightness: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.BrightnessFilter) -> None"""

        class DecimationFilter:
            class DecimationMode:
                __members__: ClassVar[dict] = ...  # read-only
                NON_ZERO_MEAN: ClassVar[RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode] = ...
                NON_ZERO_MEDIAN: ClassVar[RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode] = ...
                PIXEL_SKIPPING: ClassVar[RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode] = ...
                __entries: ClassVar[dict] = ...
                def __init__(self, value: int) -> None:
                    """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode, value: int) -> None"""
                def __eq__(self, other: object) -> bool:
                    """__eq__(self: object, other: object) -> bool"""
                def __hash__(self) -> int:
                    """__hash__(self: object) -> int"""
                def __index__(self) -> int:
                    """__index__(self: depthai.RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode) -> int"""
                def __int__(self) -> int:
                    """__int__(self: depthai.RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode) -> int"""
                def __ne__(self, other: object) -> bool:
                    """__ne__(self: object, other: object) -> bool"""
                @property
                def name(self) -> str: ...
                @property
                def value(self) -> int: ...
            decimationFactor: int
            decimationMode: RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.DecimationFilter) -> None"""

        class Filter:
            __members__: ClassVar[dict] = ...  # read-only
            DECIMATION: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            FILTER_COUNT: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            MEDIAN: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            SPATIAL: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            SPECKLE: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            TEMPORAL: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.Filter, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawStereoDepthConfig.PostProcessing.Filter) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawStereoDepthConfig.PostProcessing.Filter) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...

        class SpatialFilter:
            alpha: float
            delta: int
            enable: bool
            holeFillingRadius: int
            numIterations: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.SpatialFilter) -> None"""

        class SpeckleFilter:
            differenceThreshold: int
            enable: bool
            speckleRange: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.SpeckleFilter) -> None"""

        class TemporalFilter:
            class PersistencyMode:
                __members__: ClassVar[dict] = ...  # read-only
                PERSISTENCY_INDEFINITELY: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                PERSISTENCY_OFF: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_1_IN_LAST_2: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_1_IN_LAST_5: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_1_IN_LAST_8: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_2_IN_LAST_3: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_2_IN_LAST_4: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_2_OUT_OF_8: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_8_OUT_OF_8: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                __entries: ClassVar[dict] = ...
                def __init__(self, value: int) -> None:
                    """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode, value: int) -> None"""
                def __eq__(self, other: object) -> bool:
                    """__eq__(self: object, other: object) -> bool"""
                def __hash__(self) -> int:
                    """__hash__(self: object) -> int"""
                def __index__(self) -> int:
                    """__index__(self: depthai.RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode) -> int"""
                def __int__(self) -> int:
                    """__int__(self: depthai.RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode) -> int"""
                def __ne__(self, other: object) -> bool:
                    """__ne__(self: object, other: object) -> bool"""
                @property
                def name(self) -> str: ...
                @property
                def value(self) -> int: ...
            alpha: float
            delta: int
            enable: bool
            persistencyMode: RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.TemporalFilter) -> None"""

        class ThresholdFilter:
            maxRange: int
            minRange: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.ThresholdFilter) -> None"""
        bilateralSigmaValue: int
        brightnessFilter: RawStereoDepthConfig.PostProcessing.BrightnessFilter
        decimationFilter: RawStereoDepthConfig.PostProcessing.DecimationFilter
        filteringOrder: Incomplete
        median: MedianFilter
        spatialFilter: RawStereoDepthConfig.PostProcessing.SpatialFilter
        speckleFilter: RawStereoDepthConfig.PostProcessing.SpeckleFilter
        temporalFilter: RawStereoDepthConfig.PostProcessing.TemporalFilter
        thresholdFilter: RawStereoDepthConfig.PostProcessing.ThresholdFilter
        def __init__(self) -> None:
            """__init__(self: depthai.RawStereoDepthConfig.PostProcessing) -> None"""
    algorithmControl: RawStereoDepthConfig.AlgorithmControl
    censusTransform: RawStereoDepthConfig.CensusTransform
    costAggregation: RawStereoDepthConfig.CostAggregation
    costMatching: RawStereoDepthConfig.CostMatching
    postProcessing: RawStereoDepthConfig.PostProcessing
    def __init__(self) -> None:
        """__init__(self: depthai.RawStereoDepthConfig) -> None"""

class RawSystemInformation(RawBuffer):
    chipTemperature: ChipTemperature
    cmxMemoryUsage: MemoryInfo
    ddrMemoryUsage: MemoryInfo
    leonCssCpuUsage: CpuUsage
    leonCssMemoryUsage: MemoryInfo
    leonMssCpuUsage: CpuUsage
    leonMssMemoryUsage: MemoryInfo
    def __init__(self) -> None:
        """__init__(self: depthai.RawSystemInformation) -> None"""

class RawToFConfig(RawBuffer):
    enableBurstMode: bool
    enableDistortionCorrection: bool
    enableFPPNCorrection: bool | None
    enableOpticalCorrection: bool | None
    enablePhaseShuffleTemporalFilter: bool
    enablePhaseUnwrapping: bool | None
    enableTemperatureCorrection: bool | None
    enableWiggleCorrection: bool | None
    median: MedianFilter
    phaseUnwrapErrorThreshold: int
    phaseUnwrappingLevel: int
    def __init__(self) -> None:
        """__init__(self: depthai.RawToFConfig) -> None"""

class RawTrackedFeatures(RawBuffer):
    trackedFeatures: list[TrackedFeature]
    def __init__(self) -> None:
        """__init__(self: depthai.RawTrackedFeatures) -> None"""

class RawTracklets(RawBuffer):
    tracklets: list[Tracklet]
    def __init__(self) -> None:
        """__init__(self: depthai.RawTracklets) -> None"""

class Rect:
    height: float
    width: float
    x: float
    y: float
    @overload
    def __init__(self) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Rect) -> None

        2. __init__(self: depthai.Rect, arg0: float, arg1: float, arg2: float, arg3: float) -> None

        3. __init__(self: depthai.Rect, arg0: depthai.Point2f, arg1: depthai.Point2f) -> None

        4. __init__(self: depthai.Rect, arg0: depthai.Point2f, arg1: depthai.Size2f) -> None
        """
    @overload
    def __init__(self, arg0: float, arg1: float, arg2: float, arg3: float) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Rect) -> None

        2. __init__(self: depthai.Rect, arg0: float, arg1: float, arg2: float, arg3: float) -> None

        3. __init__(self: depthai.Rect, arg0: depthai.Point2f, arg1: depthai.Point2f) -> None

        4. __init__(self: depthai.Rect, arg0: depthai.Point2f, arg1: depthai.Size2f) -> None
        """
    @overload
    def __init__(self, arg0: Point2f, arg1: Point2f) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Rect) -> None

        2. __init__(self: depthai.Rect, arg0: float, arg1: float, arg2: float, arg3: float) -> None

        3. __init__(self: depthai.Rect, arg0: depthai.Point2f, arg1: depthai.Point2f) -> None

        4. __init__(self: depthai.Rect, arg0: depthai.Point2f, arg1: depthai.Size2f) -> None
        """
    @overload
    def __init__(self, arg0: Point2f, arg1: Size2f) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Rect) -> None

        2. __init__(self: depthai.Rect, arg0: float, arg1: float, arg2: float, arg3: float) -> None

        3. __init__(self: depthai.Rect, arg0: depthai.Point2f, arg1: depthai.Point2f) -> None

        4. __init__(self: depthai.Rect, arg0: depthai.Point2f, arg1: depthai.Size2f) -> None
        """
    def area(self) -> float:
        """area(self: depthai.Rect) -> float

        Area (width*height) of the rectangle
        """
    def bottomRight(self) -> Point2f:
        """bottomRight(self: depthai.Rect) -> depthai.Point2f

        The bottom-right corner
        """
    def contains(self, arg0: Point2f) -> bool:
        """contains(self: depthai.Rect, arg0: depthai.Point2f) -> bool

        Checks whether the rectangle contains the point.
        """
    def denormalize(self, width: int, height: int) -> Rect:
        """denormalize(self: depthai.Rect, width: int, height: int) -> depthai.Rect

        Denormalize rectangle.

        Parameter ``destWidth``:
            Destination frame width.

        Parameter ``destHeight``:
            Destination frame height.
        """
    def empty(self) -> bool:
        """empty(self: depthai.Rect) -> bool

        True if rectangle is empty.
        """
    def isNormalized(self) -> bool:
        """isNormalized(self: depthai.Rect) -> bool

        Whether rectangle is normalized (coordinates in [0,1] range) or not.
        """
    def normalize(self, width: int, height: int) -> Rect:
        """normalize(self: depthai.Rect, width: int, height: int) -> depthai.Rect

        Normalize rectangle.

        Parameter ``srcWidth``:
            Source frame width.

        Parameter ``srcHeight``:
            Source frame height.
        """
    def size(self) -> Size2f:
        """size(self: depthai.Rect) -> depthai.Size2f

        Size (width, height) of the rectangle
        """
    def topLeft(self) -> Point2f:
        """topLeft(self: depthai.Rect) -> depthai.Point2f

        The top-left corner.
        """

class RotatedRect:
    angle: float
    center: Point2f
    size: Size2f
    def __init__(self) -> None:
        """__init__(self: depthai.RotatedRect) -> None"""

class SPIInProperties:
    busId: int
    maxDataSize: int
    numFrames: int
    streamName: str
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class SPIOutProperties:
    busId: int
    streamName: str
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class ScriptProperties:
    processor: ProcessorType
    scriptName: str
    scriptUri: str
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class SerializationType:
    __members__: ClassVar[dict] = ...  # read-only
    JSON: ClassVar[SerializationType] = ...
    JSON_MSGPACK: ClassVar[SerializationType] = ...
    LIBNOP: ClassVar[SerializationType] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.SerializationType, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.SerializationType) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.SerializationType) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class Size2f:
    height: float
    width: float
    @overload
    def __init__(self) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Size2f) -> None

        2. __init__(self: depthai.Size2f, arg0: float, arg1: float) -> None
        """
    @overload
    def __init__(self, arg0: float, arg1: float) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Size2f) -> None

        2. __init__(self: depthai.Size2f, arg0: float, arg1: float) -> None
        """

class SpatialDetectionNetworkProperties(DetectionNetworkProperties):
    depthThresholds: SpatialLocationCalculatorConfigThresholds
    detectedBBScaleFactor: float
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class SpatialImgDetection(ImgDetection):
    boundingBoxMapping: SpatialLocationCalculatorConfigData
    spatialCoordinates: Point3f
    def __init__(self) -> None:
        """__init__(self: depthai.SpatialImgDetection) -> None"""

class SpatialImgDetections(Buffer):
    detections: list[SpatialImgDetection]
    def __init__(self) -> None:
        """__init__(self: depthai.SpatialImgDetections) -> None"""
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.SpatialImgDetections) -> int

        Retrieves sequence number
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.SpatialImgDetections) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.SpatialImgDetections) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """
    def setSequenceNum(self, arg0: int) -> SpatialImgDetections:
        """setSequenceNum(self: depthai.SpatialImgDetections, arg0: int) -> depthai.SpatialImgDetections

        Retrieves image sequence number
        """
    def setTimestamp(self, arg0: datetime.timedelta) -> SpatialImgDetections:
        """setTimestamp(self: depthai.SpatialImgDetections, arg0: datetime.timedelta) -> depthai.SpatialImgDetections

        Sets image timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> SpatialImgDetections:
        """setTimestampDevice(self: depthai.SpatialImgDetections, arg0: datetime.timedelta) -> depthai.SpatialImgDetections

        Sets image timestamp related to dai::Clock::now()
        """

class SpatialLocationCalculatorAlgorithm:
    __members__: ClassVar[dict] = ...  # read-only
    AVERAGE: ClassVar[SpatialLocationCalculatorAlgorithm] = ...
    MAX: ClassVar[SpatialLocationCalculatorAlgorithm] = ...
    MEAN: ClassVar[SpatialLocationCalculatorAlgorithm] = ...
    MEDIAN: ClassVar[SpatialLocationCalculatorAlgorithm] = ...
    MIN: ClassVar[SpatialLocationCalculatorAlgorithm] = ...
    MODE: ClassVar[SpatialLocationCalculatorAlgorithm] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.SpatialLocationCalculatorAlgorithm, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.SpatialLocationCalculatorAlgorithm) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.SpatialLocationCalculatorAlgorithm) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class SpatialLocationCalculatorConfig(Buffer):
    def __init__(self) -> None:
        """__init__(self: depthai.SpatialLocationCalculatorConfig) -> None"""
    def addROI(self, ROI: SpatialLocationCalculatorConfigData) -> None:
        """addROI(self: depthai.SpatialLocationCalculatorConfig, ROI: depthai.SpatialLocationCalculatorConfigData) -> None

        Add a new ROI to configuration data.

        Parameter ``roi``:
            Configuration parameters for ROI (region of interest)
        """
    def get(self, *args, **kwargs):
        """get(self: depthai.SpatialLocationCalculatorConfig) -> dai::RawSpatialLocationCalculatorConfig

        Retrieve configuration data for SpatialLocationCalculator.

        Returns:
            config for SpatialLocationCalculator
        """
    def getConfigData(self) -> list[SpatialLocationCalculatorConfigData]:
        """getConfigData(self: depthai.SpatialLocationCalculatorConfig) -> list[depthai.SpatialLocationCalculatorConfigData]

        Retrieve configuration data for SpatialLocationCalculator

        Returns:
            Vector of configuration parameters for ROIs (region of interests)
        """
    def set(self, config) -> SpatialLocationCalculatorConfig:
        """set(self: depthai.SpatialLocationCalculatorConfig, config: dai::RawSpatialLocationCalculatorConfig) -> depthai.SpatialLocationCalculatorConfig

        Set explicit configuration.

        Parameter ``config``:
            Explicit configuration
        """
    def setROIs(self, ROIs: list[SpatialLocationCalculatorConfigData]) -> None:
        """setROIs(self: depthai.SpatialLocationCalculatorConfig, ROIs: list[depthai.SpatialLocationCalculatorConfigData]) -> None

        Set a vector of ROIs as configuration data.

        Parameter ``ROIs``:
            Vector of configuration parameters for ROIs (region of interests)
        """

class SpatialLocationCalculatorConfigData:
    calculationAlgorithm: SpatialLocationCalculatorAlgorithm
    depthThresholds: SpatialLocationCalculatorConfigThresholds
    roi: Rect
    def __init__(self) -> None:
        """__init__(self: depthai.SpatialLocationCalculatorConfigData) -> None"""

class SpatialLocationCalculatorConfigThresholds:
    lowerThreshold: int
    upperThreshold: int
    def __init__(self) -> None:
        """__init__(self: depthai.SpatialLocationCalculatorConfigThresholds) -> None"""

class SpatialLocationCalculatorData(Buffer):
    spatialLocations: list[SpatialLocations]
    def __init__(self) -> None:
        """__init__(self: depthai.SpatialLocationCalculatorData) -> None"""
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.SpatialLocationCalculatorData) -> int

        Retrieves sequence number
        """
    def getSpatialLocations(self) -> list[SpatialLocations]:
        """getSpatialLocations(self: depthai.SpatialLocationCalculatorData) -> list[depthai.SpatialLocations]

        Retrieve configuration data for SpatialLocationCalculatorData.

        Returns:
            Vector of spatial location data, carrying spatial information (X,Y,Z)
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.SpatialLocationCalculatorData) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.SpatialLocationCalculatorData) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """
    def setSequenceNum(self, arg0: int) -> SpatialLocationCalculatorData:
        """setSequenceNum(self: depthai.SpatialLocationCalculatorData, arg0: int) -> depthai.SpatialLocationCalculatorData

        Retrieves image sequence number
        """
    def setTimestamp(self, arg0: datetime.timedelta) -> SpatialLocationCalculatorData:
        """setTimestamp(self: depthai.SpatialLocationCalculatorData, arg0: datetime.timedelta) -> depthai.SpatialLocationCalculatorData

        Sets image timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> SpatialLocationCalculatorData:
        """setTimestampDevice(self: depthai.SpatialLocationCalculatorData, arg0: datetime.timedelta) -> depthai.SpatialLocationCalculatorData

        Sets image timestamp related to dai::Clock::now()
        """

class SpatialLocationCalculatorProperties:
    roiConfig: Incomplete
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class SpatialLocations:
    config: SpatialLocationCalculatorConfigData
    depthAverage: float
    depthAveragePixelCount: int
    depthMax: int
    depthMedian: float
    depthMin: int
    depthMode: float
    spatialCoordinates: Point3f
    def __init__(self) -> None:
        """__init__(self: depthai.SpatialLocations) -> None"""

class StereoDepthConfig(Buffer):
    class AlgorithmControl:
        class DepthAlign:
            __members__: ClassVar[dict] = ...  # read-only
            CENTER: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthAlign] = ...
            RECTIFIED_LEFT: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthAlign] = ...
            RECTIFIED_RIGHT: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthAlign] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthAlign, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthAlign) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthAlign) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...

        class DepthUnit:
            __members__: ClassVar[dict] = ...  # read-only
            CENTIMETER: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            CUSTOM: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            FOOT: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            INCH: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            METER: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            MILLIMETER: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthUnit] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthUnit, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthUnit) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthUnit) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...
        centerAlignmentShiftFactor: float | None
        customDepthUnitMultiplier: float
        depthAlign: RawStereoDepthConfig.AlgorithmControl.DepthAlign
        depthUnit: RawStereoDepthConfig.AlgorithmControl.DepthUnit
        disparityShift: int
        enableExtended: bool
        enableLeftRightCheck: bool
        enableSubpixel: bool
        leftRightCheckThreshold: int
        numInvalidateEdgePixels: int
        subpixelFractionalBits: int
        def __init__(self) -> None:
            """__init__(self: depthai.RawStereoDepthConfig.AlgorithmControl) -> None"""

    class CensusTransform:
        class KernelSize:
            __members__: ClassVar[dict] = ...  # read-only
            AUTO: ClassVar[RawStereoDepthConfig.CensusTransform.KernelSize] = ...
            KERNEL_5x5: ClassVar[RawStereoDepthConfig.CensusTransform.KernelSize] = ...
            KERNEL_7x7: ClassVar[RawStereoDepthConfig.CensusTransform.KernelSize] = ...
            KERNEL_7x9: ClassVar[RawStereoDepthConfig.CensusTransform.KernelSize] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.CensusTransform.KernelSize, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawStereoDepthConfig.CensusTransform.KernelSize) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawStereoDepthConfig.CensusTransform.KernelSize) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...
        enableMeanMode: bool
        kernelMask: int
        kernelSize: RawStereoDepthConfig.CensusTransform.KernelSize
        threshold: int
        def __init__(self) -> None:
            """__init__(self: depthai.RawStereoDepthConfig.CensusTransform) -> None"""

    class CostAggregation:
        divisionFactor: int
        horizontalPenaltyCostP1: int
        horizontalPenaltyCostP2: int
        verticalPenaltyCostP1: int
        verticalPenaltyCostP2: int
        def __init__(self) -> None:
            """__init__(self: depthai.RawStereoDepthConfig.CostAggregation) -> None"""

    class CostMatching:
        class DisparityWidth:
            __members__: ClassVar[dict] = ...  # read-only
            DISPARITY_64: ClassVar[RawStereoDepthConfig.CostMatching.DisparityWidth] = ...
            DISPARITY_96: ClassVar[RawStereoDepthConfig.CostMatching.DisparityWidth] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.CostMatching.DisparityWidth, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawStereoDepthConfig.CostMatching.DisparityWidth) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawStereoDepthConfig.CostMatching.DisparityWidth) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...

        class LinearEquationParameters:
            alpha: int
            beta: int
            threshold: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.CostMatching.LinearEquationParameters) -> None"""
        confidenceThreshold: int
        disparityWidth: RawStereoDepthConfig.CostMatching.DisparityWidth
        enableCompanding: bool
        invalidDisparityValue: int
        linearEquationParameters: RawStereoDepthConfig.CostMatching.LinearEquationParameters
        def __init__(self) -> None:
            """__init__(self: depthai.RawStereoDepthConfig.CostMatching) -> None"""

    class MedianFilter:
        __members__: ClassVar[dict] = ...  # read-only
        KERNEL_3x3: ClassVar[MedianFilter] = ...
        KERNEL_5x5: ClassVar[MedianFilter] = ...
        KERNEL_7x7: ClassVar[MedianFilter] = ...
        MEDIAN_OFF: ClassVar[MedianFilter] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.MedianFilter, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.MedianFilter) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.MedianFilter) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class PostProcessing:
        class BrightnessFilter:
            maxBrightness: int
            minBrightness: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.BrightnessFilter) -> None"""

        class DecimationFilter:
            class DecimationMode:
                __members__: ClassVar[dict] = ...  # read-only
                NON_ZERO_MEAN: ClassVar[RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode] = ...
                NON_ZERO_MEDIAN: ClassVar[RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode] = ...
                PIXEL_SKIPPING: ClassVar[RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode] = ...
                __entries: ClassVar[dict] = ...
                def __init__(self, value: int) -> None:
                    """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode, value: int) -> None"""
                def __eq__(self, other: object) -> bool:
                    """__eq__(self: object, other: object) -> bool"""
                def __hash__(self) -> int:
                    """__hash__(self: object) -> int"""
                def __index__(self) -> int:
                    """__index__(self: depthai.RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode) -> int"""
                def __int__(self) -> int:
                    """__int__(self: depthai.RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode) -> int"""
                def __ne__(self, other: object) -> bool:
                    """__ne__(self: object, other: object) -> bool"""
                @property
                def name(self) -> str: ...
                @property
                def value(self) -> int: ...
            decimationFactor: int
            decimationMode: RawStereoDepthConfig.PostProcessing.DecimationFilter.DecimationMode
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.DecimationFilter) -> None"""

        class Filter:
            __members__: ClassVar[dict] = ...  # read-only
            DECIMATION: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            FILTER_COUNT: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            MEDIAN: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            SPATIAL: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            SPECKLE: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            TEMPORAL: ClassVar[RawStereoDepthConfig.PostProcessing.Filter] = ...
            __entries: ClassVar[dict] = ...
            def __init__(self, value: int) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.Filter, value: int) -> None"""
            def __eq__(self, other: object) -> bool:
                """__eq__(self: object, other: object) -> bool"""
            def __hash__(self) -> int:
                """__hash__(self: object) -> int"""
            def __index__(self) -> int:
                """__index__(self: depthai.RawStereoDepthConfig.PostProcessing.Filter) -> int"""
            def __int__(self) -> int:
                """__int__(self: depthai.RawStereoDepthConfig.PostProcessing.Filter) -> int"""
            def __ne__(self, other: object) -> bool:
                """__ne__(self: object, other: object) -> bool"""
            @property
            def name(self) -> str: ...
            @property
            def value(self) -> int: ...

        class SpatialFilter:
            alpha: float
            delta: int
            enable: bool
            holeFillingRadius: int
            numIterations: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.SpatialFilter) -> None"""

        class SpeckleFilter:
            differenceThreshold: int
            enable: bool
            speckleRange: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.SpeckleFilter) -> None"""

        class TemporalFilter:
            class PersistencyMode:
                __members__: ClassVar[dict] = ...  # read-only
                PERSISTENCY_INDEFINITELY: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                PERSISTENCY_OFF: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_1_IN_LAST_2: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_1_IN_LAST_5: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_1_IN_LAST_8: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_2_IN_LAST_3: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_2_IN_LAST_4: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_2_OUT_OF_8: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                VALID_8_OUT_OF_8: ClassVar[RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode] = ...
                __entries: ClassVar[dict] = ...
                def __init__(self, value: int) -> None:
                    """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode, value: int) -> None"""
                def __eq__(self, other: object) -> bool:
                    """__eq__(self: object, other: object) -> bool"""
                def __hash__(self) -> int:
                    """__hash__(self: object) -> int"""
                def __index__(self) -> int:
                    """__index__(self: depthai.RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode) -> int"""
                def __int__(self) -> int:
                    """__int__(self: depthai.RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode) -> int"""
                def __ne__(self, other: object) -> bool:
                    """__ne__(self: object, other: object) -> bool"""
                @property
                def name(self) -> str: ...
                @property
                def value(self) -> int: ...
            alpha: float
            delta: int
            enable: bool
            persistencyMode: RawStereoDepthConfig.PostProcessing.TemporalFilter.PersistencyMode
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.TemporalFilter) -> None"""

        class ThresholdFilter:
            maxRange: int
            minRange: int
            def __init__(self) -> None:
                """__init__(self: depthai.RawStereoDepthConfig.PostProcessing.ThresholdFilter) -> None"""
        bilateralSigmaValue: int
        brightnessFilter: RawStereoDepthConfig.PostProcessing.BrightnessFilter
        decimationFilter: RawStereoDepthConfig.PostProcessing.DecimationFilter
        filteringOrder: Incomplete
        median: MedianFilter
        spatialFilter: RawStereoDepthConfig.PostProcessing.SpatialFilter
        speckleFilter: RawStereoDepthConfig.PostProcessing.SpeckleFilter
        temporalFilter: RawStereoDepthConfig.PostProcessing.TemporalFilter
        thresholdFilter: RawStereoDepthConfig.PostProcessing.ThresholdFilter
        def __init__(self) -> None:
            """__init__(self: depthai.RawStereoDepthConfig.PostProcessing) -> None"""
    def __init__(self) -> None:
        """__init__(self: depthai.StereoDepthConfig) -> None"""
    def get(self) -> RawStereoDepthConfig:
        """get(self: depthai.StereoDepthConfig) -> depthai.RawStereoDepthConfig

        Retrieve configuration data for StereoDepth.

        Returns:
            config for stereo depth algorithm
        """
    def getBilateralFilterSigma(self) -> int:
        """getBilateralFilterSigma(self: depthai.StereoDepthConfig) -> int

        Get sigma value for 5x5 bilateral filter
        """
    def getConfidenceThreshold(self) -> int:
        """getConfidenceThreshold(self: depthai.StereoDepthConfig) -> int

        Get confidence threshold for disparity calculation
        """
    def getDepthUnit(self) -> RawStereoDepthConfig.AlgorithmControl.DepthUnit:
        """getDepthUnit(self: depthai.StereoDepthConfig) -> depthai.RawStereoDepthConfig.AlgorithmControl.DepthUnit

        Get depth unit of depth map.
        """
    def getLeftRightCheckThreshold(self) -> int:
        """getLeftRightCheckThreshold(self: depthai.StereoDepthConfig) -> int

        Get threshold for left-right check combine
        """
    def getMaxDisparity(self) -> float:
        """getMaxDisparity(self: depthai.StereoDepthConfig) -> float

        Useful for normalization of the disparity map.

        Returns:
            Maximum disparity value that the node can return
        """
    def getMedianFilter(self) -> MedianFilter:
        """getMedianFilter(self: depthai.StereoDepthConfig) -> depthai.MedianFilter

        Get median filter setting
        """
    def set(self, config: RawStereoDepthConfig) -> StereoDepthConfig:
        """set(self: depthai.StereoDepthConfig, config: depthai.RawStereoDepthConfig) -> depthai.StereoDepthConfig

        Set explicit configuration.

        Parameter ``config``:
            Explicit configuration
        """
    def setBilateralFilterSigma(self, sigma: int) -> StereoDepthConfig:
        """setBilateralFilterSigma(self: depthai.StereoDepthConfig, sigma: int) -> depthai.StereoDepthConfig

        A larger value of the parameter means that farther colors within the pixel
        neighborhood will be mixed together, resulting in larger areas of semi-equal
        color.

        Parameter ``sigma``:
            Set sigma value for 5x5 bilateral filter. 0..65535
        """
    def setConfidenceThreshold(self, confThr: int) -> StereoDepthConfig:
        """setConfidenceThreshold(self: depthai.StereoDepthConfig, confThr: int) -> depthai.StereoDepthConfig

        Confidence threshold for disparity calculation

        Parameter ``confThr``:
            Confidence threshold value 0..255
        """
    def setDepthAlign(self, align: RawStereoDepthConfig.AlgorithmControl.DepthAlign) -> StereoDepthConfig:
        """setDepthAlign(self: depthai.StereoDepthConfig, align: depthai.RawStereoDepthConfig.AlgorithmControl.DepthAlign) -> depthai.StereoDepthConfig

        Parameter ``align``:
            Set the disparity/depth alignment: centered (between the 'left' and 'right'
            inputs), or from the perspective of a rectified output stream
        """
    def setDepthUnit(self, arg0: RawStereoDepthConfig.AlgorithmControl.DepthUnit) -> StereoDepthConfig:
        """setDepthUnit(self: depthai.StereoDepthConfig, arg0: depthai.RawStereoDepthConfig.AlgorithmControl.DepthUnit) -> depthai.StereoDepthConfig

        Set depth unit of depth map.

        Meter, centimeter, millimeter, inch, foot or custom unit is available.
        """
    def setDisparityShift(self, arg0: int) -> StereoDepthConfig:
        """setDisparityShift(self: depthai.StereoDepthConfig, arg0: int) -> depthai.StereoDepthConfig

        Shift input frame by a number of pixels to increase minimum depth. For example
        shifting by 48 will change effective disparity search range from (0,95] to
        [48,143]. An alternative approach to reducing the minZ. We normally only
        recommend doing this when it is known that there will be no objects farther away
        than MaxZ, such as having a depth camera mounted above a table pointing down at
        the table surface.
        """
    def setExtendedDisparity(self, enable: bool) -> StereoDepthConfig:
        """setExtendedDisparity(self: depthai.StereoDepthConfig, enable: bool) -> depthai.StereoDepthConfig

        Disparity range increased from 95 to 190, combined from full resolution and
        downscaled images. Suitable for short range objects
        """
    def setLeftRightCheck(self, enable: bool) -> StereoDepthConfig:
        """setLeftRightCheck(self: depthai.StereoDepthConfig, enable: bool) -> depthai.StereoDepthConfig

        Computes and combines disparities in both L-R and R-L directions, and combine
        them.

        For better occlusion handling, discarding invalid disparity values
        """
    def setLeftRightCheckThreshold(self, sigma: int) -> StereoDepthConfig:
        """setLeftRightCheckThreshold(self: depthai.StereoDepthConfig, sigma: int) -> depthai.StereoDepthConfig

        Parameter ``threshold``:
            Set threshold for left-right, right-left disparity map combine, 0..255
        """
    def setMedianFilter(self, median: MedianFilter) -> StereoDepthConfig:
        """setMedianFilter(self: depthai.StereoDepthConfig, median: depthai.MedianFilter) -> depthai.StereoDepthConfig

        Parameter ``median``:
            Set kernel size for disparity/depth median filtering, or disable
        """
    def setNumInvalidateEdgePixels(self, arg0: int) -> StereoDepthConfig:
        """setNumInvalidateEdgePixels(self: depthai.StereoDepthConfig, arg0: int) -> depthai.StereoDepthConfig

        Invalidate X amount of pixels at the edge of disparity frame. For right and
        center alignment X pixels will be invalidated from the right edge, for left
        alignment from the left edge.
        """
    def setSubpixel(self, enable: bool) -> StereoDepthConfig:
        """setSubpixel(self: depthai.StereoDepthConfig, enable: bool) -> depthai.StereoDepthConfig

        Computes disparity with sub-pixel interpolation (3 fractional bits by default).

        Suitable for long range. Currently incompatible with extended disparity
        """
    def setSubpixelFractionalBits(self, subpixelFractionalBits: int) -> StereoDepthConfig:
        """setSubpixelFractionalBits(self: depthai.StereoDepthConfig, subpixelFractionalBits: int) -> depthai.StereoDepthConfig

        Number of fractional bits for subpixel mode. Default value: 3. Valid values:
        3,4,5. Defines the number of fractional disparities: 2^x. Median filter
        postprocessing is supported only for 3 fractional bits.
        """

class StereoDepthProperties:
    class DepthAlign:
        __members__: ClassVar[dict] = ...  # read-only
        CENTER: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthAlign] = ...
        RECTIFIED_LEFT: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthAlign] = ...
        RECTIFIED_RIGHT: ClassVar[RawStereoDepthConfig.AlgorithmControl.DepthAlign] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthAlign, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthAlign) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.RawStereoDepthConfig.AlgorithmControl.DepthAlign) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class MedianFilter:
        __members__: ClassVar[dict] = ...  # read-only
        KERNEL_3x3: ClassVar[MedianFilter] = ...
        KERNEL_5x5: ClassVar[MedianFilter] = ...
        KERNEL_7x7: ClassVar[MedianFilter] = ...
        MEDIAN_OFF: ClassVar[MedianFilter] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.MedianFilter, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.MedianFilter) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.MedianFilter) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class RectificationMesh:
        meshLeftUri: str
        meshRightUri: str
        meshSize: int | None
        stepHeight: int
        stepWidth: int
        def __init__(self, *args, **kwargs) -> None:
            """Initialize self.  See help(type(self)) for accurate signature."""
    alphaScaling: float | None
    baseline: float | None
    depthAlignCamera: CameraBoardSocket
    depthAlignmentUseSpecTranslation: bool | None
    disparityToDepthUseSpecTranslation: bool | None
    enableRectification: bool
    enableRuntimeStereoModeSwitch: bool
    focalLength: float | None
    focalLengthFromCalibration: bool
    height: int | None
    initialConfig: RawStereoDepthConfig
    mesh: StereoDepthProperties.RectificationMesh
    numFramesPool: int
    numPostProcessingMemorySlices: int
    numPostProcessingShaves: int
    outHeight: int | None
    outKeepAspectRatio: bool
    outWidth: int | None
    rectificationUseSpecTranslation: bool | None
    rectifyEdgeFillColor: int
    useHomographyRectification: bool | None
    width: int | None
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class StereoPair:
    baseline: float
    isVertical: bool
    left: CameraBoardSocket
    right: CameraBoardSocket
    def __init__(self) -> None:
        """__init__(self: depthai.StereoPair) -> None"""

class StereoRectification:
    leftCameraSocket: CameraBoardSocket
    rectifiedRotationLeft: list[list[float]]
    rectifiedRotationRight: list[list[float]]
    rightCameraSocket: CameraBoardSocket
    def __init__(self) -> None:
        """__init__(self: depthai.StereoRectification) -> None"""

class SyncProperties:
    syncAttempts: int
    syncThresholdNs: int
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class SystemInformation(Buffer):
    chipTemperature: ChipTemperature
    cmxMemoryUsage: MemoryInfo
    ddrMemoryUsage: MemoryInfo
    leonCssCpuUsage: CpuUsage
    leonCssMemoryUsage: MemoryInfo
    leonMssCpuUsage: CpuUsage
    leonMssMemoryUsage: MemoryInfo
    def __init__(self) -> None:
        """__init__(self: depthai.SystemInformation) -> None"""

class SystemLoggerProperties:
    rateHz: float
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class TensorInfo:
    class DataType:
        __members__: ClassVar[dict] = ...  # read-only
        FP16: ClassVar[TensorInfo.DataType] = ...
        FP32: ClassVar[TensorInfo.DataType] = ...
        I8: ClassVar[TensorInfo.DataType] = ...
        INT: ClassVar[TensorInfo.DataType] = ...
        U8F: ClassVar[TensorInfo.DataType] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.TensorInfo.DataType, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.TensorInfo.DataType) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.TensorInfo.DataType) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class StorageOrder:
        __members__: ClassVar[dict] = ...  # read-only
        C: ClassVar[TensorInfo.StorageOrder] = ...
        CHW: ClassVar[TensorInfo.StorageOrder] = ...
        CN: ClassVar[TensorInfo.StorageOrder] = ...
        CWH: ClassVar[TensorInfo.StorageOrder] = ...
        H: ClassVar[TensorInfo.StorageOrder] = ...
        HCW: ClassVar[TensorInfo.StorageOrder] = ...
        HWC: ClassVar[TensorInfo.StorageOrder] = ...
        NC: ClassVar[TensorInfo.StorageOrder] = ...
        NCHW: ClassVar[TensorInfo.StorageOrder] = ...
        NHCW: ClassVar[TensorInfo.StorageOrder] = ...
        NHWC: ClassVar[TensorInfo.StorageOrder] = ...
        W: ClassVar[TensorInfo.StorageOrder] = ...
        WCH: ClassVar[TensorInfo.StorageOrder] = ...
        WHC: ClassVar[TensorInfo.StorageOrder] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.TensorInfo.StorageOrder, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.TensorInfo.StorageOrder) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.TensorInfo.StorageOrder) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    dataType: TensorInfo.DataType
    dims: list[int]
    name: str
    numDimensions: int
    offset: int
    order: TensorInfo.StorageOrder
    strides: list[int]
    def __init__(self) -> None:
        """__init__(self: depthai.TensorInfo) -> None"""

class Timestamp:
    nsec: int
    sec: int
    def __init__(self) -> None:
        """__init__(self: depthai.Timestamp) -> None"""
    def get(self) -> datetime.timedelta:
        """get(self: depthai.Timestamp) -> datetime.timedelta"""

class ToFConfig(Buffer):
    @overload
    def __init__(self) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.ToFConfig) -> None

        2. __init__(self: depthai.ToFConfig, arg0: depthai.RawToFConfig) -> None
        """
    @overload
    def __init__(self, arg0: RawToFConfig) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.ToFConfig) -> None

        2. __init__(self: depthai.ToFConfig, arg0: depthai.RawToFConfig) -> None
        """
    def get(self) -> RawToFConfig:
        """get(self: depthai.ToFConfig) -> depthai.RawToFConfig

        Retrieve configuration data for ToF.

        Returns:
            config for feature tracking algorithm
        """
    def set(self, config: RawToFConfig) -> ToFConfig:
        """set(self: depthai.ToFConfig, config: depthai.RawToFConfig) -> depthai.ToFConfig

        Set explicit configuration.

        Parameter ``config``:
            Explicit configuration
        """
    def setMedianFilter(self, arg0: MedianFilter) -> ToFConfig:
        """setMedianFilter(self: depthai.ToFConfig, arg0: depthai.MedianFilter) -> depthai.ToFConfig

        Parameter ``median``:
            Set kernel size for median filtering, or disable
        """

class ToFProperties:
    initialConfig: RawToFConfig
    numFramesPool: int
    numShaves: int
    warpHwIds: list[int]
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class TrackedFeature:
    age: int
    harrisScore: float
    id: int
    position: Point2f
    trackingError: float
    def __init__(self) -> None:
        """__init__(self: depthai.TrackedFeature) -> None"""

class TrackedFeatures(Buffer):
    trackedFeatures: list[TrackedFeature]
    def __init__(self) -> None:
        """__init__(self: depthai.TrackedFeatures) -> None"""
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.TrackedFeatures) -> int

        Retrieves sequence number
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.TrackedFeatures) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.TrackedFeatures) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """
    def setSequenceNum(self, arg0: int) -> TrackedFeatures:
        """setSequenceNum(self: depthai.TrackedFeatures, arg0: int) -> depthai.TrackedFeatures

        Retrieves image sequence number
        """
    def setTimestamp(self, arg0: datetime.timedelta) -> TrackedFeatures:
        """setTimestamp(self: depthai.TrackedFeatures, arg0: datetime.timedelta) -> depthai.TrackedFeatures

        Sets image timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> TrackedFeatures:
        """setTimestampDevice(self: depthai.TrackedFeatures, arg0: datetime.timedelta) -> depthai.TrackedFeatures

        Sets image timestamp related to dai::Clock::now()
        """

class TrackerIdAssignmentPolicy:
    __members__: ClassVar[dict] = ...  # read-only
    SMALLEST_ID: ClassVar[TrackerIdAssignmentPolicy] = ...
    UNIQUE_ID: ClassVar[TrackerIdAssignmentPolicy] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.TrackerIdAssignmentPolicy, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.TrackerIdAssignmentPolicy) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.TrackerIdAssignmentPolicy) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class TrackerType:
    __members__: ClassVar[dict] = ...  # read-only
    SHORT_TERM_IMAGELESS: ClassVar[TrackerType] = ...
    SHORT_TERM_KCF: ClassVar[TrackerType] = ...
    ZERO_TERM_COLOR_HISTOGRAM: ClassVar[TrackerType] = ...
    ZERO_TERM_IMAGELESS: ClassVar[TrackerType] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.TrackerType, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.TrackerType) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.TrackerType) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class Tracklet:
    class TrackingStatus:
        __members__: ClassVar[dict] = ...  # read-only
        LOST: ClassVar[Tracklet.TrackingStatus] = ...
        NEW: ClassVar[Tracklet.TrackingStatus] = ...
        REMOVED: ClassVar[Tracklet.TrackingStatus] = ...
        TRACKED: ClassVar[Tracklet.TrackingStatus] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.Tracklet.TrackingStatus, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.Tracklet.TrackingStatus) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.Tracklet.TrackingStatus) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    age: int
    id: int
    label: int
    roi: Rect
    spatialCoordinates: Point3f
    srcImgDetection: ImgDetection
    status: Tracklet.TrackingStatus
    def __init__(self) -> None:
        """__init__(self: depthai.Tracklet) -> None"""

class Tracklets(Buffer):
    tracklets: list[Tracklet]
    def __init__(self) -> None:
        """__init__(self: depthai.Tracklets) -> None"""
    def getSequenceNum(self) -> int:
        """getSequenceNum(self: depthai.Tracklets) -> int

        Retrieves sequence number
        """
    def getTimestamp(self) -> datetime.timedelta:
        """getTimestamp(self: depthai.Tracklets) -> datetime.timedelta

        Retrieves timestamp related to dai::Clock::now()
        """
    def getTimestampDevice(self) -> datetime.timedelta:
        """getTimestampDevice(self: depthai.Tracklets) -> datetime.timedelta

        Retrieves timestamp directly captured from device's monotonic clock, not
        synchronized to host time. Used mostly for debugging
        """
    def setSequenceNum(self, arg0: int) -> Tracklets:
        """setSequenceNum(self: depthai.Tracklets, arg0: int) -> depthai.Tracklets

        Retrieves image sequence number
        """
    def setTimestamp(self, arg0: datetime.timedelta) -> Tracklets:
        """setTimestamp(self: depthai.Tracklets, arg0: datetime.timedelta) -> depthai.Tracklets

        Sets image timestamp related to dai::Clock::now()
        """
    def setTimestampDevice(self, arg0: datetime.timedelta) -> Tracklets:
        """setTimestampDevice(self: depthai.Tracklets, arg0: datetime.timedelta) -> depthai.Tracklets

        Sets image timestamp related to dai::Clock::now()
        """

class UVCProperties:
    gpioInit: dict[int, int]
    gpioStreamOff: dict[int, int]
    gpioStreamOn: dict[int, int]
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class UsbSpeed:
    __members__: ClassVar[dict] = ...  # read-only
    FULL: ClassVar[UsbSpeed] = ...
    HIGH: ClassVar[UsbSpeed] = ...
    LOW: ClassVar[UsbSpeed] = ...
    SUPER: ClassVar[UsbSpeed] = ...
    SUPER_PLUS: ClassVar[UsbSpeed] = ...
    UNKNOWN: ClassVar[UsbSpeed] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.UsbSpeed, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.UsbSpeed) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.UsbSpeed) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class Version:
    @overload
    def __init__(self, v: str) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Version, v: str) -> None

        Construct Version from string

        2. __init__(self: depthai.Version, major: int, minor: int, patch: int) -> None

        Construct Version major, minor and patch numbers
        """
    @overload
    def __init__(self, major: int, minor: int, patch: int) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.Version, v: str) -> None

        Construct Version from string

        2. __init__(self: depthai.Version, major: int, minor: int, patch: int) -> None

        Construct Version major, minor and patch numbers
        """
    def getBuildInfo(self) -> str:
        """getBuildInfo(self: depthai.Version) -> str

        Get build info
        """
    def getSemver(self) -> Version:
        """getSemver(self: depthai.Version) -> depthai.Version

        Retrieves semver version (no build information)
        """
    def toStringSemver(self) -> str:
        """toStringSemver(self: depthai.Version) -> str

        Convert Version to semver (no build information) string
        """
    def __eq__(self, arg0: Version) -> bool:
        """__eq__(self: depthai.Version, arg0: depthai.Version) -> bool"""
    def __gt__(self, arg0: Version) -> bool:
        """__gt__(self: depthai.Version, arg0: depthai.Version) -> bool"""
    def __lt__(self, arg0: Version) -> bool:
        """__lt__(self: depthai.Version, arg0: depthai.Version) -> bool"""

class VideoEncoderProperties:
    class Profile:
        __members__: ClassVar[dict] = ...  # read-only
        H264_BASELINE: ClassVar[VideoEncoderProperties.Profile] = ...
        H264_HIGH: ClassVar[VideoEncoderProperties.Profile] = ...
        H264_MAIN: ClassVar[VideoEncoderProperties.Profile] = ...
        H265_MAIN: ClassVar[VideoEncoderProperties.Profile] = ...
        MJPEG: ClassVar[VideoEncoderProperties.Profile] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.VideoEncoderProperties.Profile, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.VideoEncoderProperties.Profile) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.VideoEncoderProperties.Profile) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...

    class RateControlMode:
        __members__: ClassVar[dict] = ...  # read-only
        CBR: ClassVar[VideoEncoderProperties.RateControlMode] = ...
        VBR: ClassVar[VideoEncoderProperties.RateControlMode] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.VideoEncoderProperties.RateControlMode, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.VideoEncoderProperties.RateControlMode) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.VideoEncoderProperties.RateControlMode) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    bitrate: int
    keyframeFrequency: int
    maxBitrate: int
    numBFrames: int
    numFramesPool: int
    outputFrameSize: int
    profile: VideoEncoderProperties.Profile
    quality: int
    rateCtrlMode: VideoEncoderProperties.RateControlMode
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class WarpProperties:
    class Interpolation:
        __members__: ClassVar[dict] = ...  # read-only
        BICUBIC: ClassVar[Interpolation] = ...
        BILINEAR: ClassVar[Interpolation] = ...
        BYPASS: ClassVar[Interpolation] = ...
        DEFAULT: ClassVar[Interpolation] = ...
        DEFAULT_DISPARITY_DEPTH: ClassVar[Interpolation] = ...
        NEAREST_NEIGHBOR: ClassVar[Interpolation] = ...
        __entries: ClassVar[dict] = ...
        def __init__(self, value: int) -> None:
            """__init__(self: depthai.Interpolation, value: int) -> None"""
        def __eq__(self, other: object) -> bool:
            """__eq__(self: object, other: object) -> bool"""
        def __hash__(self) -> int:
            """__hash__(self: object) -> int"""
        def __index__(self) -> int:
            """__index__(self: depthai.Interpolation) -> int"""
        def __int__(self) -> int:
            """__int__(self: depthai.Interpolation) -> int"""
        def __ne__(self, other: object) -> bool:
            """__ne__(self: object, other: object) -> bool"""
        @property
        def name(self) -> str: ...
        @property
        def value(self) -> int: ...
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class XLinkConnection:
    @overload
    def __init__(self, arg0: DeviceInfo, arg1: list[int]) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.XLinkConnection, arg0: depthai.DeviceInfo, arg1: list[int]) -> None

        2. __init__(self: depthai.XLinkConnection, arg0: depthai.DeviceInfo, arg1: str) -> None

        3. __init__(self: depthai.XLinkConnection, arg0: depthai.DeviceInfo) -> None
        """
    @overload
    def __init__(self, arg0: DeviceInfo, arg1: str) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.XLinkConnection, arg0: depthai.DeviceInfo, arg1: list[int]) -> None

        2. __init__(self: depthai.XLinkConnection, arg0: depthai.DeviceInfo, arg1: str) -> None

        3. __init__(self: depthai.XLinkConnection, arg0: depthai.DeviceInfo) -> None
        """
    @overload
    def __init__(self, arg0: DeviceInfo) -> None:
        """__init__(*args, **kwargs)
        Overloaded function.

        1. __init__(self: depthai.XLinkConnection, arg0: depthai.DeviceInfo, arg1: list[int]) -> None

        2. __init__(self: depthai.XLinkConnection, arg0: depthai.DeviceInfo, arg1: str) -> None

        3. __init__(self: depthai.XLinkConnection, arg0: depthai.DeviceInfo) -> None
        """
    @staticmethod
    def bootBootloader(devInfo: DeviceInfo) -> DeviceInfo:
        """bootBootloader(devInfo: depthai.DeviceInfo) -> depthai.DeviceInfo"""
    @staticmethod
    def getAllConnectedDevices(state: XLinkDeviceState = ..., skipInvalidDevices: bool = ..., platform: XLinkPlatform = ...) -> list[DeviceInfo]:
        """getAllConnectedDevices(state: depthai.XLinkDeviceState = <XLinkDeviceState.X_LINK_ANY_STATE: 0>, skipInvalidDevices: bool = True, platform: depthai.XLinkPlatform = <XLinkPlatform.X_LINK_MYRIAD_X: 2480>) -> list[depthai.DeviceInfo]"""
    @staticmethod
    def getDeviceByMxId(mxId: str, state: XLinkDeviceState = ..., skipInvalidDevice: bool = ...) -> tuple[bool, DeviceInfo]:
        """getDeviceByMxId(mxId: str, state: depthai.XLinkDeviceState = <XLinkDeviceState.X_LINK_ANY_STATE: 0>, skipInvalidDevice: bool = True) -> tuple[bool, depthai.DeviceInfo]"""
    @staticmethod
    def getFirstDevice(state: XLinkDeviceState = ..., skipInvalidDevice: bool = ...) -> tuple[bool, DeviceInfo]:
        """getFirstDevice(state: depthai.XLinkDeviceState = <XLinkDeviceState.X_LINK_ANY_STATE: 0>, skipInvalidDevice: bool = True) -> tuple[bool, depthai.DeviceInfo]"""
    @staticmethod
    def getGlobalProfilingData() -> ProfilingData:
        """getGlobalProfilingData() -> depthai.ProfilingData

        Get current accumulated profiling data

        Returns:
            ProfilingData from the specific connection
        """

class XLinkDeviceState:
    __members__: ClassVar[dict] = ...  # read-only
    X_LINK_ANY_STATE: ClassVar[XLinkDeviceState] = ...
    X_LINK_BOOTED: ClassVar[XLinkDeviceState] = ...
    X_LINK_BOOTLOADER: ClassVar[XLinkDeviceState] = ...
    X_LINK_FLASH_BOOTED: ClassVar[XLinkDeviceState] = ...
    X_LINK_UNBOOTED: ClassVar[XLinkDeviceState] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.XLinkDeviceState, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.XLinkDeviceState) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.XLinkDeviceState) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class XLinkError(RuntimeError): ...

class XLinkError_t:
    __members__: ClassVar[dict] = ...  # read-only
    X_LINK_ALREADY_OPEN: ClassVar[XLinkError_t] = ...
    X_LINK_COMMUNICATION_FAIL: ClassVar[XLinkError_t] = ...
    X_LINK_COMMUNICATION_NOT_OPEN: ClassVar[XLinkError_t] = ...
    X_LINK_COMMUNICATION_UNKNOWN_ERROR: ClassVar[XLinkError_t] = ...
    X_LINK_DEVICE_ALREADY_IN_USE: ClassVar[XLinkError_t] = ...
    X_LINK_DEVICE_NOT_FOUND: ClassVar[XLinkError_t] = ...
    X_LINK_ERROR: ClassVar[XLinkError_t] = ...
    X_LINK_INIT_PCIE_ERROR: ClassVar[XLinkError_t] = ...
    X_LINK_INIT_TCP_IP_ERROR: ClassVar[XLinkError_t] = ...
    X_LINK_INIT_USB_ERROR: ClassVar[XLinkError_t] = ...
    X_LINK_INSUFFICIENT_PERMISSIONS: ClassVar[XLinkError_t] = ...
    X_LINK_NOT_IMPLEMENTED: ClassVar[XLinkError_t] = ...
    X_LINK_OUT_OF_MEMORY: ClassVar[XLinkError_t] = ...
    X_LINK_SUCCESS: ClassVar[XLinkError_t] = ...
    X_LINK_TIMEOUT: ClassVar[XLinkError_t] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.XLinkError_t, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.XLinkError_t) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.XLinkError_t) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class XLinkInProperties:
    maxDataSize: int
    numFrames: int
    streamName: str
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class XLinkOutProperties:
    maxFpsLimit: float
    metadataOnly: bool
    streamName: str
    def __init__(self, *args, **kwargs) -> None:
        """Initialize self.  See help(type(self)) for accurate signature."""

class XLinkPlatform:
    __members__: ClassVar[dict] = ...  # read-only
    X_LINK_ANY_PLATFORM: ClassVar[XLinkPlatform] = ...
    X_LINK_MYRIAD_2: ClassVar[XLinkPlatform] = ...
    X_LINK_MYRIAD_X: ClassVar[XLinkPlatform] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.XLinkPlatform, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.XLinkPlatform) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.XLinkPlatform) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class XLinkProtocol:
    __members__: ClassVar[dict] = ...  # read-only
    X_LINK_ANY_PROTOCOL: ClassVar[XLinkProtocol] = ...
    X_LINK_IPC: ClassVar[XLinkProtocol] = ...
    X_LINK_NMB_OF_PROTOCOLS: ClassVar[XLinkProtocol] = ...
    X_LINK_PCIE: ClassVar[XLinkProtocol] = ...
    X_LINK_TCP_IP: ClassVar[XLinkProtocol] = ...
    X_LINK_USB_CDC: ClassVar[XLinkProtocol] = ...
    X_LINK_USB_VSC: ClassVar[XLinkProtocol] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.XLinkProtocol, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.XLinkProtocol) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.XLinkProtocol) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

class XLinkReadError(XLinkError): ...

class XLinkWriteError(XLinkError): ...

class connectionInterface:
    __members__: ClassVar[dict] = ...  # read-only
    ETHERNET: ClassVar[connectionInterface] = ...
    USB: ClassVar[connectionInterface] = ...
    WIFI: ClassVar[connectionInterface] = ...
    __entries: ClassVar[dict] = ...
    def __init__(self, value: int) -> None:
        """__init__(self: depthai.connectionInterface, value: int) -> None"""
    def __eq__(self, other: object) -> bool:
        """__eq__(self: object, other: object) -> bool"""
    def __hash__(self) -> int:
        """__hash__(self: object) -> int"""
    def __index__(self) -> int:
        """__index__(self: depthai.connectionInterface) -> int"""
    def __int__(self) -> int:
        """__int__(self: depthai.connectionInterface) -> int"""
    def __ne__(self, other: object) -> bool:
        """__ne__(self: object, other: object) -> bool"""
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...

def isDatatypeSubclassOf(arg0: DatatypeEnum, arg1: DatatypeEnum) -> bool:
    """isDatatypeSubclassOf(arg0: depthai.DatatypeEnum, arg1: depthai.DatatypeEnum) -> bool"""
